/**
 * E2E Tests — Navigation and Core Pages
 * Covers: home dashboard, profile, analytics, 404 handling
 */

import { test, expect, Page } from '@playwright/test';

const BASE_URL = process.env.PLAYWRIGHT_BASE_URL || 'http://localhost:4028';

// ── Helpers ───────────────────────────────────────────────────────────────────
async function setGuestSession(page: Page) {
  await page.goto(`${BASE_URL}/sign-up-login-screen`);
  await page.evaluate(() => {
    localStorage.setItem('gm_guest_session', JSON.stringify({
      name: 'E2ETestPlayer',
      token: 'guest_e2e_token_456',
    }));
  });
}

// ── 404 Page ──────────────────────────────────────────────────────────────────
test.describe('404 Handling', () => {
  test('shows not-found page for unknown routes', async ({ page }) => {
    const response = await page.goto(`${BASE_URL}/this-route-does-not-exist`);
    // Either 404 status or custom not-found page
    expect(response?.status()).toBeLessThanOrEqual(404);
  });

  test('not-found page has navigation back to home', async ({ page }) => {
    await page.goto(`${BASE_URL}/nonexistent-page-xyz`);
    // Should render something (not blank)
    const body = await page.textContent('body');
    expect(body?.length).toBeGreaterThan(0);
  });
});

// ── Home Dashboard ────────────────────────────────────────────────────────────
test.describe('Home Dashboard', () => {
  test.beforeEach(async ({ page }) => {
    await setGuestSession(page);
    await page.goto(`${BASE_URL}/`);
    await page.waitForLoadState('networkidle');
  });

  test('renders without crashing', async ({ page }) => {
    const body = await page.textContent('body');
    expect(body?.length).toBeGreaterThan(0);
  });

  test('has no broken image resources', async ({ page }) => {
    const failedImages: string[] = [];
    page.on('response', (response) => {
      if (response.request().resourceType() === 'image' && response.status() >= 400) {
        failedImages.push(response.url());
      }
    });
    await page.goto(`${BASE_URL}/`);
    await page.waitForLoadState('networkidle');
    expect(failedImages).toHaveLength(0);
  });
});

// ── Profile Page ──────────────────────────────────────────────────────────────
test.describe('Profile Page', () => {
  test.beforeEach(async ({ page }) => {
    await setGuestSession(page);
    await page.goto(`${BASE_URL}/profile`);
    await page.waitForLoadState('networkidle');
  });

  test('renders profile page without crash', async ({ page }) => {
    const body = await page.textContent('body');
    expect(body?.length).toBeGreaterThan(0);
  });
});

// ── Analytics Page ────────────────────────────────────────────────────────────
test.describe('Analytics Page', () => {
  test.beforeEach(async ({ page }) => {
    await setGuestSession(page);
    await page.goto(`${BASE_URL}/analytics`);
    await page.waitForLoadState('networkidle');
  });

  test('renders analytics page without crash', async ({ page }) => {
    const body = await page.textContent('body');
    expect(body?.length).toBeGreaterThan(0);
  });
});

// ── API Health Checks ─────────────────────────────────────────────────────────
test.describe('API Health', () => {
  test('AI chat completion endpoint responds', async ({ request }) => {
    const response = await request.post(`${BASE_URL}/api/ai/chat-completion`, {
      data: {
        messages: [{ role: 'user', content: 'Hello' }],
        provider: 'GEMINI',
        model: 'gemini/gemini-2.5-flash',
      },
      headers: { 'Content-Type': 'application/json' },
    });
    // Should not return 404 (endpoint exists)
    expect(response.status()).not.toBe(404);
  });

  test('auth callback route exists', async ({ request }) => {
    const response = await request.get(`${BASE_URL}/auth/callback`);
    // Should redirect (3xx) not 404
    expect(response.status()).not.toBe(404);
  });
});

// ── Performance Checks ────────────────────────────────────────────────────────
test.describe('Performance', () => {
  test('home page loads within 5 seconds', async ({ page }) => {
    const start = Date.now();
    await page.goto(`${BASE_URL}/`);
    await page.waitForLoadState('domcontentloaded');
    const loadTime = Date.now() - start;
    expect(loadTime).toBeLessThan(5000);
  });

  test('practice page loads within 5 seconds', async ({ page }) => {
    await setGuestSession(page);
    const start = Date.now();
    await page.goto(`${BASE_URL}/practice`);
    await page.waitForLoadState('domcontentloaded');
    const loadTime = Date.now() - start;
    expect(loadTime).toBeLessThan(5000);
  });

  test('no console errors on home page', async ({ page }) => {
    const errors: string[] = [];
    page.on('console', (msg) => {
      if (msg.type() === 'error') errors.push(msg.text());
    });
    await page.goto(`${BASE_URL}/`);
    await page.waitForLoadState('networkidle');
    // Filter out known third-party errors
    const criticalErrors = errors.filter(
      (e) => !e.includes('AdSense') && !e.includes('googletag') && !e.includes('gtag')
    );
    expect(criticalErrors).toHaveLength(0);
  });
});
