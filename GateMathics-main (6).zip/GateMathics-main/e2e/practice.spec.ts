/**
 * E2E Tests — Practice Mode Flow
 * Covers: config selection, question answering, summary display
 */

import { test, expect, Page } from '@playwright/test';

const BASE_URL = process.env.PLAYWRIGHT_BASE_URL || 'http://localhost:4028';

// ── Helpers ───────────────────────────────────────────────────────────────────
async function setupGuestSession(page: Page) {
  await page.goto(`${BASE_URL}/sign-up-login-screen`);
  await page.waitForLoadState('networkidle');
  await page.getByText('Continue as Guest').click();
  await page.getByPlaceholder('e.g. Rohan Verma').fill('TestPlayer');
  await page.getByText('🎮 Enter as Guest').click();
  await page.waitForURL(`${BASE_URL}/`);
}

// ── Practice Mode Page ────────────────────────────────────────────────────────
test.describe('Practice Mode', () => {
  test.beforeEach(async ({ page }) => {
    // Set guest session directly in localStorage to skip login
    await page.goto(`${BASE_URL}/sign-up-login-screen`);
    await page.evaluate(() => {
      localStorage.setItem('gm_guest_session', JSON.stringify({
        name: 'TestPlayer',
        token: 'guest_test_token_123',
      }));
    });
    await page.goto(`${BASE_URL}/practice`);
    await page.waitForLoadState('networkidle');
  });

  test('renders Practice Mode header', async ({ page }) => {
    await expect(page.getByText('Practice Mode')).toBeVisible();
  });

  test('renders config phase with all sections', async ({ page }) => {
    await expect(page.getByText('Practice Session')).toBeVisible();
    await expect(page.getByText('Select Topics')).toBeVisible();
    await expect(page.getByText('Difficulty')).toBeVisible();
    await expect(page.getByText('Question Count')).toBeVisible();
    await expect(page.getByText('Start Practice Session')).toBeVisible();
  });

  test('shows all 12 topics in config', async ({ page }) => {
    await expect(page.getByText('Operating Systems')).toBeVisible();
    await expect(page.getByText('Algorithms')).toBeVisible();
    await expect(page.getByText('DBMS')).toBeVisible();
    await expect(page.getByText('Computer Networks')).toBeVisible();
  });

  test('can select a topic', async ({ page }) => {
    await page.getByText('Algorithms').click();
    await expect(page.getByText('1 topic selected')).toBeVisible();
  });

  test('can select difficulty', async ({ page }) => {
    await page.getByText('Easy').click();
    // Easy button should become active (has ring styling)
    const easyBtn = page.getByText('Easy').locator('..');
    await expect(easyBtn).toBeVisible();
  });

  test('can change question count', async ({ page }) => {
    await page.getByText('5').click();
    await expect(page.getByText('5 questions · Mixed difficulty')).toBeVisible();
  });

  test('starts session and shows question phase', async ({ page }) => {
    await page.getByText('Start Practice Session').click();
    // Should show question counter
    await expect(page.getByText(/Q\d+ \/ \d+/)).toBeVisible({ timeout: 10000 });
  });

  test('shows progress bar during question phase', async ({ page }) => {
    await page.getByText('Start Practice Session').click();
    await page.waitForSelector('[class*="bg-primary"][class*="rounded-full"]', { timeout: 10000 });
  });

  test('shows "Complete" in header after all questions', async ({ page }) => {
    // Select 5 questions for faster test
    await page.getByText('5').click();
    await page.getByText('Start Practice Session').click();

    // Wait for question to load
    await page.waitForSelector('text=/Q1 \\/ 5/', { timeout: 15000 });
  });
});

// ── Practice Config Validation ────────────────────────────────────────────────
test.describe('Practice Config', () => {
  test.beforeEach(async ({ page }) => {
    await page.goto(`${BASE_URL}/sign-up-login-screen`);
    await page.evaluate(() => {
      localStorage.setItem('gm_guest_session', JSON.stringify({
        name: 'TestPlayer',
        token: 'guest_test_token_123',
      }));
    });
    await page.goto(`${BASE_URL}/practice`);
    await page.waitForLoadState('networkidle');
  });

  test('shows estimated time based on difficulty and count', async ({ page }) => {
    await expect(page.getByText(/Estimated time:/)).toBeVisible();
  });

  test('shows AI-Assisted Hints badge', async ({ page }) => {
    await expect(page.getByText('AI-Assisted Hints')).toBeVisible();
  });

  test('deselects topic on second click', async ({ page }) => {
    await page.getByText('Algorithms').click();
    await expect(page.getByText('1 topic selected')).toBeVisible();
    await page.getByText('Algorithms').click();
    await expect(page.getByText('All 12 topics in pool')).toBeVisible();
  });

  test('Clear all button removes all selected topics', async ({ page }) => {
    await page.getByText('Algorithms').click();
    await page.getByText('DBMS').click();
    await page.getByText('Clear all').click();
    await expect(page.getByText('All 12 topics in pool')).toBeVisible();
  });
});
