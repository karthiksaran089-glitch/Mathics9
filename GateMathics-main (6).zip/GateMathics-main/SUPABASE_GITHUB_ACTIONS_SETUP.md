# GateMathics: Supabase + GitHub Actions Setup

This guide explains how to automatically deploy SQL migrations from GitHub to your Supabase database.

## How It Works

When you push SQL changes to `supabase/migrations/**` on the `main` branch, GitHub Actions automatically:

1. Spins up a runner with Node.js + Supabase CLI
2. Links to your Supabase project
3. Runs `supabase db push` to apply all new migration files
4. Verifies the migration status

The workflow file is at: `.github/workflows/supabase-migrate.yml`

## One-Time Setup

### Step 1: Get your Supabase Access Token

1. Go to https://supabase.com/dashboard/account/tokens
2. Click **Generate new token**
3. Give it a name (e.g., "GitHub Actions")
4. Copy the generated token (you'll only see it once!)

### Step 2: Find your Project Ref

1. Go to your Supabase project dashboard
2. Click **Settings** (gear icon) → **General**
3. Copy the **Reference ID** (e.g., `abc123xyz`)

### Step 3: Get your Database Password

1. In Supabase dashboard, go to **Settings** → **Database**
2. Find the **Database password** section
3. If you forgot it, click **Reset database password** (save the new one!)
4. Copy the password

### Step 4: Add Secrets to GitHub

1. Go to your GitHub repository
2. Click **Settings** → **Secrets and variables** → **Actions**
3. Click **New repository secret** and add these three:

| Secret Name | Value |
|-------------|-------|
| `SUPABASE_ACCESS_TOKEN` | Your Supabase access token from Step 1 |
| `SUPABASE_PROJECT_REF` | Your project reference ID from Step 2 |
| `SUPABASE_DB_PASSWORD` | Your database password from Step 3 |

### Step 5: Test the Workflow

After adding the secrets, trigger the workflow:

1. Make a small change to any file in `supabase/migrations/`
2. Commit and push to `main`:
   ```bash
   git add supabase/migrations/
   git commit -m "Test migration deployment"
   git push origin main
   ```
3. Go to GitHub → **Actions** tab
4. You should see "Supabase DB Migrations" workflow running
5. Click on it to see logs and confirm success

## Manual Trigger

You can also manually trigger the workflow:

1. Go to GitHub → **Actions** tab
2. Click "Supabase DB Migrations" on the left
3. Click **Run workflow** → **Run workflow**

## Migration File Naming Convention

Supabase CLI applies migrations in alphabetical order based on filename. Use a timestamp prefix:

```
supabase/migrations/
  20260602093507_user_profiles_auth.sql
  20260602141000_support_messages_ranked_sessions.sql
  20260603084727_practice_sessions.sql
  20260603180000_enable_realtime.sql
  20260604110000_analytics_dashboard.sql
  20260604120000_profile_account.sql
  20260604130000_analytics_performance_overview.sql
  20260604140000_profile_raw_data.sql
  20260604150000_points_raw_data.sql
```

The format is: `YYYYMMDDHHMMSS_descriptive_name.sql`

## Troubleshooting

### "SUPABASE_ACCESS_TOKEN secret is not set"
- Go to GitHub → Settings → Secrets and variables → Actions
- Add the `SUPABASE_ACCESS_TOKEN` secret

### "Connection failed"
- Verify your `SUPABASE_PROJECT_REF` is correct
- Check that your Supabase project is not paused (free tier pauses after inactivity)

### "Password authentication failed"
- Reset your database password in Supabase dashboard
- Update the `SUPABASE_DB_PASSWORD` secret in GitHub

### "Migration failed with SQL error"
- Check the workflow logs for the specific error
- Verify the SQL syntax in your migration file
- Make sure referenced tables/views exist (apply migrations in order)

### "Permission denied for table"
- Check your RLS policies in the migration file
- Ensure the migration includes necessary GRANT statements

## Verifying Deployment

After the workflow completes, verify in Supabase:

1. Go to https://supabase.com/dashboard → your project
2. Click **SQL Editor** → New query
3. Run:
   ```sql
   SELECT tablename FROM pg_tables 
   WHERE schemaname = 'public' 
   ORDER BY tablename;
   ```
4. Confirm all your tables exist
5. Check views:
   ```sql
   SELECT viewname FROM pg_views 
   WHERE schemaname = 'public' 
   ORDER BY viewname;
   ```

## Best Practices

1. **Never edit a migration file after it's been merged** — Create a new migration instead
2. **Test locally first** using `supabase db reset` if you have local Supabase
3. **Use `IF NOT EXISTS` clauses** to make migrations idempotent
4. **Include `DROP IF EXISTS`** before `CREATE` for views/functions
5. **Add comments** explaining what each migration does
6. **Keep migrations small and focused** on a single feature/change

## Local Development

To test migrations locally before pushing:

```bash
# Install Supabase CLI
brew install supabase/tap/supabase  # macOS
# or npm install -g supabase

# Start local Supabase
supabase start

# Apply migrations locally
supabase db reset

# Or push to remote
supabase db push
```

## Related Files

- **Workflow config:** `.github/workflows/supabase-migrate.yml`
- **Supabase config:** `supabase/config.toml`
- **Migrations folder:** `supabase/migrations/`
- **Verification script:** `scripts/verify_analytics_flow.sql`