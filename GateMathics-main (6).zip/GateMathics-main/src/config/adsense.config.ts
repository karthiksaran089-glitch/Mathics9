export const adsenseConfig = {
  client: process.env.NEXT_PUBLIC_ADSENSE_CLIENT as string,
  slots: {
    // Leaderboard — top of content pages (728x90 / responsive)
    leaderboard: 'YOUR_LEADERBOARD_SLOT_ID',
    // In-article — between content sections (responsive)
    inArticle: 'YOUR_IN_ARTICLE_SLOT_ID',
    // Sidebar rectangle — right rail (300x250 / responsive)
    sidebar: 'YOUR_SIDEBAR_SLOT_ID',
    // Footer banner — bottom of page (responsive)
    footer: 'YOUR_FOOTER_SLOT_ID',
  },
} as const;

export type AdSlotKey = keyof typeof adsenseConfig.slots;
