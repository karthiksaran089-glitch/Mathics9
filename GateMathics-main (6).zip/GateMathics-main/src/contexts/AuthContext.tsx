'use client';

import { createContext, useContext, useEffect, useState } from 'react';
import { createClient } from '../lib/supabase/client';

const AuthContext = createContext<any>({});

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within AuthProvider');
  }
  return context;
};

export const AuthProvider = ({ children }: { children: React.ReactNode }) => {
  const [user, setUser] = useState<any>(null);
  const [session, setSession] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [guestSession, setGuestSession] = useState<{ name: string; token: string } | null>(null);
  const supabase = createClient();

  // Ensure user profile exists with Silver rank and zeroed stats on first sign-in
  const ensureUserProfile = async (authUser: any) => {
    if (!authUser || !supabase) return;
    try {
      const { data: existing } = await supabase
        .from('user_profiles')
        .select('id')
        .eq('id', authUser.id)
        .single();

      if (!existing) {
        // First-time user: create profile with Silver rank and all stats zeroed
        await supabase.from('user_profiles').upsert({
          id: authUser.id,
          email: authUser.email ?? '',
          display_name:
            authUser.user_metadata?.full_name ||
            authUser.user_metadata?.name ||
            (authUser.email ? authUser.email.split('@')[0] : 'User'),
          avatar_url:
            authUser.user_metadata?.avatar_url ||
            authUser.user_metadata?.picture ||
            '',
          auth_method: authUser.app_metadata?.provider === 'google' ? 'google' : 'email_otp',
          rank: 'Silver',
          lp: 0,
          total_questions_answered: 0,
          total_correct: 0,
          total_incorrect: 0,
          total_timeout: 0,
          overall_accuracy: 0,
          avg_answer_speed_seconds: 0,
          daily_streak: 0,
          longest_streak: 0,
          total_sessions: 0,
          total_ranked_sessions: 0,
          total_practice_sessions: 0,
        }, { onConflict: 'id', ignoreDuplicates: true });
      }
    } catch {
      // Profile creation is best-effort; DB trigger handles it as fallback
    }
  };

  useEffect(() => {
    // Restore guest session from localStorage (client-only, safe inside useEffect)
    const stored = localStorage.getItem('gm_guest_session');
    if (stored) {
      try {
        const parsed = JSON.parse(stored);
        if (parsed?.token && parsed?.name) {
          setGuestSession(parsed);
        }
      } catch {
        localStorage.removeItem('gm_guest_session');
      }
    }

    if (!supabase) {
      setLoading(false);
      return;
    }

    // Single getSession call — avoids a redundant network round-trip on every page load.
    // onAuthStateChange fires immediately with the cached session, so we rely on it
    // as the primary source of truth and only use getSession to set initial state fast.
    let resolved = false;
    supabase.auth.getSession().then(({ data: { session: initialSession } }: any) => {
      if (!resolved) {
        setSession(initialSession);
        setUser(initialSession?.user ?? null);
        setLoading(false);
        resolved = true;
      }
    });

    const {
      data: { subscription }
    } = supabase.auth.onAuthStateChange((event: any, session: any) => {
      setSession(session);
      setUser(session?.user ?? null);
      if (!resolved) {
        setLoading(false);
        resolved = true;
      }

      // On first sign-in, ensure profile is initialized
      if ((event === 'SIGNED_IN' || event === 'USER_UPDATED') && session?.user) {
        ensureUserProfile(session.user);
      }
    });

    return () => subscription.unsubscribe();
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // ── Google OAuth ──────────────────────────────────────────
  const signInWithGoogle = async () => {
    const appUrl = process.env.NEXT_PUBLIC_APP_URL || (typeof window !== 'undefined' ? window.location.origin : '');
    const { data, error } = await supabase.auth.signInWithOAuth({
      provider: 'google',
      options: {
        redirectTo: `${appUrl}/auth/callback`,
        queryParams: {
          access_type: 'offline',
          prompt: 'consent',
        },
      },
    });
    if (error) throw error;
    return data;
  };

  // ── Email OTP ─────────────────────────────────────────────
  const sendEmailOTP = async (email: string) => {
    // Do NOT set emailRedirectTo — this forces Supabase to send a 6-digit OTP code
    // instead of a magic link. The user enters the code in the app.
    const { data, error } = await supabase.auth.signInWithOtp({
      email,
      options: {
        shouldCreateUser: true,
      },
    });
    if (error) throw error;
    return data;
  };

  const verifyEmailOTP = async (email: string, token: string) => {
    const { data, error } = await supabase.auth.verifyOtp({
      email,
      token,
      type: 'email',
    });
    if (error) throw error;
    return data;
  };

  // ── Guest Access ──────────────────────────────────────────
  const signInAsGuest = async (guestName: string) => {
    const sessionToken = `guest_${Date.now()}_${Math.random().toString(36).slice(2)}`;

    const { error } = await supabase.from('guest_sessions').insert({
      guest_name: guestName,
      session_token: sessionToken,
    });
    if (error) throw error;

    const gs = { name: guestName, token: sessionToken };
    setGuestSession(gs);
    localStorage.setItem('gm_guest_session', JSON.stringify(gs));
    return gs;
  };

  const signOutGuest = () => {
    setGuestSession(null);
    localStorage.removeItem('gm_guest_session');
  };

  // ── Sign Out ──────────────────────────────────────────────
  const signOut = async () => {
    signOutGuest();
    const { error } = await supabase.auth.signOut();
    if (error) throw error;
  };

  // ── Legacy helpers (kept for backward compat) ─────────────
  const signUp = async (email: string, password: string, metadata = {}) => {
    const { data, error } = await supabase.auth.signUp({
      email,
      password,
      options: {
        data: {
          full_name: (metadata as any)?.fullName || '',
          avatar_url: (metadata as any)?.avatarUrl || '',
        },
        emailRedirectTo: `${window.location.origin}/auth/callback`,
      },
    });
    if (error) throw error;
    return data;
  };

  const signIn = async (email: string, password: string) => {
    const { data, error } = await supabase.auth.signInWithPassword({ email, password });
    if (error) throw error;
    return data;
  };

  const getCurrentUser = async () => {
    const { data: { user }, error } = await supabase.auth.getUser();
    if (error) throw error;
    return user;
  };

  const isEmailVerified = () => user?.email_confirmed_at !== null;

  const getUserProfile = async () => {
    if (!user) return null;
    const { data, error } = await supabase
      .from('user_profiles')
      .select('*')
      .eq('id', user.id)
      .single();
    if (error) throw error;
    return data;
  };

  const isGuest = !!guestSession && !user;
  const isAuthenticated = !!user || isGuest;

  const value = {
    user,
    session,
    loading,
    guestSession,
    isGuest,
    isAuthenticated,
    // New auth methods
    signInWithGoogle,
    sendEmailOTP,
    verifyEmailOTP,
    signInAsGuest,
    signOutGuest,
    // Legacy
    signUp,
    signIn,
    signOut,
    getCurrentUser,
    isEmailVerified,
    getUserProfile,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};
