'use client';

import React, { useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { useAuth } from '@/contexts/AuthContext';
import AppLayout from '@/components/AppLayout';
import PracticeModeClient from './components/PracticeMode';

export default function PracticePage() {
  const { user, guestSession, loading } = useAuth();
  const router = useRouter();

  useEffect(() => {
    if (!loading && !user && !guestSession) {
      router?.replace('/sign-up-login-screen');
    }
  }, [user, guestSession, loading, router]);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  if (!user && !guestSession) {
    return null;
  }

  return (
    <AppLayout>
      <PracticeModeClient />
    </AppLayout>
  );
}
