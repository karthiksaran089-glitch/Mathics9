'use client';
import PracticeSummary from './PracticeSummary';
export default PracticeSummary;