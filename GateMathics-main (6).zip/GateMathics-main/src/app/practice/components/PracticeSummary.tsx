'use client';
import React, { useMemo } from 'react';
import Link from 'next/link';
import Badge from '@/components/ui/Badge';
import { CheckCircle2, XCircle, Clock, RotateCcw, BookOpen, BarChart3, Target, Lightbulb, TrendingUp, AlertTriangle } from 'lucide-react';
import type { PracticeSessionState, PracticeQuestionResult } from './PracticeMode';
import Icon from '@/components/ui/AppIcon';


interface PracticeSummaryPhaseProps {
  session: PracticeSessionState;
  onPlayAgain: () => void;
  onTryNew: () => void;
}

function getResultBadge(result: PracticeQuestionResult) {
  if (result.correct === true) return <Badge variant="success" size="sm"><CheckCircle2 size={9} />Correct</Badge>;
  if (result.correct === 'timeout') return <Badge variant="warning" size="sm"><Clock size={9} />Timeout</Badge>;
  return <Badge variant="danger" size="sm"><XCircle size={9} />Wrong</Badge>;
}

export default function PracticeSummaryPhase({ session, onPlayAgain, onTryNew }: PracticeSummaryPhaseProps) {
  const { results, config } = session;

  const stats = useMemo(() => {
    const correct = results.filter((r: PracticeQuestionResult) => r.correct === true).length;
    const wrong = results.filter((r: PracticeQuestionResult) => r.correct === false).length;
    const timeout = results.filter((r: PracticeQuestionResult) => r.correct === 'timeout').length;
    const hintsUsed = results.filter((r: PracticeQuestionResult) => r.hintUsed).length;
    const accuracy = results.length > 0 ? Math.round((correct / results.length) * 100) : 0;
    const avgTime = results.length > 0
      ? Math.round(results.reduce((sum: number, r: PracticeQuestionResult) => sum + r.timeUsed, 0) / results.length)
      : 0;

    // Topic performance
    const topicMap: Record<string, { correct: number; total: number; topic: string }> = {};
    for (const r of results) {
      if (!topicMap[r.topic]) topicMap[r.topic] = { correct: 0, total: 0, topic: r.topic };
      topicMap[r.topic].total++;
      if (r.correct === true) topicMap[r.topic].correct++;
    }
    const topicPerformance = Object.values(topicMap).map((t) => ({
      ...t,
      accuracy: Math.round((t.correct / t.total) * 100),
    })).sort((a, b) => b.accuracy - a.accuracy);

    // Recommended focus: topics with < 60% accuracy
    const weakTopics = topicPerformance.filter((t) => t.accuracy < 60);

    return { correct, wrong, timeout, hintsUsed, accuracy, avgTime, topicPerformance, weakTopics };
  }, [results]);

  const completionPct = results.length > 0 ? Math.round((stats.correct / results.length) * 100) : 0;
  const performanceLabel = completionPct >= 80 ? 'Excellent! 🔥' : completionPct >= 60 ? 'Good work! 💪' : 'Keep practicing! 📚';

  return (
    <div className="max-w-3xl mx-auto fade-in-up">
      {/* Header */}
      <div className="text-center mb-7">
        <div className="w-16 h-16 rounded-2xl mx-auto mb-4 flex items-center justify-center glow-primary"
          style={{ background: 'linear-gradient(135deg, #A78BFA 0%, #7C3AED 100%)' }}>
          <Target size={28} className="text-white" />
        </div>
        <h1 className="text-2xl font-extrabold text-foreground mb-1">Practice Complete</h1>
        <p className="text-sm text-muted-foreground">{performanceLabel}</p>

        {/* Accuracy ring */}
        <div className="mt-4 inline-flex items-center gap-3 px-5 py-3 rounded-2xl bg-card border border-border">
          <div className="relative w-14 h-14">
            <svg className="w-14 h-14 -rotate-90" viewBox="0 0 56 56">
              <circle cx="28" cy="28" r="22" fill="none" stroke="var(--muted)" strokeWidth="5" />
              <circle
                cx="28" cy="28" r="22" fill="none"
                stroke={completionPct >= 80 ? 'var(--success)' : completionPct >= 60 ? 'var(--warning)' : 'var(--danger)'}
                strokeWidth="5"
                strokeDasharray={`${(completionPct / 100) * 138.2} 138.2`}
                strokeLinecap="round"
              />
            </svg>
            <span className="absolute inset-0 flex items-center justify-center font-mono-data text-sm font-bold text-foreground">
              {completionPct}%
            </span>
          </div>
          <div className="text-left">
            <p className="text-xs text-muted-foreground">Overall Accuracy</p>
            <p className="text-lg font-bold text-foreground">{stats.correct}/{results.length} correct</p>
          </div>
        </div>
      </div>

      {/* Stats row */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-5">
        {[
          { id: 'ps-correct', label: 'Correct', value: `${stats.correct}`, color: 'text-success', icon: CheckCircle2 },
          { id: 'ps-wrong', label: 'Incorrect', value: `${stats.wrong}`, color: 'text-danger', icon: XCircle },
          { id: 'ps-hints', label: 'Hints Used', value: `${stats.hintsUsed}`, color: 'text-accent', icon: Lightbulb },
          { id: 'ps-time', label: 'Avg Speed', value: `${stats.avgTime}s`, color: 'text-info', icon: Clock },
        ].map((stat) => {
          const Icon = stat.icon;
          return (
            <div key={stat.id} className="card-elevated p-4 text-center">
              <Icon size={16} className={`${stat.color} mx-auto mb-1.5`} />
              <p className={`font-mono-data text-2xl font-bold ${stat.color}`}>{stat.value}</p>
              <p className="text-[10px] text-muted-foreground mt-0.5">{stat.label}</p>
            </div>
          );
        })}
      </div>

      {/* Topic Performance */}
      {stats.topicPerformance.length > 0 && (
        <div className="card-elevated p-5 mb-5">
          <div className="flex items-center gap-2 mb-4">
            <TrendingUp size={15} className="text-primary" />
            <h2 className="text-sm font-semibold text-foreground">Topic Performance</h2>
          </div>
          <div className="flex flex-col gap-3">
            {stats.topicPerformance.map((tp) => (
              <div key={`tp-${tp.topic}`} className="flex items-center gap-3">
                <div className="w-32 text-xs text-foreground font-medium truncate flex-shrink-0">{tp.topic}</div>
                <div className="flex-1 h-2 bg-muted rounded-full overflow-hidden">
                  <div
                    className={`h-full rounded-full transition-all duration-700 ${
                      tp.accuracy >= 80 ? 'bg-success' : tp.accuracy >= 60 ? 'bg-warning' : 'bg-danger'
                    }`}
                    style={{ width: `${tp.accuracy}%` }}
                  />
                </div>
                <span className={`font-mono-data text-xs font-bold w-10 text-right flex-shrink-0 ${
                  tp.accuracy >= 80 ? 'text-success' : tp.accuracy >= 60 ? 'text-warning' : 'bg-danger'
                }`}>
                  {tp.accuracy}%
                </span>
                <span className="text-[10px] text-muted-foreground w-12 text-right flex-shrink-0">
                  {tp.correct}/{tp.total}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Recommended Focus */}
      {stats.weakTopics.length > 0 && (
        <div className="card-elevated p-5 mb-5">
          <div className="flex items-center gap-2 mb-3">
            <AlertTriangle size={15} className="text-warning" />
            <h2 className="text-sm font-semibold text-foreground">Recommended Focus Areas</h2>
          </div>
          <p className="text-xs text-muted-foreground mb-3">
            These topics need more practice — accuracy below 60%
          </p>
          <div className="flex flex-wrap gap-2">
            {stats.weakTopics.map((t) => (
              <div
                key={`weak-${t.topic}`}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-warning/10 border border-warning/30"
              >
                <span className="text-xs font-semibold text-warning">{t.topic}</span>
                <span className="font-mono-data text-[10px] text-warning/70">{t.accuracy}%</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Question Review */}
      <div className="card-elevated p-5 mb-6">
        <div className="flex items-center gap-2 mb-4">
          <BookOpen size={15} className="text-primary" />
          <h2 className="text-sm font-semibold text-foreground">Question Review</h2>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-border">
                {['#', 'Topic', 'Difficulty', 'Time', 'Hint', 'Result'].map((h) => (
                  <th key={`pth-${h}`} className="text-left text-[11px] font-semibold text-muted-foreground pb-2 pr-3 last:pr-0">
                    {h}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {results.map((result: PracticeQuestionResult) => {
                const diffVariant = result.difficulty === 'Easy' ? 'success' : result.difficulty === 'Medium' ? 'warning' : 'danger';
                return (
                  <tr key={result.questionId} className="border-b border-border/40 hover:bg-muted/30 transition-colors">
                    <td className="py-2.5 pr-3 font-mono-data text-xs text-muted-foreground">Q{result.questionNum}</td>
                    <td className="py-2.5 pr-3 text-xs text-foreground max-w-[120px] truncate">{result.topic}</td>
                    <td className="py-2.5 pr-3">
                      <Badge variant={diffVariant} size="sm">{result.difficulty}</Badge>
                    </td>
                    <td className="py-2.5 pr-3 font-mono-data text-xs text-muted-foreground">{result.timeUsed}s</td>
                    <td className="py-2.5 pr-3">
                      {result.hintUsed
                        ? <Lightbulb size={12} className="text-accent" />
                        : <span className="text-[10px] text-muted-foreground">—</span>}
                    </td>
                    <td className="py-2.5">{getResultBadge(result)}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        <div className="flex items-center gap-4 mt-4 pt-3 border-t border-border text-xs">
          <span className="text-success font-semibold">{stats.correct} correct</span>
          <span className="text-danger font-semibold">{stats.wrong} wrong</span>
          <span className="text-warning font-semibold">{stats.timeout} timeout</span>
          <span className="text-accent font-semibold ml-auto">{stats.hintsUsed} hints</span>
        </div>
      </div>

      {/* Actions */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
        <button
          onClick={onPlayAgain}
          className="btn-primary flex items-center justify-center gap-2 flex-1 py-3 text-sm"
        >
          <RotateCcw size={15} />
          Play Again
        </button>
        <button
          onClick={onTryNew}
          className="btn-secondary flex items-center justify-center gap-2 flex-1 py-3 text-sm"
        >
          <BookOpen size={15} />
          Try New Questions
        </button>
        <Link
          href="/analytics"
          className="btn-secondary flex items-center justify-center gap-2 flex-1 py-3 text-sm"
        >
          <BarChart3 size={15} />
          View Analytics
        </Link>
      </div>
    </div>
  );
}
