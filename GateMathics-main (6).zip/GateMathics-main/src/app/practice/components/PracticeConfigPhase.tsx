'use client';
import PracticeConfig from './PracticeConfig';
export default PracticeConfig;