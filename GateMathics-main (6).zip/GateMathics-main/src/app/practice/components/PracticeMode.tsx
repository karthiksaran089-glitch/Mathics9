'use client';
import React, { useState } from 'react';
import Toast from '@/components/ui/Toast';
import PracticeConfigPhase from './PracticeConfigPhase';
import PracticeQuestionPhase from './PracticeQuestionPhase';
import PracticeSummaryPhase from './PracticeSummaryPhase';
import LevelUpModal from '@/components/LevelUpModal';
import { createClient } from '@/lib/supabase/client';
import { getLevelInfo, getBadgesWithState, type UserProfileStats, type LevelInfo, type BadgeDefinition } from '@/lib/gamification';

export type PracticePhase = 'config' | 'question' | 'feedback' | 'summary';

export interface PracticeConfig {
  selectedTopics: string[];
  difficulty: 'Easy' | 'Medium' | 'Hard' | 'Mixed';
  questionCount: number;
}

export interface PracticeQuestionResult {
  questionId: string;
  questionNum: number;
  topic: string;
  difficulty: 'Easy' | 'Medium' | 'Hard';
  correct: boolean | 'timeout';
  timeUsed: number;
  hintUsed: boolean;
}

export interface PracticeSessionState {
  phase: PracticePhase;
  config: PracticeConfig;
  currentQuestion: number;
  results: PracticeQuestionResult[];
}

const DEFAULT_CONFIG: PracticeConfig = {
  selectedTopics: [],
  difficulty: 'Mixed',
  questionCount: 10,
};

// Save completed practice session to Supabase and update user profile stats
async function savePracticeSession(session: PracticeSessionState) {
  const supabase = createClient();
  if (!supabase) return;
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return;

  const results = session.results;
  const correct = results.filter((r) => r.correct === true).length;
  const incorrect = results.filter((r) => r.correct === false).length;
  const timeout = results.filter((r) => r.correct === 'timeout').length;
  const total = results.length;
  if (total === 0) return;

  const accuracy = Math.round((correct / total) * 100 * 100) / 100;
  const avgSpeed = Math.round((results.reduce((s, r) => s + r.timeUsed, 0) / total) * 100) / 100;
  const hintsUsed = results.filter((r) => r.hintUsed).length;

  // Insert practice session record
  const { error: sessionError } = await supabase.from('practice_sessions').insert({
    user_id: user.id,
    questions_total: total,
    questions_correct: correct,
    questions_incorrect: incorrect,
    questions_timeout: timeout,
    accuracy,
    avg_speed_seconds: avgSpeed,
    hints_used: hintsUsed,
    topics_practiced: session.config.selectedTopics,
    difficulty: session.config.difficulty,
  });
  if (sessionError) {
    console.error('[PracticeMode] Failed to save practice session:', JSON.stringify(sessionError));
  } else {
    console.log('[PracticeMode] Practice session saved successfully. Accuracy:', accuracy, 'Hints:', hintsUsed);
  }

  // Fetch current profile stats and update
  const { data: profile } = await supabase
    .from('user_profiles')
    .select('total_questions_answered, total_correct, total_incorrect, total_timeout, total_sessions, total_practice_sessions, avg_answer_speed_seconds, daily_streak, longest_streak, last_active_date')
    .eq('id', user.id)
    .single();

  if (profile) {
    const newTotalQ = (profile.total_questions_answered || 0) + total;
    const newTotalCorrect = (profile.total_correct || 0) + correct;
    const newTotalIncorrect = (profile.total_incorrect || 0) + incorrect;
    const newTotalTimeout = (profile.total_timeout || 0) + timeout;
    const newOverallAccuracy = newTotalQ > 0 ? Math.round((newTotalCorrect / newTotalQ) * 100 * 100) / 100 : 0;
    const newAvgSpeed = profile.avg_answer_speed_seconds
      ? Math.round(((Number(profile.avg_answer_speed_seconds) + avgSpeed) / 2) * 100) / 100
      : avgSpeed;

    // Update streak based on last_active_date
    const today = new Date().toISOString().split('T')[0];
    const lastActive = profile.last_active_date;
    let newStreak = profile.daily_streak || 0;
    
    if (lastActive !== today) {
      if (lastActive) {
        const lastDate = new Date(lastActive);
        const currentDate = new Date(today);
        const diffTime = Math.abs(currentDate.getTime() - lastDate.getTime());
        const diffDays = Math.round(diffTime / (1000 * 60 * 60 * 24));
        if (diffDays === 1) {
          newStreak += 1;
        } else if (diffDays > 1) {
          newStreak = 1;
        }
      } else {
        newStreak = 1;
      }
    } else if (newStreak === 0) {
      newStreak = 1; // First session today
    }
    const newLongestStreak = Math.max(profile.longest_streak || 0, newStreak);

    // Compute level before update
    const oldStats: UserProfileStats = {
      total_questions_answered: profile.total_questions_answered || 0,
      total_correct: profile.total_correct || 0,
      total_incorrect: profile.total_incorrect || 0,
      total_timeout: profile.total_timeout || 0,
      total_sessions: profile.total_sessions || 0,
      total_ranked_sessions: profile.total_ranked_sessions || 0,
      total_practice_sessions: profile.total_practice_sessions || 0,
      overall_accuracy: Number(profile.overall_accuracy) || 0,
      avg_answer_speed_seconds: Number(profile.avg_answer_speed_seconds) || 0,
      daily_streak: profile.daily_streak || 0,
      longest_streak: profile.longest_streak || 0,
      lp: profile.lp || 0,
      rank: profile.rank || 'Silver',
    };
    const oldLevel = getLevelInfo(oldStats);
    const oldBadgeIds = getBadgesWithState(oldStats).filter(b => b.unlocked).map(b => b.id);

    await supabase.from('user_profiles').update({
      total_questions_answered: newTotalQ,
      total_correct: newTotalCorrect,
      total_incorrect: newTotalIncorrect,
      total_timeout: newTotalTimeout,
      overall_accuracy: newOverallAccuracy,
      avg_answer_speed_seconds: newAvgSpeed,
      total_sessions: (profile.total_sessions || 0) + 1,
      total_practice_sessions: (profile.total_practice_sessions || 0) + 1,
      daily_streak: newStreak,
      longest_streak: newLongestStreak,
      last_active_date: today,
    }).eq('id', user.id);

    // Compute level after update
    const newStats: UserProfileStats = {
      ...oldStats,
      total_correct: newTotalCorrect,
      total_sessions: (profile.total_sessions || 0) + 1,
      total_practice_sessions: (profile.total_practice_sessions || 0) + 1,
      longest_streak: newLongestStreak,
    };
    const newLevel = getLevelInfo(newStats);
    const newBadgeIds = getBadgesWithState(newStats).filter(b => b.unlocked).map(b => b.id);
    const newBadges = getBadgesWithState(newStats)
      .filter(b => b.unlocked && !oldBadgeIds.includes(b.id));

    if (newLevel.level > oldLevel.level) {
      return { leveledUp: true, previousLevel: oldLevel.level, newLevelInfo: newLevel, newBadges };
    }
    if (newBadges.length > 0) {
      return { leveledUp: false, previousLevel: oldLevel.level, newLevelInfo: newLevel, newBadges };
    }
  }
  return null;
}

export default function PracticeModeClient() {
  const [session, setSession] = useState<PracticeSessionState>({
    phase: 'config',
    config: DEFAULT_CONFIG,
    currentQuestion: 0,
    results: [],
  });

  const [levelUpData, setLevelUpData] = useState<{
    previousLevel: number;
    newLevelInfo: LevelInfo;
    newBadges: BadgeDefinition[];
  } | null>(null);

  // Session key increments when starting a new session (playAgain or tryNew)
  // This forces PracticeQuestion to remount and clear its internal state (pool, usedIds)
  const [sessionKey, setSessionKey] = useState(0);

  const [currentFeedback, setCurrentFeedback] = useState<{
    correct: boolean | 'timeout';
    selectedOption: number | null;
    correctOption: number;
    explanation: string;
    questionText: string;
    options: string[];
    topic: string;
    difficulty: 'Easy' | 'Medium' | 'Hard';
    timeUsed: number;
    hintUsed: boolean;
  } | null>(null);

  const startSession = (config: PracticeConfig) => {
    setSessionKey((k) => k + 1);
    setSession({
      phase: 'question',
      config,
      currentQuestion: 1,
      results: [],
    });
    setCurrentFeedback(null);
  };

  const submitAnswer = (
    selectedOption: number | null,
    correctOption: number,
    isCorrect: boolean | 'timeout',
    questionText: string,
    options: string[],
    explanation: string,
    topic: string,
    difficulty: 'Easy' | 'Medium' | 'Hard',
    timeUsed: number,
    hintUsed: boolean
  ) => {
    const result: PracticeQuestionResult = {
      questionId: `pq-${session.currentQuestion}`,
      questionNum: session.currentQuestion,
      topic,
      difficulty,
      correct: isCorrect,
      timeUsed,
      hintUsed,
    };

    setCurrentFeedback({
      correct: isCorrect,
      selectedOption,
      correctOption,
      explanation,
      questionText,
      options,
      topic,
      difficulty,
      timeUsed,
      hintUsed,
    });

    setSession((prev) => ({
      ...prev,
      phase: 'feedback',
      results: [...prev.results, result],
    }));
  };

  const nextQuestion = () => {
    if (session.currentQuestion >= session.config.questionCount) {
      // Build final session state and save before showing summary
      const finalSession = { ...session, phase: 'summary' as PracticePhase };
      // Save practice session to DB and check for level-up
      savePracticeSession(finalSession).then((result) => {
        if (result && result.leveledUp) {
          setLevelUpData({
            previousLevel: result.previousLevel,
            newLevelInfo: result.newLevelInfo,
            newBadges: result.newBadges,
          });
        }
      });
      setSession(finalSession);
    } else {
      setSession((prev) => ({
        ...prev,
        phase: 'question',
        currentQuestion: prev.currentQuestion + 1,
      }));
      setCurrentFeedback(null);
    }
  };

  const playAgain = () => {
    setSession({
      phase: 'question',
      config: session.config,
      currentQuestion: 1,
      results: [],
    });
    setCurrentFeedback(null);
    setSessionKey((k) => k + 1);
  };

  const tryNewQuestions = () => {
    setSession({
      phase: 'config',
      config: DEFAULT_CONFIG,
      currentQuestion: 0,
      results: [],
    });
    setCurrentFeedback(null);
    setSessionKey((k) => k + 1);
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Practice Header */}
      <div className="sticky top-0 z-10 bg-card/80 backdrop-blur-sm border-b border-border">
        <div className="max-w-screen-xl mx-auto px-4 lg:px-8 h-14 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <span className="text-sm font-bold text-foreground">Practice Mode</span>
            {session.phase !== 'config' && (
              <>
                <div className="w-px h-4 bg-border" />
                <span className="text-xs text-muted-foreground font-mono-data">
                  {session.phase === 'summary' ? 'Complete'
                    : `Q${session.currentQuestion} / ${session.config.questionCount}`}
                </span>
              </>
            )}
          </div>
          {session.phase !== 'config' && session.phase !== 'summary' && (
            <div className="flex items-center gap-2">
              {/* Progress bar */}
              <div className="w-32 h-1.5 bg-muted rounded-full overflow-hidden">
                <div
                  className="h-full bg-primary rounded-full transition-all duration-500"
                  style={{
                    width: `${((session.currentQuestion - 1) / session.config.questionCount) * 100}%`,
                  }}
                />
              </div>
              <span className="text-[11px] font-mono-data text-muted-foreground">
                {Math.round(((session.currentQuestion - 1) / session.config.questionCount) * 100)}%
              </span>
            </div>
          )}
        </div>
      </div>

      <div className="max-w-screen-xl mx-auto px-4 lg:px-8 py-6">
        {session.phase === 'config' && (
          <PracticeConfigPhase onStart={startSession} />
        )}
        {(session.phase === 'question' || session.phase === 'feedback') && (
          <PracticeQuestionPhase
            key={sessionKey}
            session={session}
            feedback={currentFeedback}
            onSubmit={submitAnswer}
            onNext={nextQuestion}
          />
        )}
        {session.phase === 'summary' && (
          <PracticeSummaryPhase
            session={session}
            onPlayAgain={playAgain}
            onTryNew={tryNewQuestions}
          />
        )}
      </div>
      <Toast />

      {/* Level Up Modal */}
      {levelUpData && (
        <LevelUpModal
          previousLevel={levelUpData.previousLevel}
          newLevelInfo={levelUpData.newLevelInfo}
          newBadges={levelUpData.newBadges}
          onClose={() => setLevelUpData(null)}
        />
      )}
    </div>
  );
}
