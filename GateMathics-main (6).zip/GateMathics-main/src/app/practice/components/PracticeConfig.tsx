'use client';
import React, { useState } from 'react';
import { BookOpen, Zap, Target, Layers, CheckCircle2, Play, Sparkles } from 'lucide-react';
import type { PracticeConfig } from './PracticeMode';
import Icon from '@/components/ui/AppIcon';


const ALL_TOPICS = [
  { id: 'topic-os', name: 'Operating Systems', short: 'OS' },
  { id: 'topic-dbms', name: 'DBMS', short: 'DBMS' },
  { id: 'topic-algo', name: 'Algorithms', short: 'Algo' },
  { id: 'topic-ds', name: 'Data Structures', short: 'DS' },
  { id: 'topic-cn', name: 'Computer Networks', short: 'CN' },
  { id: 'topic-toc', name: 'Theory of Computation', short: 'TOC' },
  { id: 'topic-co', name: 'Computer Organisation', short: 'CO' },
  { id: 'topic-dm', name: 'Discrete Mathematics', short: 'DM' },
  { id: 'topic-pl', name: 'Programming Languages', short: 'PL' },
  { id: 'topic-cd', name: 'Compiler Design', short: 'CD' },
  { id: 'topic-se', name: 'Software Engineering', short: 'SE' },
  { id: 'topic-ai', name: 'Artificial Intelligence', short: 'AI' },
];

const DIFFICULTIES = [
  {
    key: 'Easy' as const,
    label: 'Easy',
    desc: 'Fundamental concepts',
    icon: Zap,
    color: 'text-success border-success/40 bg-success/10',
    activeRing: 'ring-success/40',
    timePerQ: 45,
  },
  {
    key: 'Medium' as const,
    label: 'Medium',
    desc: 'Application problems',
    icon: Target,
    color: 'text-warning border-warning/40 bg-warning/10',
    activeRing: 'ring-warning/40',
    timePerQ: 60,
  },
  {
    key: 'Hard' as const,
    label: 'Hard',
    desc: 'GATE-level analysis',
    icon: BookOpen,
    color: 'text-danger border-danger/40 bg-danger/10',
    activeRing: 'ring-danger/40',
    timePerQ: 90,
  },
  {
    key: 'Mixed' as const,
    label: 'Mixed',
    desc: 'All difficulty levels',
    icon: Layers,
    color: 'text-primary border-primary/40 bg-primary/10',
    activeRing: 'ring-primary/40',
    timePerQ: 65,
  },
];

const QUESTION_COUNTS = [5, 10, 15, 20];

interface PracticeConfigPhaseProps {
  onStart: (config: PracticeConfig) => void;
}

export default function PracticeConfigPhase({ onStart }: PracticeConfigPhaseProps) {
  const [selectedTopics, setSelectedTopics] = useState<string[]>([]);
  const [difficulty, setDifficulty] = useState<PracticeConfig['difficulty']>('Mixed');
  const [questionCount, setQuestionCount] = useState(10);

  const toggleTopic = (topicId: string) => {
    setSelectedTopics((prev) =>
      prev.includes(topicId) ? prev.filter((t) => t !== topicId) : [...prev, topicId]
    );
  };

  const selectedDiff = DIFFICULTIES.find((d) => d.key === difficulty)!;
  const estimatedTime = Math.round((questionCount * selectedDiff.timePerQ) / 60);

  const handleStart = () => {
    onStart({ selectedTopics, difficulty, questionCount });
  };

  return (
    <div className="max-w-4xl mx-auto fade-in-up">
      {/* Header */}
      <div className="mb-7">
        <div className="flex items-center gap-3 mb-2">
          <div className="w-10 h-10 rounded-xl bg-primary/20 flex items-center justify-center">
            <BookOpen size={20} className="text-primary" />
          </div>
          <div>
            <h1 className="text-xl font-bold text-foreground">Practice Session</h1>
            <p className="text-sm text-muted-foreground">Configure Your Practice Set</p>
          </div>
        </div>
      </div>

      {/* Select Topics */}
      <div className="card-elevated p-5 mb-5">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-sm font-semibold text-foreground">Select Topics</h2>
            <p className="text-xs text-muted-foreground mt-0.5">
              Pick one or more topics — leave empty to include all
            </p>
          </div>
          {selectedTopics.length > 0 && (
            <button
              onClick={() => setSelectedTopics([])}
              className="text-xs text-muted-foreground hover:text-foreground transition-colors"
            >
              Clear all
            </button>
          )}
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-2.5">
          {ALL_TOPICS.map((topic) => {
            const isSelected = selectedTopics.includes(topic.id);
            return (
              <button
                key={topic.id}
                onClick={() => toggleTopic(topic.id)}
                className={`flex items-center gap-2.5 p-3 rounded-xl border text-left transition-all duration-150 ${
                  isSelected
                    ? 'border-primary/60 bg-primary/10' :'border-border bg-muted/30 hover:border-border/80 hover:bg-muted/60'
                }`}
              >
                <div className={`w-5 h-5 rounded-md flex items-center justify-center flex-shrink-0 transition-colors ${
                  isSelected ? 'bg-primary' : 'bg-muted border border-border'
                }`}>
                  {isSelected && <CheckCircle2 size={11} className="text-white" />}
                </div>
                <div className="min-w-0">
                  <p className={`text-xs font-semibold truncate ${isSelected ? 'text-primary' : 'text-foreground'}`}>
                    {topic.name}
                  </p>
                  <p className="text-[10px] text-muted-foreground">{topic.short}</p>
                </div>
              </button>
            );
          })}
        </div>

        <div className="mt-4 pt-3 border-t border-border flex items-center gap-2 text-xs text-muted-foreground">
          <div className="w-2 h-2 rounded-full bg-primary" />
          {selectedTopics.length === 0
            ? 'All 12 topics in pool'
            : `${selectedTopics.length} topic${selectedTopics.length > 1 ? 's' : ''} selected`}
        </div>
      </div>

      {/* Difficulty */}
      <div className="card-elevated p-5 mb-5">
        <h2 className="text-sm font-semibold text-foreground mb-1">Difficulty</h2>
        <p className="text-xs text-muted-foreground mb-4">Choose the challenge level for your session</p>

        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
          {DIFFICULTIES.map((diff) => {
            const Icon = diff.icon;
            const isActive = difficulty === diff.key;
            return (
              <button
                key={diff.key}
                onClick={() => setDifficulty(diff.key)}
                className={`p-4 rounded-xl border text-left transition-all duration-150 ${
                  isActive
                    ? `${diff.color} ring-2 ${diff.activeRing}`
                    : 'border-border bg-muted/30 hover:bg-muted/60'
                }`}
              >
                <div className="flex items-center justify-between mb-2">
                  <Icon size={16} className={isActive ? '' : 'text-muted-foreground'} />
                  {isActive && <CheckCircle2 size={13} />}
                </div>
                <p className={`text-sm font-bold mb-0.5 ${isActive ? '' : 'text-foreground'}`}>{diff.label}</p>
                <p className={`text-[11px] leading-relaxed ${isActive ? 'opacity-80' : 'text-muted-foreground'}`}>
                  {diff.desc}
                </p>
              </button>
            );
          })}
        </div>
      </div>

      {/* Question Count */}
      <div className="card-elevated p-5 mb-5">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-sm font-semibold text-foreground">Question Count</h2>
            <p className="text-xs text-muted-foreground mt-0.5">
              More questions = longer session · ~{selectedDiff.timePerQ}s per question
            </p>
          </div>
          <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-primary/10 border border-primary/20">
            <Sparkles size={12} className="text-primary" />
            <span className="text-xs font-semibold text-primary">AI-Assisted Hints</span>
          </div>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          {QUESTION_COUNTS.map((count) => (
            <button
              key={`qcount-${count}`}
              onClick={() => setQuestionCount(count)}
              className={`flex-1 py-3 rounded-xl border font-mono-data text-lg font-bold transition-all duration-150 ${
                questionCount === count
                  ? 'border-primary/60 bg-primary/10 text-primary ring-2 ring-primary/30' :'border-border bg-muted/30 text-foreground hover:bg-muted/60'
              }`}
            >
              {count}
            </button>
          ))}
        </div>

        <p className="text-xs text-muted-foreground mt-3">
          Estimated time: ~{estimatedTime} min · {questionCount} questions
        </p>
      </div>

      {/* Start Button */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 p-5 card-elevated">
        <div>
          <p className="text-sm font-semibold text-foreground">Ready to practice?</p>
          <p className="text-xs text-muted-foreground mt-0.5">
            {questionCount} questions · {difficulty} difficulty ·{' '}
            {selectedTopics.length === 0 ? 'All topics' : `${selectedTopics.length} topic${selectedTopics.length > 1 ? 's' : ''}`}
          </p>
        </div>
        <button
          onClick={handleStart}
          className="btn-primary flex items-center justify-center gap-2 px-8 py-3 text-sm glow-primary"
        >
          <Play size={16} />
          Start Practice Session
        </button>
      </div>
    </div>
  );
}
