'use client';
import React, { useState, useCallback, useRef, useEffect } from 'react';
import { BookOpen, Clock, Lightbulb, CheckCircle2, XCircle, ChevronRight, Loader2 } from 'lucide-react';
import Badge from '@/components/ui/Badge';
import QuestionTimer from '@/app/ranked-mode-screen/components/QuestionTimer';
import { useChat } from '@/lib/hooks/useChat';
import { toast } from 'sonner';
import type { PracticeSessionState, PracticeQuestionResult } from './PracticeMode';
import { fetchPracticeFallbackQuestion } from '@/lib/questions/fallbackQuestions';
import type { FallbackQuestion } from '@/lib/questions/fallbackQuestions';

// Static local practice question bank — used as last-resort fallback when both AI
// and Supabase are unavailable (e.g. no network at all or no questions in DB).
const LOCAL_QUESTION_BANK: FallbackQuestion[] = [
  {
    id: 'local-p-001',
    topic: 'Operating Systems',
    difficulty: 'Easy',
    timeLimit: 45,
    text: 'Which of the following is NOT a function of an operating system?',
    options: ['Memory management', 'Process scheduling', 'Compiling source code', 'File system management'],
    correct: 2,
    explanation: 'Compiling source code is a function of a compiler, not the operating system. OS handles memory management, process scheduling, file systems, I/O, and security.',
    hint: 'Think about what a compiler does vs. what the OS kernel handles.',
  },
  {
    id: 'local-p-002',
    topic: 'DBMS',
    difficulty: 'Easy',
    timeLimit: 45,
    text: 'In a relational database, what is a primary key?',
    options: ['A key that opens the database', 'A unique identifier for each row in a table', 'A key used to encrypt data', 'An index on a column'],
    correct: 1,
    explanation: 'A primary key is a column (or set of columns) that uniquely identifies each row in a table. It must contain unique values and cannot be NULL.',
    hint: 'Consider what makes each row unique and identifiable.',
  },
  {
    id: 'local-p-003',
    topic: 'Algorithms',
    difficulty: 'Medium',
    timeLimit: 60,
    text: 'Which sorting algorithm has the best worst-case time complexity?',
    options: ['Bubble Sort', 'Insertion Sort', 'Merge Sort', 'Selection Sort'],
    correct: 2,
    explanation: 'Merge Sort has O(n log n) worst-case time complexity. Bubble Sort, Insertion Sort, and Selection Sort all have O(n²) worst-case.',
    hint: 'The best worst-case time complexity among common sorting algorithms is O(n log n).',
  },
  {
    id: 'local-p-004',
    topic: 'Data Structures',
    difficulty: 'Medium',
    timeLimit: 60,
    text: 'What data structure is typically used to implement recursion?',
    options: ['Queue', 'Stack', 'Array', 'Linked List'],
    correct: 1,
    explanation: 'Recursion is implemented using a stack. Each recursive call pushes a new frame onto the call stack, and when the base case is reached, frames are popped off.',
    hint: 'Think about LIFO (Last In, First Out) — which data structure follows this principle?',
  },
  {
    id: 'local-p-005',
    topic: 'Computer Networks',
    difficulty: 'Medium',
    timeLimit: 60,
    text: 'Which protocol is used to resolve IP addresses to MAC addresses?',
    options: ['DNS', 'DHCP', 'ARP', 'HTTP'],
    correct: 2,
    explanation: 'ARP (Address Resolution Protocol) is used to map IP addresses to MAC addresses on a local network. DNS resolves domain names to IP addresses.',
    hint: 'This protocol works at the link layer to find hardware addresses.',
  },
  {
    id: 'local-p-006',
    topic: 'Theory of Computation',
    difficulty: 'Hard',
    timeLimit: 90,
    text: 'Which of the following problems is undecidable?',
    options: ['Checking if a DFA accepts a string', 'The Halting Problem', 'Checking if a context-free grammar is empty', 'Checking if two DFAs are equivalent'],
    correct: 1,
    explanation: 'The Halting Problem (determining if a Turing machine halts on a given input) is undecidable — no algorithm can solve it for all possible inputs. The other three are decidable.',
    hint: 'This is the classic undecidable problem proven by Alan Turing.',
  },
  {
    id: 'local-p-007',
    topic: 'Computer Organisation',
    difficulty: 'Hard',
    timeLimit: 75,
    text: 'In pipelining, what is a data hazard?',
    options: ['A power supply issue', 'An instruction depends on the result of a previous instruction still in the pipeline', 'A cache miss', 'An incorrect branch prediction'],
    correct: 1,
    explanation: 'A data hazard occurs when an instruction depends on the result of a previous instruction that is still being processed in the pipeline. Techniques like forwarding (bypassing) help resolve this.',
    hint: 'It occurs when there is a dependency between consecutive instructions in the pipeline.',
  },
  {
    id: 'local-p-008',
    topic: 'Discrete Mathematics',
    difficulty: 'Easy',
    timeLimit: 45,
    text: 'How many bits are needed to represent 16 distinct values?',
    options: ['2 bits', '3 bits', '4 bits', '5 bits'],
    correct: 2,
    explanation: '4 bits can represent 2⁴ = 16 distinct values. In general, n bits can represent 2ⁿ distinct values.',
    hint: 'Calculate how many values n bits can represent using powers of 2.',
  },
  {
    id: 'local-p-009',
    topic: 'Programming Languages',
    difficulty: 'Easy',
    timeLimit: 45,
    text: 'What is the primary difference between a compiler and an interpreter?',
    options: ['Compilers are faster than interpreters', 'Compilers translate entire programs at once; interpreters execute line by line', 'Interpreters produce machine code', 'There is no difference'],
    correct: 1,
    explanation: 'A compiler translates the entire source code into machine code before execution. An interpreter translates and executes the code line by line at runtime.',
    hint: 'Think about how each translates source code into executable instructions.',
  },
  {
    id: 'local-p-010',
    topic: 'Compiler Design',
    difficulty: 'Hard',
    timeLimit: 75,
    text: 'Which phase of a compiler produces a stream of tokens?',
    options: ['Semantic Analysis', 'Syntax Analysis', 'Lexical Analysis', 'Code Generation'],
    correct: 2,
    explanation: 'Lexical Analysis (scanning) is the first phase that reads the source code and produces a stream of tokens by grouping characters into lexemes.',
    hint: 'This is the very first phase that breaks source code into meaningful symbols.',
  },
  {
    id: 'local-p-011',
    topic: 'Software Engineering',
    difficulty: 'Medium',
    timeLimit: 60,
    text: 'Which software development model emphasizes iterative development and customer feedback?',
    options: ['Waterfall Model', 'Agile Model', 'Spiral Model', 'V-Model'],
    correct: 1,
    explanation: 'The Agile model emphasizes iterative development, collaboration, and rapid feedback. The Waterfall model is sequential while Spiral focuses on risk assessment.',
    hint: 'This model values "individuals and interactions over processes and tools."',
  },
  {
    id: 'local-p-012',
    topic: 'Artificial Intelligence',
    difficulty: 'Medium',
    timeLimit: 60,
    text: 'In machine learning, what is overfitting?',
    options: ['The model performs well on test data but poorly on training data', 'The model performs well on training data but poorly on unseen data', 'The model is too simple to capture patterns', 'The model has too few parameters'],
    correct: 1,
    explanation: 'Overfitting occurs when a model learns the training data too well, including noise and outliers, resulting in poor generalization to new, unseen data.',
    hint: 'Think about memorization vs. learning — when a model memorizes instead of learning patterns.',
  },
  {
    id: 'local-p-013',
    topic: 'Operating Systems',
    difficulty: 'Medium',
    timeLimit: 60,
    text: 'What is a deadlock in an operating system?',
    options: ['A process that never starts', 'A set of processes where each process is waiting for a resource held by another process in the set', 'A process that runs indefinitely', 'A memory allocation failure'],
    correct: 1,
    explanation: 'Deadlock is a situation where a set of processes are blocked because each process is holding a resource and waiting for a resource held by another process in the set.',
    hint: 'It involves a circular wait condition where processes hold and wait for resources.',
  },
  {
    id: 'local-p-014',
    topic: 'DBMS',
    difficulty: 'Hard',
    timeLimit: 75,
    text: 'Which property of ACID ensures that a transaction is executed as a single, indivisible unit?',
    options: ['Consistency', 'Isolation', 'Durability', 'Atomicity'],
    correct: 3,
    explanation: 'Atomicity ensures that a transaction is treated as a single, indivisible unit — either all operations are completed successfully (commit) or none are (rollback).',
    hint: 'This property\'s name literally means "cannot be divided into smaller parts."',
  },
  {
    id: 'local-p-015',
    topic: 'Algorithms',
    difficulty: 'Easy',
    timeLimit: 45,
    text: 'What is the time complexity of binary search on a sorted array of n elements?',
    options: ['O(n)', 'O(log n)', 'O(n log n)', 'O(1)'],
    correct: 1,
    explanation: 'Binary search has O(log n) time complexity because it divides the search space in half with each comparison, requiring at most log₂(n) comparisons.',
    hint: 'Think about how the search space is divided with each step.',
  },
  {
    id: 'local-p-016',
    topic: 'Data Structures',
    difficulty: 'Hard',
    timeLimit: 75,
    text: 'Which tree traversal visits the root node first, then the left subtree, then the right subtree?',
    options: ['In-order', 'Post-order', 'Pre-order', 'Level-order'],
    correct: 2,
    explanation: 'Pre-order traversal visits the root first (pre = before children), then recursively traverses the left subtree, then the right subtree.',
    hint: 'The name tells you where the root falls in the order relative to its children.',
  },
  {
    id: 'local-p-017',
    topic: 'Computer Networks',
    difficulty: 'Easy',
    timeLimit: 45,
    text: 'What does TCP stand for?',
    options: ['Transmission Control Protocol', 'Transfer Communication Protocol', 'Transport Control Process', 'Terminal Connection Protocol'],
    correct: 0,
    explanation: 'TCP stands for Transmission Control Protocol. It is a connection-oriented protocol that provides reliable, ordered delivery of data between applications.',
    hint: 'Each word describes its function — transmitting data with control.',
  },
  {
    id: 'local-p-018',
    topic: 'Discrete Mathematics',
    difficulty: 'Medium',
    timeLimit: 60,
    text: 'What is the cardinality of the power set of a set with n elements?',
    options: ['n', '2n', 'n²', '2ⁿ'],
    correct: 3,
    explanation: 'The power set of a set with n elements has 2ⁿ elements. This includes all possible subsets, including the empty set and the set itself.',
    hint: 'Each element can either be in or out of a subset — how many combinations is that?',
  },
  {
    id: 'local-p-019',
    topic: 'Theory of Computation',
    difficulty: 'Easy',
    timeLimit: 45,
    text: 'Which automaton has a finite amount of memory and no auxiliary storage?',
    options: ['Turing Machine', 'Pushdown Automaton', 'Finite Automaton', 'Linear Bounded Automaton'],
    correct: 2,
    explanation: 'A Finite Automaton (FA) has a finite number of states and no additional memory or storage. It can only recognize regular languages.',
    hint: 'The name itself tells you it has a "finite" amount of memory.',
  },
  {
    id: 'local-p-020',
    topic: 'Artificial Intelligence',
    difficulty: 'Hard',
    timeLimit: 90,
    text: 'In A* search, what does the f(n) = g(n) + h(n) function represent?',
    options: ['The cost of the path from start to goal', 'The estimated total cost of the cheapest solution through node n', 'The heuristic estimate to the goal', 'The actual cost from start to node n'],
    correct: 1,
    explanation: 'In A*, f(n) = g(n) + h(n) represents the estimated total cost of the cheapest solution that goes through node n, where g(n) is the cost from start to n and h(n) is the heuristic estimate from n to goal.',
    hint: 'This is the sum of the cost so far and the estimated remaining cost.',
  },
];

function getLocalFallback(topics: string[], usedIds: string[]): FallbackQuestion | null {
  let pool = LOCAL_QUESTION_BANK.filter((q) => !usedIds.includes(q.id));
  if (topics.length > 0) {
    const topicFiltered = pool.filter((q) => topics.includes(q.topic));
    if (topicFiltered.length > 0) pool = topicFiltered;
  }
  if (pool.length === 0) {
    // If we've exhausted all questions (used all), reset from the full bank
    if (topics.length > 0) {
      const fullTopicPool = LOCAL_QUESTION_BANK.filter((q) => topics.includes(q.topic));
      if (fullTopicPool.length > 0) {
        pool = fullTopicPool;
      } else {
        pool = LOCAL_QUESTION_BANK;
      }
    } else {
      pool = LOCAL_QUESTION_BANK;
    }
  }
  if (pool.length === 0) return null;
  return pool[Math.floor(Math.random() * pool.length)];
}

// Topic ID → display name mapping (shared with PracticeConfigPhase)
const TOPIC_MAP: Record<string, string> = {
  'topic-os': 'Operating Systems', 'topic-dbms': 'DBMS', 'topic-algo': 'Algorithms',
  'topic-ds': 'Data Structures', 'topic-cn': 'Computer Networks', 'topic-toc': 'Theory of Computation',
  'topic-co': 'Computer Organisation', 'topic-dm': 'Discrete Mathematics', 'topic-pl': 'Programming Languages',
  'topic-cd': 'Compiler Design', 'topic-se': 'Software Engineering', 'topic-ai': 'Artificial Intelligence',
};

interface PracticeQuestionPhaseProps {
  session: PracticeSessionState;
  feedback: {
    correct: boolean | 'timeout';
    selectedOption: number | null;
    correctOption: number;
    explanation: string;
    questionText: string;
    options: string[];
    topic: string;
    difficulty: 'Easy' | 'Medium' | 'Hard';
    timeUsed: number;
    hintUsed: boolean;
  } | null;
  onSubmit: (
    selectedOption: number | null,
    correctOption: number,
    isCorrect: boolean | 'timeout',
    questionText: string,
    options: string[],
    explanation: string,
    topic: string,
    difficulty: 'Easy' | 'Medium' | 'Hard',
    timeUsed: number,
    hintUsed: boolean
  ) => void;
  onNext: () => void;
}

export default function PracticeQuestionPhase({ session, feedback, onSubmit, onNext }: PracticeQuestionPhaseProps) {
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [timerStopped, setTimerStopped] = useState(false);
  const [timeUsed, setTimeUsed] = useState(0);
  const [showHint, setShowHint] = useState(false);
  const [hintUsed, setHintUsed] = useState(false);
  const [hintText, setHintText] = useState('');
  const [question, setQuestion] = useState<FallbackQuestion | null>(null);
  const [loading, setLoading] = useState(true);
  const [loadFailed, setLoadFailed] = useState(false);
  const hasSubmitted = useRef(false);
  const usedIdsRef = useRef<string[]>([]);

  const { response: aiResponse, isLoading: hintLoading, error: hintError, sendMessage } = useChat(
    'GEMINI',
    'gemini/gemini-2.5-flash',
    false
  );

  useEffect(() => {
    if (hintError) toast.error('Could not load hint. Try again.');
  }, [hintError]);

  useEffect(() => {
    if (aiResponse && !hintLoading) {
      setHintText(aiResponse);
    }
  }, [aiResponse, hintLoading]);

  // Load question: try Supabase practice_questions table, fall back to local bank
  useEffect(() => {
    if (session.phase === 'feedback') return;
    let cancelled = false;
    setLoading(true);
    setLoadFailed(false);
    setSelectedOption(null);
    setTimerStopped(false);
    setTimeUsed(0);
    setShowHint(false);
    setHintUsed(false);
    setHintText('');
    hasSubmitted.current = false;

    const load = async () => {
      const topicNames = session.config.selectedTopics
        .map((id: string) => TOPIC_MAP[id] || id)
        .filter(Boolean);

      console.log(`[Practice] Q${session.currentQuestion}: Loading for topics=[${topicNames.join(', ')}], difficulty=${session.config.difficulty}`);

      let loaded: FallbackQuestion | null = null;

      // Try fetching from Supabase with a timeout
      try {
        const timeoutPromise = new Promise<null>((resolve) => setTimeout(() => resolve(null), 5000));
        loaded = await Promise.race([
          fetchPracticeFallbackQuestion(topicNames, session.config.difficulty, usedIdsRef.current),
          timeoutPromise,
        ]);
      } catch {
        loaded = null;
      }

      if (loaded) {
        console.log(`[Practice] Q${session.currentQuestion}: Got from Supabase: topic="${loaded.topic}", difficulty="${loaded.difficulty}"`);
      } else {
        console.warn(`[Practice] Q${session.currentQuestion}: No question from Supabase. Falling back to local question bank.`);
        // Fall back to local question bank (same pattern as Ranked Mode)
        loaded = getLocalFallback(topicNames, usedIdsRef.current);
        if (loaded) {
          console.log(`[Practice] Q${session.currentQuestion}: Got from local bank: topic="${loaded.topic}"`);
        } else {
          console.error(`[Practice] Q${session.currentQuestion}: No questions available from either Supabase or local bank.`);
        }
      }

      if (!cancelled) {
        if (loaded) {
          usedIdsRef.current = [...usedIdsRef.current, loaded.id];
          setQuestion(loaded);
        } else {
          setLoadFailed(true);
        }
        setLoading(false);
      }
    };

    load();
    return () => { cancelled = true; };
  }, [session.currentQuestion, session.phase, session.config.selectedTopics, session.config.difficulty]);

  const handleRetry = () => {
    // Reset usedIds for the current question position to retry loading
    setLoadFailed(false);
    setLoading(true);
    setQuestion(null);

    const load = async () => {
      const topicNames = session.config.selectedTopics
        .map((id: string) => TOPIC_MAP[id] || id)
        .filter(Boolean);

      let loaded: FallbackQuestion | null = null;
      try {
        const timeoutPromise = new Promise<null>((resolve) => setTimeout(() => resolve(null), 5000));
        loaded = await Promise.race([
          fetchPracticeFallbackQuestion(topicNames, session.config.difficulty, usedIdsRef.current),
          timeoutPromise,
        ]);
      } catch {
        loaded = null;
      }

      if (!loaded) {
        loaded = getLocalFallback(topicNames, usedIdsRef.current);
      }

      if (loaded) {
        usedIdsRef.current = [...usedIdsRef.current, loaded.id];
        setQuestion(loaded);
        setLoading(false);
      } else {
        setLoadFailed(true);
        setLoading(false);
      }
    };
    load();
  };

  const handleOptionSelect = (optionIndex: number) => {
    if (timerStopped || hasSubmitted.current || session.phase === 'feedback' || !question) return;
    setSelectedOption(optionIndex);
    setTimerStopped(true);
    hasSubmitted.current = true;
    const isCorrect = optionIndex === question.correct;
    setTimeout(() => {
      onSubmit(optionIndex, question.correct, isCorrect, question.text, question.options as string[], question.explanation, question.topic, question.difficulty, timeUsed, hintUsed);
    }, 500);
  };

  const handleTimeout = useCallback(() => {
    if (hasSubmitted.current || !question) return;
    hasSubmitted.current = true;
    setTimerStopped(true);
    setTimeout(() => {
      onSubmit(null, question.correct, 'timeout', question.text, question.options as string[], question.explanation, question.topic, question.difficulty, question.timeLimit, hintUsed);
    }, 400);
  }, [question, hintUsed, onSubmit]);

  const handleTick = useCallback((remaining: number) => {
    if (question) setTimeUsed(question.timeLimit - remaining);
  }, [question]);

  const handleRequestHint = () => {
    if (hintLoading || !question) return;
    setShowHint(true);
    setHintUsed(true);

    // If the question has a stored hint, use it directly (no AI call needed)
    if (question.hint) {
      setHintText(question.hint);
      return;
    }

    // Otherwise fall back to AI-generated hint
    sendMessage([
      {
        role: 'system',
        content: 'You are a GATE CS exam tutor. Give a concise, helpful hint (2-3 sentences max) that guides the student toward the answer without revealing it directly. Focus on the key concept needed.',
      },
      {
        role: 'user',
        content: `Question: ${question.text}\n\nOptions:\nA) ${question.options[0]}\nB) ${question.options[1]}\nC) ${question.options[2]}\nD) ${question.options[3]}\n\nTopic: ${question.topic}\n\nProvide a hint without revealing the answer.`,
      },
    ], { temperature: 0.5, max_tokens: 150 });
  };

  // Loading state
  if (loading && session.phase !== 'feedback') {
    return (
      <div className="max-w-3xl mx-auto flex items-center justify-center py-24">
        <Loader2 size={32} className="animate-spin text-primary" />
        <span className="ml-3 text-muted-foreground text-sm">Loading question…</span>
      </div>
    );
  }

  // Load failed state — show retry button
  if (loadFailed && session.phase !== 'feedback') {
    return (
      <div className="max-w-3xl mx-auto flex flex-col items-center justify-center py-24">
        <div className="w-16 h-16 rounded-2xl bg-warning/10 border border-warning/30 flex items-center justify-center mb-4">
          <Clock size={28} className="text-warning" />
        </div>
        <h3 className="text-lg font-semibold text-foreground mb-2">Could Not Load Question</h3>
        <p className="text-sm text-muted-foreground text-center max-w-md mb-6">
          We couldn't fetch a question right now. This might be because your practice question bank is empty or there's a connection issue.
        </p>
        <button
          onClick={handleRetry}
          className="btn-primary flex items-center gap-2 px-6 py-3 text-sm"
        >
          <Loader2 size={15} />
          Retry Loading
        </button>
      </div>
    );
  }

  const difficultyVariant = (question?.difficulty ?? 'Medium') === 'Easy' ? 'success' : (question?.difficulty ?? 'Medium') === 'Medium' ? 'warning' : 'danger';
  const isLastQuestion = session.currentQuestion >= session.config.questionCount;

  // Feedback view
  if (session.phase === 'feedback' && feedback) {
    const isCorrect = feedback.correct === true;
    const isTimeout = feedback.correct === 'timeout';
    const optionLabels = ['A', 'B', 'C', 'D'];
    const fbDiffVariant = feedback.difficulty === 'Easy' ? 'success' : feedback.difficulty === 'Medium' ? 'warning' : 'danger';

    return (
      <div className="max-w-3xl mx-auto fade-in-up">
        {/* Verdict banner */}
        <div className={`flex items-center justify-between gap-4 p-4 rounded-xl mb-5 border ${
          isCorrect ? 'bg-success/10 border-success/30' : isTimeout ? 'bg-warning/10 border-warning/30' : 'bg-danger/10 border-danger/30'
        }`}>
          <div className="flex items-center gap-3">
            {isCorrect ? <CheckCircle2 size={24} className="text-success" /> : isTimeout ? <Clock size={24} className="text-warning" /> : <XCircle size={24} className="text-danger" />}
            <div>
              <p className={`text-base font-bold ${isCorrect ? 'text-success' : isTimeout ? 'text-warning' : 'text-danger'}`}>
                {isCorrect ? 'Correct!' : isTimeout ? 'Time Out' : 'Incorrect'}
              </p>
              <p className="text-xs text-muted-foreground">
                {isTimeout ? 'You ran out of time' : isCorrect ? `Answered in ${feedback.timeUsed}s` : `You selected option ${feedback.selectedOption !== null ? optionLabels[feedback.selectedOption] : '—'}`}
                {feedback.hintUsed && ' · Hint used'}
              </p>
            </div>
          </div>
          <Badge variant={fbDiffVariant} size="sm">{feedback.difficulty}</Badge>
        </div>

        {/* Question recap */}
        <div className="card-elevated p-5 mb-4">
          <div className="flex items-center gap-2 mb-3">
            <BookOpen size={13} className="text-muted-foreground" />
            <span className="text-xs text-muted-foreground font-medium">{feedback.topic}</span>
          </div>
          <p className="text-sm font-medium text-foreground leading-relaxed mb-4">{feedback.questionText}</p>
          <div className="flex flex-col gap-2">
            {feedback.options.map((option, idx) => {
              const isCorrectOption = idx === feedback.correctOption;
              const isSelectedOption = idx === feedback.selectedOption;
              const isWrongSelected = isSelectedOption && !isCorrect;
              let cls = 'option-idle opacity-50';
              if (isCorrectOption) cls = 'option-correct';
              else if (isWrongSelected) cls = 'option-wrong';
              return (
                <div key={`fb-opt-${idx}`} className={`flex items-start gap-3 p-3 rounded-xl border ${cls}`}>
                  <span className={`w-6 h-6 rounded-lg flex items-center justify-center text-xs font-bold flex-shrink-0 ${isCorrectOption ? 'bg-success text-white' : isWrongSelected ? 'bg-danger text-white' : 'bg-muted text-muted-foreground'}`}>
                    {optionLabels[idx]}
                  </span>
                  <span className="text-sm text-foreground leading-relaxed pt-0.5 flex-1">{option}</span>
                  {isCorrectOption && <CheckCircle2 size={15} className="text-success flex-shrink-0 mt-0.5" />}
                  {isWrongSelected && <XCircle size={15} className="text-danger flex-shrink-0 mt-0.5" />}
                </div>
              );
            })}
          </div>
        </div>

        {/* Explanation */}
        <div className="card-elevated p-5 mb-5">
          <p className="text-xs font-bold uppercase tracking-widest text-muted-foreground mb-2">Explanation</p>
          <p className="text-sm text-foreground leading-relaxed">{feedback.explanation}</p>
        </div>

        <div className="flex justify-end">
          <button onClick={onNext} className="btn-primary flex items-center gap-2 px-6 py-3 text-sm">
            {isLastQuestion ? 'View Practice Summary' : 'Next Question'}
            <ChevronRight size={16} />
          </button>
        </div>
      </div>
    );
  }

  if (!question) return null;

  // Question view
  return (
    <div className="max-w-3xl mx-auto fade-in-up">
      {/* Question header */}
      <div className="flex items-start justify-between gap-4 mb-5">
        <div className="flex items-center gap-2 flex-wrap">
          <span className="font-mono-data text-sm font-bold text-muted-foreground">
            Question {session.currentQuestion} of {session.config.questionCount}
          </span>
          <Badge variant={difficultyVariant} size="sm">{question.difficulty}</Badge>
          <div className="flex items-center gap-1 px-2 py-0.5 rounded-full bg-muted border border-border">
            <BookOpen size={10} className="text-muted-foreground" />
            <span className="text-[11px] text-muted-foreground font-medium">{question.topic}</span>
          </div>
        </div>
        <QuestionTimer
          key={`ptimer-q${session.currentQuestion}`}
          totalSeconds={question.timeLimit}
          stopped={timerStopped}
          onTimeout={handleTimeout}
          onTick={handleTick}
        />
      </div>

      {/* Question Card */}
      <div className="card-elevated p-6 mb-5">
        <p className="text-base font-medium text-foreground leading-relaxed">{question.text}</p>
      </div>

      {/* Options */}
      <div className="flex flex-col gap-3 mb-5">
        {question.options.map((option, idx) => {
          const optionKeys = ['A', 'B', 'C', 'D'];
          const isSelected = selectedOption === idx;
          const optionClass = !timerStopped
            ? isSelected ? 'option-selected' : 'option-idle cursor-pointer' : isSelected ?'option-selected' : 'option-idle opacity-60 cursor-not-allowed';
          return (
            <button
              key={`popt-${session.currentQuestion}-${idx}`}
              onClick={() => handleOptionSelect(idx)}
              disabled={timerStopped}
              className={`flex items-start gap-4 p-4 rounded-xl text-left transition-all duration-150 w-full ${optionClass}`}
            >
              <span className={`w-7 h-7 rounded-lg flex items-center justify-center text-xs font-bold flex-shrink-0 mt-0.5 ${isSelected ? 'bg-primary text-white' : 'bg-muted text-muted-foreground'}`}>
                {optionKeys[idx]}
              </span>
              <span className="text-sm text-foreground leading-relaxed pt-0.5 flex-1">{option}</span>
            </button>
          );
        })}
      </div>

      {/* Hint Section */}
      <div className="card-elevated p-4">
        {!showHint ? (
          <button
            onClick={handleRequestHint}
            disabled={timerStopped}
            className="flex items-center gap-2.5 w-full text-left group"
          >
            <div className="w-8 h-8 rounded-lg bg-accent/15 flex items-center justify-center flex-shrink-0 group-hover:bg-accent/25 transition-colors">
              <Lightbulb size={15} className="text-accent" />
            </div>
            <div>
              <p className="text-sm font-semibold text-foreground">Need a hint?</p>
              <p className="text-xs text-muted-foreground">Guided hint — won't reveal the answer</p>
            </div>
            <span className="ml-auto text-xs text-accent font-semibold">Show Hint →</span>
          </button>
        ) : (
          <div>
            <div className="flex items-center gap-2 mb-3">
              <div className="w-7 h-7 rounded-lg bg-accent/15 flex items-center justify-center flex-shrink-0">
                <Lightbulb size={14} className="text-accent" />
              </div>
              <p className="text-xs font-bold text-accent uppercase tracking-widest">Hint</p>
            </div>
            {hintLoading ? (
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <Loader2 size={14} className="animate-spin" />
                Loading hint...
              </div>
            ) : (
              <p className="text-sm text-foreground leading-relaxed">{hintText || 'Think about the core concept this question is testing.'}</p>
            )}
          </div>
        )}
      </div>
    </div>
  );
}