'use client';
import PracticeQuestion from './PracticeQuestion';
export default PracticeQuestion;