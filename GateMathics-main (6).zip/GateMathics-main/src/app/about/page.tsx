import React from 'react';
import type { Metadata } from 'next';
import AppLayout from '@/components/AppLayout';
import { PAGE_SEO } from '@/lib/seo/gateSeoConfig';
import AboutContent from './AboutContent';

export const metadata: Metadata = PAGE_SEO.about;

export default function AboutPage() {
  return (
    <AppLayout>
      <AboutContent />
    </AppLayout>
  );
}
