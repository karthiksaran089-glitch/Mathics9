'use client';

import React from 'react';
import AdUnit from '@/components/adsense/AdUnit';
import { adsenseConfig } from '@/config/adsense.config';
import { Trophy, BookOpen, BarChart3, Zap, Target, Users } from 'lucide-react';
import Icon from '@/components/ui/AppIcon';


const features = [
  {
    icon: Trophy,
    title: 'Ranked Mode',
    desc: 'Compete in real-time ranked quizzes. Earn LP, climb tiers from Bronze to Grandmaster, and benchmark yourself against GATE CS aspirants nationwide.',
  },
  {
    icon: BookOpen,
    title: 'Practice Mode',
    desc: 'Topic-wise practice sessions covering all GATE CS subjects — Algorithms, OS, DBMS, Computer Networks, Theory of Computation, and more.',
  },
  {
    icon: BarChart3,
    title: 'Performance Analytics',
    desc: 'Deep-dive analytics to identify weak topics, track accuracy trends, and optimize your GATE CS preparation strategy with data-driven insights.',
  },
  {
    icon: Zap,
    title: 'AI Question Engine',
    desc: 'Adaptive question generation powered by AI, ensuring you always face fresh, relevant GATE-standard questions tailored to your skill level.',
  },
  {
    icon: Target,
    title: 'Fallback Question Bank',
    desc: 'Curated offline question banks for Ranked and Practice modes ensure uninterrupted quizzes even when the AI engine is unavailable.',
  },
  {
    icon: Users,
    title: 'Community-Driven',
    desc: 'Built for and with GATE CS aspirants. Continuous improvements based on real user feedback and GATE exam pattern analysis.',
  },
];

const topics = [
  'Data Structures & Algorithms',
  'Operating Systems',
  'Database Management Systems',
  'Computer Networks',
  'Theory of Computation',
  'Compiler Design',
  'Digital Logic',
  'Computer Organization & Architecture',
  'Discrete Mathematics',
  'Engineering Mathematics',
];

export default function AboutContent() {
  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Header */}
      <div className="border-b border-border px-6 py-8 md:px-10">
        <h1 className="text-3xl md:text-4xl font-extrabold tracking-tight text-foreground">
          About <span className="text-gradient-primary">GateMathics</span>
        </h1>
        <p className="mt-2 text-muted-foreground max-w-2xl">
          The most engaging GATE CS preparation platform — built to make your rank climb addictive.
        </p>
      </div>
      <div className="px-6 py-8 md:px-10 max-w-5xl mx-auto space-y-12">

        {/* Mission */}
        <section>
          <h2 className="text-xl font-bold text-foreground mb-3">Our Mission</h2>
          <p className="text-muted-foreground leading-relaxed">
            GateMathics was built with a single goal: make GATE CS preparation as engaging as a competitive game.
            Traditional mock tests are passive — you answer questions, see a score, and move on. We believe preparation
            should feel like progression. Every question you answer earns you LP. Every session moves your rank. Every
            topic you master shows up in your analytics.
          </p>
          <p className="text-muted-foreground leading-relaxed mt-3">
            We cover the complete GATE CS 2025 syllabus with thousands of questions across all topics, difficulty levels,
            and question types — from single-correct MCQs to numerical answer type (NAT) problems.
          </p>
        </section>

        {/* Ad — In Article */}
        <AdUnit
          adClient={adsenseConfig?.client}
          adSlot={adsenseConfig?.slots?.inArticle}
          adFormat="auto"
          className="my-2"
        />

        {/* Features */}
        <section>
          <h2 className="text-xl font-bold text-foreground mb-6">What We Offer</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {features?.map((f) => {
              const Icon = f?.icon;
              return (
                <div
                  key={f?.title}
                  className="bg-card border border-border rounded-xl p-5 hover:border-primary/40 transition-colors"
                >
                  <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center mb-3">
                    <Icon size={20} className="text-primary" />
                  </div>
                  <h3 className="font-semibold text-foreground mb-1">{f?.title}</h3>
                  <p className="text-sm text-muted-foreground leading-relaxed">{f?.desc}</p>
                </div>
              );
            })}
          </div>
        </section>

        {/* Topics Covered */}
        <section>
          <h2 className="text-xl font-bold text-foreground mb-4">GATE CS Topics Covered</h2>
          <div className="flex flex-wrap gap-2">
            {topics?.map((t) => (
              <span
                key={t}
                className="px-3 py-1.5 rounded-full bg-muted text-sm text-foreground font-medium border border-border"
              >
                {t}
              </span>
            ))}
          </div>
        </section>

        {/* Ad — Footer */}
        <AdUnit
          adClient={adsenseConfig?.client}
          adSlot={adsenseConfig?.slots?.footer}
          adFormat="auto"
          className="my-2"
        />

        {/* Why Free */}
        <section>
          <h2 className="text-xl font-bold text-foreground mb-3">Why Is GateMathics Free?</h2>
          <p className="text-muted-foreground leading-relaxed">
            We believe quality GATE CS preparation should be accessible to every aspirant regardless of financial
            background. GateMathics is free to use and supported by non-intrusive advertisements. Ad revenue helps us
            maintain servers, improve the AI question engine, and keep adding new content.
          </p>
          <p className="text-muted-foreground leading-relaxed mt-3">
            We are committed to keeping the core platform — Ranked Mode, Practice Mode, and Analytics — completely free
            forever.
          </p>
        </section>

        {/* Team */}
        <section className="pb-8">
          <h2 className="text-xl font-bold text-foreground mb-3">Built by GATE Aspirants</h2>
          <p className="text-muted-foreground leading-relaxed">
            GateMathics was created by engineers who went through the GATE preparation grind and wanted a better tool.
            We understand the syllabus, the exam pattern, and the mental challenge of staying consistent over months of
            preparation. Every feature on this platform was designed to solve a real problem we faced ourselves.
          </p>
          <p className="text-muted-foreground leading-relaxed mt-3">
            Have feedback, suggestions, or want to contribute questions?{' '}
            <a href="/contact" className="text-primary hover:underline font-medium">
              Reach out to us
            </a>
            .
          </p>
        </section>
      </div>
    </div>
  );
}
