import React from 'react';
import type { Metadata } from 'next';
import AppLayout from '@/components/AppLayout';
import { PAGE_SEO } from '@/lib/seo/gateSeoConfig';
import ContactContent from './ContactContent';

export const metadata: Metadata = PAGE_SEO.contact;

export default function ContactPage() {
  return (
    <AppLayout>
      <ContactContent />
    </AppLayout>
  );
}
