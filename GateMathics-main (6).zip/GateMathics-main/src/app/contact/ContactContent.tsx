'use client';

import React, { useState } from 'react';
import AdUnit from '@/components/adsense/AdUnit';
import { adsenseConfig } from '@/config/adsense.config';
import { Mail, MessageSquare, Bug, Lightbulb, Send, CheckCircle } from 'lucide-react';
import Icon from '@/components/ui/AppIcon';


const contactReasons = [
  { icon: Bug, label: 'Report a Bug', value: 'bug' },
  { icon: Lightbulb, label: 'Feature Request', value: 'feature' },
  { icon: MessageSquare, label: 'General Feedback', value: 'feedback' },
  { icon: Mail, label: 'Other', value: 'other' },
];

export default function ContactContent() {
  const [form, setForm] = useState({ name: '', email: '', reason: 'feedback', message: '' });
  const [submitted, setSubmitted] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>
  ) => {
    setForm((prev) => ({ ...prev, [e.target.name]: e.target.value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    // Simulate submission — replace with actual API call or Supabase insert
    await new Promise((r) => setTimeout(r, 1000));
    setLoading(false);
    setSubmitted(true);
  };

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Header */}
      <div className="border-b border-border px-6 py-8 md:px-10">
        <h1 className="text-3xl md:text-4xl font-extrabold tracking-tight text-foreground">
          Contact <span className="text-gradient-primary">Us</span>
        </h1>
        <p className="mt-2 text-muted-foreground max-w-xl">
          Have a question, found a bug, or want to suggest a feature? We read every message.
        </p>
      </div>

      <div className="px-6 py-8 md:px-10 max-w-3xl mx-auto space-y-10">

        {/* Ad — Leaderboard */}
        <AdUnit
          adClient={adsenseConfig.client}
          adSlot={adsenseConfig.slots.leaderboard}
          adFormat="auto"
          className="mb-2"
        />

        {submitted ? (
          <div className="flex flex-col items-center justify-center py-16 gap-4 text-center">
            <CheckCircle size={48} className="text-success" />
            <h2 className="text-xl font-bold text-foreground">Message Received!</h2>
            <p className="text-muted-foreground max-w-sm">
              Thanks for reaching out. We typically respond within 24–48 hours. Keep grinding those GATE CS questions!
            </p>
            <button
              onClick={() => { setSubmitted(false); setForm({ name: '', email: '', reason: 'feedback', message: '' }); }}
              className="mt-2 px-5 py-2.5 rounded-lg bg-primary text-primary-foreground font-semibold text-sm hover:opacity-90 transition-opacity"
            >
              Send Another Message
            </button>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-5">
            {/* Reason selector */}
            <div>
              <label className="block text-sm font-semibold text-foreground mb-2">
                What can we help with?
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                {contactReasons.map((r) => {
                  const Icon = r.icon;
                  const active = form.reason === r.value;
                  return (
                    <button
                      key={r.value}
                      type="button"
                      onClick={() => setForm((p) => ({ ...p, reason: r.value }))}
                      className={`flex flex-col items-center gap-1.5 p-3 rounded-xl border text-sm font-medium transition-all ${
                        active
                          ? 'border-primary bg-primary/10 text-primary' :'border-border bg-card text-muted-foreground hover:border-primary/40 hover:text-foreground'
                      }`}
                    >
                      <Icon size={18} />
                      {r.label}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Name */}
            <div>
              <label htmlFor="name" className="block text-sm font-semibold text-foreground mb-1.5">
                Your Name
              </label>
              <input
                id="name"
                name="name"
                type="text"
                required
                value={form.name}
                onChange={handleChange}
                placeholder="e.g. Arjun Sharma"
                className="w-full px-4 py-2.5 rounded-lg bg-card border border-border text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-primary text-sm transition-colors"
              />
            </div>

            {/* Email */}
            <div>
              <label htmlFor="email" className="block text-sm font-semibold text-foreground mb-1.5">
                Email Address
              </label>
              <input
                id="email"
                name="email"
                type="email"
                required
                value={form.email}
                onChange={handleChange}
                placeholder="you@example.com"
                className="w-full px-4 py-2.5 rounded-lg bg-card border border-border text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-primary text-sm transition-colors"
              />
            </div>

            {/* Message */}
            <div>
              <label htmlFor="message" className="block text-sm font-semibold text-foreground mb-1.5">
                Message
              </label>
              <textarea
                id="message"
                name="message"
                required
                rows={5}
                value={form.message}
                onChange={handleChange}
                placeholder="Describe your issue or suggestion in detail..."
                className="w-full px-4 py-2.5 rounded-lg bg-card border border-border text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-primary text-sm transition-colors resize-none"
              />
            </div>

            <button
              type="submit"
              disabled={loading}
              className="flex items-center gap-2 px-6 py-2.5 rounded-lg bg-primary text-primary-foreground font-semibold text-sm hover:opacity-90 transition-opacity disabled:opacity-60"
            >
              {loading ? (
                <span className="w-4 h-4 border-2 border-white/40 border-t-white rounded-full animate-spin" />
              ) : (
                <Send size={16} />
              )}
              {loading ? 'Sending…' : 'Send Message'}
            </button>
          </form>
        )}

        {/* Ad — Footer */}
        <AdUnit
          adClient={adsenseConfig.client}
          adSlot={adsenseConfig.slots.footer}
          adFormat="auto"
          className="mt-4"
        />

        {/* Direct contact info */}
        <div className="pb-8 border-t border-border pt-6">
          <p className="text-sm text-muted-foreground">
            Prefer email?{' '}
            <a href="mailto:support@gatemathics.com" className="text-primary hover:underline font-medium">
              support@gatemathics.com
            </a>
          </p>
          <p className="text-xs text-muted-foreground mt-1">
            Response time: 24–48 hours on business days.
          </p>
        </div>
      </div>
    </div>
  );
}
