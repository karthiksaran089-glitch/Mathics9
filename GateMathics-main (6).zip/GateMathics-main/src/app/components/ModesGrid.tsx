import React from 'react';
import Link from 'next/link';
import { ChevronRight, Swords, Brain, TrendingUp } from 'lucide-react';
import Icon from '@/components/ui/AppIcon';


const modes = [
  {
    key: 'mode-ranked',
    href: '/ranked-mode-screen',
    icon: Swords,
    label: 'Ranked Mode',
    tagline: 'Compete. Earn LP. Rise.',
    description:
      'Draft topics, wager League Points, and answer 10 timed GATE-level questions. Win LP to climb from Bronze to Grandmaster.',
    cardClass: 'mode-card-ranked',
    iconColor: 'text-primary',
    ctaLabel: 'Start Ranked Match',
    stats: [
      { label: 'Your best run', value: '+180 LP' },
      { label: 'Avg accuracy', value: '72%' },
    ],
    badge: 'COMPETITIVE',
    badgeColor: 'bg-primary/20 text-primary',
  },
  {
    key: 'mode-practice',
    href: '/practice',
    icon: Brain,
    label: 'Practice Mode',
    tagline: 'Focus. Learn. Master.',
    description:
      'Configure your topic mix, difficulty, and question count. AI-assisted questions adapt to your weak areas with detailed explanations.',
    cardClass: 'mode-card-practice',
    iconColor: 'text-info',
    ctaLabel: 'Configure Practice',
    stats: [
      { label: 'Questions today', value: '34' },
      { label: 'Topics covered', value: '5' },
    ],
    badge: 'STUDY',
    badgeColor: 'bg-info/20 text-info',
  },
  {
    key: 'mode-analytics',
    href: '/analytics',
    icon: TrendingUp,
    label: 'Analytics',
    tagline: 'Diagnose. Improve. Win.',
    description:
      'Deep-dive into your LP trend, topic mastery radar, answer speed distribution, and session history to find and fix gaps.',
    cardClass: 'mode-card-analytics',
    iconColor: 'text-accent',
    ctaLabel: 'View Dashboard',
    stats: [
      { label: 'Overall accuracy', value: '74.2%' },
      { label: 'Weak topic', value: 'TOC' },
    ],
    badge: 'INSIGHTS',
    badgeColor: 'bg-accent/20 text-accent',
  },
];

export default function ModesGrid() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4 mb-6">
      {modes?.map((mode) => {
        const Icon = mode?.icon;
        return (
          <Link
            key={mode?.key}
            href={mode?.href}
            className={`${mode?.cardClass} rounded-xl p-5 transition-all duration-200 group cursor-pointer block`}
          >
            <div className="flex items-start justify-between mb-3">
              <div className={`w-10 h-10 rounded-xl bg-card flex items-center justify-center ${mode?.iconColor}`}>
                <Icon size={20} />
              </div>
              <span className={`text-[10px] font-bold tracking-widest px-2 py-0.5 rounded-full ${mode?.badgeColor}`}>
                {mode?.badge}
              </span>
            </div>
            <h3 className="text-base font-bold text-foreground mb-0.5">{mode?.label}</h3>
            <p className="text-xs font-semibold text-muted-foreground mb-2">{mode?.tagline}</p>
            <p className="text-xs text-muted-foreground leading-relaxed mb-4">{mode?.description}</p>
            <div className="flex items-center gap-4 mb-4">
              {mode?.stats?.map((stat) => (
                <div key={`${mode?.key}-stat-${stat?.label}`}>
                  <p className="text-[10px] text-muted-foreground">{stat?.label}</p>
                  <p className="text-sm font-bold text-foreground font-mono-data">{stat?.value}</p>
                </div>
              ))}
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm font-semibold text-foreground group-hover:text-primary transition-colors">
                {mode?.ctaLabel}
              </span>
              <ChevronRight
                size={16}
                className="text-muted-foreground group-hover:text-primary group-hover:translate-x-1 transition-all duration-150"
              />
            </div>
          </Link>
        );
      })}
    </div>
  );
}