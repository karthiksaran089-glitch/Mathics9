'use client';
import React, { useEffect, useState } from 'react';
import Link from 'next/link';
import { Flame, Star, Swords, Brain, TrendingUp, User, ChevronRight, Zap } from 'lucide-react';
import { createClient } from '@/lib/supabase/client';
import Badge from '@/components/ui/Badge';

interface UserStats {
  display_name: string;
  rank: string;
  lp: number;
  daily_streak: number;
  overall_accuracy: number;
}

const DEFAULT_STATS: UserStats = {
  display_name: 'User',
  rank: 'Silver',
  lp: 0,
  daily_streak: 0,
  overall_accuracy: 0,
};

const navButtons = [
  {
    key: 'nav-practice',
    href: '/practice',
    icon: Brain,
    label: 'Practice Mode',
    tagline: 'Focus. Learn. Master.',
    description: 'Configure topics, difficulty, and question count. AI-assisted hints included.',
    badge: 'STUDY',
    badgeColor: 'bg-info/20 text-info',
    iconColor: 'text-info',
    cardClass: 'mode-card-practice',
    cta: 'Start Practice',
  },
  {
    key: 'nav-analytics',
    href: '/analytics',
    icon: TrendingUp,
    label: 'Analytics',
    tagline: 'Diagnose. Improve. Win.',
    description: 'Deep-dive into LP trend, topic mastery, answer speed, and session history.',
    badge: 'INSIGHTS',
    badgeColor: 'bg-accent/20 text-accent',
    iconColor: 'text-accent',
    cardClass: 'mode-card-analytics',
    cta: 'View Dashboard',
  },
  {
    key: 'nav-profile',
    href: '/profile',
    icon: User,
    label: 'Profile',
    tagline: 'Track. Manage. Grow.',
    description: 'View your account details, rank progress, and edit profile settings.',
    badge: 'ACCOUNT',
    badgeColor: 'bg-primary/20 text-primary',
    iconColor: 'text-primary',
    cardClass: 'mode-card-ranked',
    cta: 'View Profile',
  },
];

export default function HomeDashboardContent() {
  const [stats, setStats] = useState<UserStats>(DEFAULT_STATS);
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
    const supabase = createClient();
    if (!supabase) return;
    let cleanupFn: (() => void) | undefined;
    supabase.auth.getUser().then(async ({ data: { user } }: any) => {
      if (!user) return;
      const { data } = await supabase
        .from('user_profiles')
        .select('display_name, rank, lp, daily_streak, overall_accuracy')
        .eq('id', user.id)
        .single();
      if (data) {
        setStats({
          display_name: data.display_name || user.email?.split('@')[0] || 'User',
          rank: data.rank || 'Silver',
          lp: data.lp ?? 0,
          daily_streak: data.daily_streak ?? 0,
          overall_accuracy: data.overall_accuracy ?? 0,
        });
      }

      const channel = supabase.channel('home_profile_sync')
        .on('postgres_changes', {
          event: '*',
          schema: 'public',
          table: 'user_profiles',
          filter: `id=eq.${user.id}`
        }, (payload: any) => {
          const newData = payload.new;
          if (newData) {
            setStats(prev => ({
              ...prev,
              display_name: newData.display_name || prev.display_name,
              rank: newData.rank || prev.rank,
              lp: newData.lp ?? prev.lp,
              daily_streak: newData.daily_streak ?? prev.daily_streak,
              overall_accuracy: newData.overall_accuracy ?? prev.overall_accuracy,
            }));
          }
        })
        .subscribe();

      cleanupFn = () => {
        supabase.removeChannel(channel);
      };
    });

    return () => {
      if (cleanupFn) cleanupFn();
    };
  }, []);

  const firstName = stats.display_name.split(' ')[0];
  const rankColor =
    stats.rank === 'Gold' ? 'text-rank-gold' :
    stats.rank === 'Silver' ? 'text-rank-silver' :
    stats.rank === 'Bronze' ? 'text-rank-bronze' :
    stats.rank === 'Grandmaster'? 'text-danger' : 'text-rank-silver';

  const statCards = [
    {
      id: 'sc-rank',
      label: 'Current Rank',
      value: mounted ? stats.rank : '—',
      color: rankColor,
      icon: Star,
      iconColor: 'text-rank-silver',
    },
    {
      id: 'sc-lp',
      label: 'League Points',
      value: mounted ? `${stats.lp} LP` : '—',
      color: 'text-accent',
      icon: Zap,
      iconColor: 'text-accent',
    },
    {
      id: 'sc-streak',
      label: 'Daily Streak',
      value: mounted ? `${stats.daily_streak} days` : '—',
      color: 'text-warning',
      icon: Flame,
      iconColor: 'text-warning',
    },
    {
      id: 'sc-accuracy',
      label: 'Overall Accuracy',
      value: mounted ? `${stats.overall_accuracy.toFixed(1)}%` : '—',
      color: 'text-success',
      icon: TrendingUp,
      iconColor: 'text-success',
    },
  ];

  return (
    <div className="w-full px-4 py-4 lg:p-6 lg:max-w-screen-2xl lg:mx-auto">
      {/* Welcome Hero */}
      <div className="card-elevated p-6 mb-6 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-full opacity-5 pointer-events-none">
          <div className="absolute top-4 right-8 w-32 h-32 rounded-full bg-primary blur-3xl" />
          <div className="absolute bottom-4 right-20 w-24 h-24 rounded-full bg-accent blur-2xl" />
        </div>
        <div className="relative">
          <div className="flex items-center gap-2 mb-2">
            {mounted && stats.daily_streak > 0 && (
              <Badge variant="warning" size="sm">
                <Flame size={10} />
                {stats.daily_streak}-day streak
              </Badge>
            )}
            <Badge variant="silver" size="sm">
              <Star size={10} />
              {mounted ? stats.rank : 'Silver'}
            </Badge>
          </div>
          <h1 className="text-2xl font-bold text-foreground mt-1">
            Welcome back, <span className="text-gradient-primary">{mounted ? firstName : 'there'}</span> 👋
          </h1>
          <p className="text-sm text-muted-foreground mt-1.5 max-w-lg">
            You&apos;re currently ranked{' '}
            <span className={`font-semibold ${rankColor}`}>{mounted ? stats.rank : 'Silver'}</span> with{' '}
            <span className="text-accent font-semibold">{mounted ? stats.lp : 0} LP</span>.{' '}
            Keep practicing to climb the leaderboard!
          </p>
        </div>
      </div>

      {/* Quick Stat Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-6">
        {statCards.map((card) => {
          const CardIcon = card.icon;
          return (
            <div key={card.id} className="card-elevated p-4 flex flex-col gap-2">
              <div className="flex items-center justify-between">
                <p className="text-xs text-muted-foreground">{card.label}</p>
                <CardIcon size={14} className={card.iconColor} />
              </div>
              {!mounted ? (
                <div className="h-7 w-16 rounded bg-muted animate-pulse" />
              ) : (
                <p className={`text-xl font-bold font-mono-data ${card.color}`}>{card.value}</p>
              )}
            </div>
          );
        })}
      </div>

      {/* Ranked Mode CTA */}
      <Link
        href="/ranked-mode-screen"
        className="mode-card-ranked rounded-xl p-5 mb-6 flex items-center justify-between group cursor-pointer block"
      >
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-card flex items-center justify-center text-primary">
            <Swords size={24} />
          </div>
          <div>
            <span className="text-[10px] font-bold tracking-widest px-2 py-0.5 rounded-full bg-primary/20 text-primary">
              COMPETITIVE
            </span>
            <h3 className="text-base font-bold text-foreground mt-1">Ranked Mode</h3>
            <p className="text-xs text-muted-foreground">Compete. Earn LP. Rise.</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-sm font-semibold text-foreground group-hover:text-primary transition-colors hidden sm:block">
            Start Ranked Match
          </span>
          <ChevronRight
            size={18}
            className="text-muted-foreground group-hover:text-primary group-hover:translate-x-1 transition-all duration-150"
          />
        </div>
      </Link>

      {/* Navigation Buttons */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {navButtons.map((btn) => {
          const BtnIcon = btn.icon;
          return (
            <Link
              key={btn.key}
              href={btn.href}
              className={`${btn.cardClass} rounded-xl p-5 transition-all duration-200 group cursor-pointer block`}
            >
              <div className="flex items-start justify-between mb-3">
                <div className={`w-10 h-10 rounded-xl bg-card flex items-center justify-center ${btn.iconColor}`}>
                  <BtnIcon size={20} />
                </div>
                <span className={`text-[10px] font-bold tracking-widest px-2 py-0.5 rounded-full ${btn.badgeColor}`}>
                  {btn.badge}
                </span>
              </div>
              <h3 className="text-base font-bold text-foreground mb-0.5">{btn.label}</h3>
              <p className="text-xs font-semibold text-muted-foreground mb-2">{btn.tagline}</p>
              <p className="text-xs text-muted-foreground leading-relaxed mb-4">{btn.description}</p>
              <div className="flex items-center justify-between">
                <span className="text-sm font-semibold text-foreground group-hover:text-primary transition-colors">
                  {btn.cta}
                </span>
                <ChevronRight
                  size={16}
                  className="text-muted-foreground group-hover:text-primary group-hover:translate-x-1 transition-all duration-150"
                />
              </div>
            </Link>
          );
        })}
      </div>
    </div>
  );
}