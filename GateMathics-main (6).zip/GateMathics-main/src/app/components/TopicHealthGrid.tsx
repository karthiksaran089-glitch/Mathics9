'use client';
import React from 'react';
import { AlertTriangle } from 'lucide-react';

const topics = [
  { id: 'topic-os', name: 'Operating Systems', short: 'OS', accuracy: 78, sessions: 12, trend: 'up' },
  { id: 'topic-dbms', name: 'DBMS', short: 'DBMS', accuracy: 82, sessions: 9, trend: 'up' },
  { id: 'topic-algo', name: 'Algorithms', short: 'Algo', accuracy: 71, sessions: 15, trend: 'down' },
  { id: 'topic-ds', name: 'Data Structures', short: 'DS', accuracy: 85, sessions: 18, trend: 'up' },
  { id: 'topic-cn', name: 'Computer Networks', short: 'CN', accuracy: 67, sessions: 8, trend: 'down' },
  { id: 'topic-toc', name: 'Theory of Computation', short: 'TOC', accuracy: 61, sessions: 7, trend: 'down' },
  { id: 'topic-co', name: 'Computer Organisation', short: 'CO', accuracy: 74, sessions: 6, trend: 'neutral' },
  { id: 'topic-dm', name: 'Discrete Mathematics', short: 'DM', accuracy: 69, sessions: 10, trend: 'down' },
  { id: 'topic-pl', name: 'Programming Languages', short: 'PL', accuracy: 80, sessions: 5, trend: 'up' },
  { id: 'topic-cd', name: 'Compiler Design', short: 'CD', accuracy: 55, sessions: 4, trend: 'down' },
  { id: 'topic-se', name: 'Software Engineering', short: 'SE', accuracy: 88, sessions: 11, trend: 'up' },
  { id: 'topic-ai', name: 'Artificial Intelligence', short: 'AI', accuracy: 73, sessions: 3, trend: 'neutral' },
];

function getAccuracyColor(accuracy: number) {
  if (accuracy >= 80) return 'text-success';
  if (accuracy >= 65) return 'text-accent';
  return 'text-danger';
}

function getBarColor(accuracy: number) {
  if (accuracy >= 80) return 'bg-success';
  if (accuracy >= 65) return 'bg-accent';
  return 'bg-danger';
}

export default function TopicHealthGrid() {
  return (
    <div className="card-elevated p-5">
      <div className="flex items-center justify-between mb-4">
        <div>
          <h2 className="text-base font-semibold text-foreground">Topic Health</h2>
          <p className="text-xs text-muted-foreground mt-0.5">Accuracy across all GATE CS subjects</p>
        </div>
        <div className="flex items-center gap-1.5 text-xs text-warning">
          <AlertTriangle size={13} />
          <span className="font-medium">3 topics need attention</span>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 2xl:grid-cols-4 gap-3">
        {topics.map((topic) => (
          <div
            key={topic.id}
            className="flex flex-col gap-2 p-3 rounded-lg bg-muted/50 hover:bg-muted transition-colors"
          >
            <div className="flex items-center justify-between gap-2">
              <span className="text-xs font-semibold text-foreground flex-1 min-w-0" title={topic.name}>
                {topic.name}
              </span>
              <span className={`text-xs font-bold font-mono-data flex-shrink-0 ${getAccuracyColor(topic.accuracy)}`}>
                {topic.accuracy}%
              </span>
            </div>
            <div className="progress-bar-bg h-1.5">
              <div
                className={`h-1.5 rounded-full transition-all duration-700 ${getBarColor(topic.accuracy)}`}
                style={{ width: `${topic.accuracy}%` }}
              />
            </div>
            <div className="flex items-center justify-between">
              <span className="text-[10px] text-muted-foreground">{topic.sessions} sessions</span>
              <span className={`text-[10px] font-medium ${
                topic.trend === 'up' ? 'text-success' : topic.trend === 'down' ? 'text-danger' : 'text-muted-foreground'
              }`}>
                {topic.trend === 'up' ? '↑ improving' : topic.trend === 'down' ? '↓ declining' : '→ stable'}
              </span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}