import React from 'react';
import Badge from '@/components/ui/Badge';
import { Trophy, BookOpen, Clock } from 'lucide-react';

const sessions = [
  {
    id: 'session-001',
    mode: 'Ranked',
    topics: ['Algorithms', 'Data Structures'],
    accuracy: 80,
    lpDelta: +60,
    questionsAnswered: 10,
    avgSpeed: '28s',
    completedAt: '2h ago',
  },
  {
    id: 'session-002',
    mode: 'Practice',
    topics: ['Operating Systems'],
    accuracy: 73,
    lpDelta: null,
    questionsAnswered: 15,
    avgSpeed: '34s',
    completedAt: '5h ago',
  },
  {
    id: 'session-003',
    mode: 'Ranked',
    topics: ['DBMS', 'Computer Networks'],
    accuracy: 60,
    lpDelta: -40,
    questionsAnswered: 10,
    avgSpeed: '41s',
    completedAt: 'Yesterday',
  },
  {
    id: 'session-004',
    mode: 'Practice',
    topics: ['Theory of Computation', 'Compiler Design'],
    accuracy: 58,
    lpDelta: null,
    questionsAnswered: 12,
    avgSpeed: '47s',
    completedAt: 'Yesterday',
  },
  {
    id: 'session-005',
    mode: 'Ranked',
    topics: ['Discrete Mathematics'],
    accuracy: 90,
    lpDelta: +120,
    questionsAnswered: 10,
    avgSpeed: '22s',
    completedAt: '2 days ago',
  },
];

export default function RecentSessionsFeed() {
  return (
    <div className="card-elevated p-5 mb-6">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-base font-semibold text-foreground">Recent Sessions</h2>
        <button className="text-xs text-primary hover:text-primary/80 font-medium transition-colors">
          View all →
        </button>
      </div>
      <div className="flex flex-col gap-2">
        {sessions?.map((session) => (
          <div
            key={session?.id}
            className="flex items-center gap-3 p-3 rounded-lg hover:bg-muted/50 transition-colors group"
          >
            {/* Mode icon */}
            <div className={`w-9 h-9 rounded-lg flex items-center justify-center flex-shrink-0 ${
              session?.mode === 'Ranked' ? 'bg-primary/15 text-primary' : 'bg-info/15 text-info'
            }`}>
              {session?.mode === 'Ranked' ? <Trophy size={16} /> : <BookOpen size={16} />}
            </div>

            {/* Session info */}
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 mb-0.5">
                <span className="text-sm font-semibold text-foreground">{session?.mode} Session</span>
                <Badge variant={session?.mode === 'Ranked' ? 'default' : 'info'} size="sm">
                  {session?.mode}
                </Badge>
              </div>
              <div className="flex items-center gap-2 flex-wrap">
                {session?.topics?.map((t) => (
                  <span key={`${session?.id}-topic-${t}`} className="text-[11px] text-muted-foreground">
                    {t}
                  </span>
                ))}
              </div>
            </div>

            {/* Stats */}
            <div className="hidden sm:flex items-center gap-4 flex-shrink-0">
              <div className="text-right">
                <p className="text-[10px] text-muted-foreground">Accuracy</p>
                <p className={`text-xs font-bold font-mono-data ${
                  session?.accuracy >= 75 ? 'text-success' : session?.accuracy >= 60 ? 'text-accent' : 'text-danger'
                }`}>
                  {session?.accuracy}%
                </p>
              </div>
              <div className="text-right">
                <p className="text-[10px] text-muted-foreground">Avg Speed</p>
                <div className="flex items-center gap-0.5 justify-end">
                  <Clock size={10} className="text-muted-foreground" />
                  <p className="text-xs font-bold font-mono-data text-foreground">{session?.avgSpeed}</p>
                </div>
              </div>
              {session?.lpDelta !== null && (
                <div className="text-right min-w-[52px]">
                  <p className="text-[10px] text-muted-foreground">LP</p>
                  <p className={`text-sm font-bold font-mono-data ${
                    session?.lpDelta > 0 ? 'text-success' : 'text-danger'
                  }`}>
                    {session?.lpDelta > 0 ? '+' : ''}{session?.lpDelta}
                  </p>
                </div>
              )}
              {session?.lpDelta === null && (
                <div className="min-w-[52px]" />
              )}
            </div>

            {/* Time */}
            <div className="text-right flex-shrink-0">
              <p className="text-[11px] text-muted-foreground">{session?.completedAt}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}