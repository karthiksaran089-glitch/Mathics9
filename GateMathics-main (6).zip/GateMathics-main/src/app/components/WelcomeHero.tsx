import React from 'react';

import { Zap, TrendingUp } from 'lucide-react';
import Badge from '@/components/ui/Badge';

export default function WelcomeHero() {
  return (
    <div className="card-elevated p-6 mb-6 relative overflow-hidden">
      {/* Background decoration */}
      <div className="absolute top-0 right-0 w-64 h-full opacity-5 pointer-events-none">
        <div className="absolute top-4 right-8 w-32 h-32 rounded-full bg-primary blur-3xl" />
        <div className="absolute bottom-4 right-20 w-24 h-24 rounded-full bg-accent blur-2xl" />
      </div>

      <div className="relative flex items-start justify-between">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <Badge variant="warning" size="sm">
              <Zap size={10} />
              12-day streak
            </Badge>
            <Badge variant="success" size="sm">↑ +42 LP today</Badge>
          </div>
          <h1 className="text-2xl font-bold text-foreground mt-2">
            Welcome back, <span className="text-gradient-primary">Arjun</span> 👋
          </h1>
          <p className="text-sm text-muted-foreground mt-1.5 max-w-lg">
            Your GATE exam is in <span className="text-accent font-semibold">87 days</span>. Today&apos;s recommended focus:{' '}
            <span className="text-info font-semibold">Theory of Computation</span> — your accuracy dipped to 61% last session.
          </p>
        </div>

        <div className="hidden lg:flex flex-col items-end gap-2">
          <div className="flex items-center gap-1.5 text-muted-foreground text-xs">
            <TrendingUp size={12} className="text-success" />
            <span>Rank progress: <span className="text-rank-silver font-semibold">847 / 1000 LP</span> to Gold</span>
          </div>
          <div className="w-48 h-2 progress-bar-bg">
            <div className="progress-bar-fill" style={{ width: '84.7%', height: '8px' }} />
          </div>
          <span className="text-[11px] text-muted-foreground">153 LP to Gold tier</span>
        </div>
      </div>
    </div>
  );
}