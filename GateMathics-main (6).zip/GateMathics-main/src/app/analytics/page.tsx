'use client';

import React, { useState, useEffect, useMemo } from 'react';
import {
  TrendingUp, Target, Zap, Flame, Trophy, Brain, Clock, BarChart3, Calendar,
  ChevronUp, ChevronDown, Minus, Star, BookOpen, Activity, ArrowRight,
  AlertTriangle, Lightbulb, Crosshair, Award, BookOpenCheck,
} from 'lucide-react';
import {
  AreaChart, Area, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
} from 'recharts';
import Badge from '@/components/ui/Badge';
import AppLayout from '@/components/AppLayout';
import { createClient } from '@/lib/supabase/client';
import { Skeleton as LoadingSkeleton } from '@/components/ui/LoadingSkeleton';

// ─── Rank Tiers ────────────────────────────────────────────────────────────────

const RANK_TIERS = [
  { name: 'Bronze', min: 0, max: 499, color: '#CD7F32', badgeClass: 'rank-badge-bronze' },
  { name: 'Silver', min: 500, max: 999, color: '#A8B8C8', badgeClass: 'rank-badge-silver' },
  { name: 'Gold', min: 1000, max: 1499, color: '#F59E0B', badgeClass: 'rank-badge-gold' },
  { name: 'Platinum', min: 1500, max: 1999, color: '#06B6D4', badgeClass: 'rank-badge-platinum' },
  { name: 'Diamond', min: 2000, max: 2499, color: '#818CF8', badgeClass: 'rank-badge-diamond' },
  { name: 'Grandmaster', min: 2500, max: Infinity, color: '#EC4899', badgeClass: 'rank-badge-grandmaster' },
];

const ALL_TOPICS = [
  'Algorithms', 'Data Structures', 'DBMS', 'Operating Systems',
  'Computer Networks', 'Theory of Computation', 'Compiler Design',
  'Discrete Mathematics', 'Computer Organisation', 'Programming Languages',
  'Software Engineering', 'Artificial Intelligence',
];

function getRankForLP(lp: number) {
  return RANK_TIERS.find((r) => lp >= r.min && lp <= r.max) || RANK_TIERS[0];
}

// ─── Custom Tooltip for Charts ────────────────────────────────────────────────

function CustomTooltip({ active, payload, label }: { active?: boolean; payload?: { value: number }[]; label?: string }) {
  if (active && payload && payload.length) {
    return (
      <div className="card-elevated px-3 py-2 text-xs">
        <p className="text-muted-foreground mb-0.5">{label}</p>
        <p className="font-mono-data font-bold text-foreground">{payload[0].value}</p>
      </div>
    );
  }
  return null;
}

// ─── Activity Cell ─────────────────────────────────────────────────────────────

function ActivityCell({ count }: { count: number }) {
  const bg =
    count === 0 ? 'bg-muted/40' :
    count === 1 ? 'bg-primary/30' :
    count === 2 ? 'bg-primary/55' :
    count === 3 ? 'bg-primary/75' : 'bg-primary';
  return <div className={`w-4 h-4 rounded-sm ${bg} transition-colors`} title={`${count} session${count !== 1 ? 's' : ''}`} />;
}

// ─── Suggested Next Steps ──────────────────────────────────────────────────────

interface SuggestedStep {
  id: string;
  icon: React.ElementType;
  iconColor: string;
  bgColor: string;
  borderColor: string;
  title: string;
  description: string;
  href: string;
  cta: string;
}

function SuggestedNextSteps({ profile, topicMastery, lpTrend }: {
  profile: { lp: number; daily_streak: number } | null;
  topicMastery: { topic: string; mastery_percent: number; total_questions: number }[];
  lpTrend: { lp_after: number }[];
}) {
  const steps: SuggestedStep[] = useMemo(() => {
    const list: SuggestedStep[] = [];

    // Weak topic suggestion
    const weakTopics = topicMastery.filter((t) => t.mastery_percent > 0 && t.mastery_percent < 55);
    if (weakTopics.length > 0) {
      list.push({
        id: 'sug-practice',
        icon: AlertTriangle,
        iconColor: 'text-warning',
        bgColor: 'bg-warning/10',
        borderColor: 'border-warning/20',
        title: `Practice ${weakTopics[0].topic}`,
        description: `Your mastery in ${weakTopics[0].topic} is ${weakTopics[0].mastery_percent}%. A focused practice session will boost your score.`,
        href: '/practice',
        cta: 'Start Practice',
      });
    }

    // LP-based rank push
    if (profile) {
      const rank = getRankForLP(profile.lp);
      const nextRank = RANK_TIERS[RANK_TIERS.indexOf(rank) + 1];
      if (nextRank) {
        const lpNeeded = nextRank.min - profile.lp;
        list.push({
          id: 'sug-ranked',
          icon: Trophy,
          iconColor: 'text-primary',
          bgColor: 'bg-primary/10',
          borderColor: 'border-primary/20',
          title: `Push to ${nextRank.name}`,
          description: `You need ${lpNeeded} more LP to reach ${nextRank.name}. Play a ranked match to close the gap!`,
          href: '/ranked-mode-screen',
          cta: 'Play Ranked',
        });
      }
    }

    // Streak suggestion
    if (profile && profile.daily_streak < 3) {
      list.push({
        id: 'sug-streak',
        icon: Flame,
        iconColor: 'text-accent',
        bgColor: 'bg-accent/10',
        borderColor: 'border-accent/20',
        title: 'Build Your Streak',
        description: `Your current streak is ${profile.daily_streak} days. Play today to keep it going!`,
        href: '/practice',
        cta: 'Play Now',
      });
    }

    list.push({
      id: 'sug-analytics',
      icon: Lightbulb,
      iconColor: 'text-info',
      bgColor: 'bg-info/10',
      borderColor: 'border-info/20',
      title: 'Review Your Weak Topics',
      description: 'Check Topic Mastery and focus on topics below 60% mastery.',
      href: '/analytics',
      cta: 'View Analytics',
    });

    return list.slice(0, 3);
  }, [profile, topicMastery]);

  return (
    <div className="card-elevated p-5">
      <div className="flex items-center gap-2 mb-4">
        <Crosshair size={15} className="text-primary" />
        <h2 className="text-sm font-semibold text-foreground">Suggested Next Steps</h2>
      </div>
      <div className="flex flex-col gap-3">
        {steps.map((step) => {
          const StepIcon = step.icon;
          return (
            <a
              key={step.id}
              href={step.href}
              className={`flex items-start gap-3 p-3 rounded-xl border ${step.bgColor} ${step.borderColor} hover:opacity-90 transition-opacity group`}
            >
              <div className="w-8 h-8 rounded-lg bg-white/10 flex items-center justify-center flex-shrink-0 mt-0.5">
                <StepIcon size={15} className={step.iconColor} />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-semibold text-foreground">{step.title}</p>
                <p className="text-xs text-muted-foreground leading-relaxed mt-0.5">{step.description}</p>
              </div>
              <div className="flex items-center gap-1 flex-shrink-0 mt-1">
                <span className={`text-xs font-semibold ${step.iconColor}`}>{step.cta}</span>
                <ArrowRight size={12} className={`${step.iconColor} group-hover:translate-x-0.5 transition-transform`} />
              </div>
            </a>
          );
        })}
      </div>
    </div>
  );
}

// ─── Analytics Loading Skeleton ─────────────────────────────────────────────────

function AnalyticsSkeleton() {
  return (
    <div className="min-h-screen bg-background">
      <div className="sticky top-0 z-10 bg-card/80 backdrop-blur-sm border-b border-border">
        <div className="max-w-screen-xl mx-auto px-4 lg:px-8 h-14 flex items-center justify-between">
          <LoadingSkeleton className="h-5 w-24" />
          <LoadingSkeleton className="h-4 w-16" />
        </div>
      </div>
      <div className="max-w-screen-xl mx-auto px-4 lg:px-8 py-6 space-y-6">
        {Array.from({ length: 6 }).map((_, i) => (
          <LoadingSkeleton key={`sk-${i}`} className="h-48 w-full rounded-xl" />
        ))}
      </div>
    </div>
  );
}

// ─── Main Analytics Page ──────────────────────────────────────────────────────

export default function AnalyticsPage() {
  const [sessionFilter, setSessionFilter] = useState<'All' | 'Ranked' | 'Practice'>('All');
  const [mounted, setMounted] = useState(false);
  const [loading, setLoading] = useState(true);
  const [profile, setProfile] = useState<any>(null);
  const [topicMastery, setTopicMastery] = useState<any[]>([]);
  const [sessionHistory, setSessionHistory] = useState<any[]>([]);
  const [lpTrend, setLpTrend] = useState<any[]>([]);
  const [activityData, setActivityData] = useState<any[]>([]);
  const [sessionStats, setSessionStats] = useState<any>(null);
  const [modeBreakdown, setModeBreakdown] = useState<any>(null);
  const [accuracyTrend, setAccuracyTrend] = useState<any[]>([]);

  useEffect(() => {
    let unsubTopics: (() => void) | undefined;

    const init = async () => {
      setMounted(true);
      const supabase = createClient();
      if (!supabase) { setLoading(false); return; }
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) { setLoading(false); return; }

      // Helper to reload all analytics data from views
      const reloadData = async () => {
        const [
          summaryResult,
          masteryResult,
          historyResult,
          lpTrendResult,
          activityResult,
          statsResult,
          modeBreakdownResult,
          accuracyTrendResult,
        ] = await Promise.all([
          supabase.from('analytics_user_summary').select('*').eq('user_id', user.id).single(),
          supabase.from('analytics_topic_mastery').select('*').eq('user_id', user.id),
          supabase.from('analytics_session_history').select('*').eq('user_id', user.id).order('session_date', { ascending: false }).limit(30),
          supabase.from('analytics_lp_trend').select('*').eq('user_id', user.id).order('session_date', { ascending: true }).limit(10),
          supabase.from('analytics_activity').select('*').eq('user_id', user.id).order('activity_date', { ascending: true }),
          supabase.from('analytics_session_stats').select('*').eq('user_id', user.id).maybeSingle(),
          supabase.from('analytics_mode_breakdown').select('*').eq('user_id', user.id).maybeSingle(),
          supabase.from('analytics_accuracy_trend').select('*').eq('user_id', user.id).order('session_date', { ascending: true }).limit(20),
        ]);

        if (summaryResult.data) setProfile(summaryResult.data);
        if (masteryResult.data) setTopicMastery(masteryResult.data);
        if (historyResult.data) setSessionHistory(historyResult.data);
        if (lpTrendResult.data) setLpTrend(lpTrendResult.data);
        if (activityResult.data) setActivityData(activityResult.data);
        if (statsResult.data) setSessionStats(statsResult.data);
        if (modeBreakdownResult.data) setModeBreakdown(modeBreakdownResult.data);
        if (accuracyTrendResult.data) setAccuracyTrend(accuracyTrendResult.data);
        setLoading(false);
      };

      // Initial load
      await reloadData();

      // Subscribe to real-time changes on practice_sessions, ranked_sessions, and user_profiles
      const channel = supabase.channel('analytics-realtime-sync')
        .on('postgres_changes',
          { event: '*', schema: 'public', table: 'practice_sessions', filter: `user_id=eq.${user.id}` },
          () => { reloadData(); }
        )
        .on('postgres_changes',
          { event: '*', schema: 'public', table: 'ranked_sessions', filter: `user_id=eq.${user.id}` },
          () => { reloadData(); }
        )
        .on('postgres_changes',
          { event: 'UPDATE', schema: 'public', table: 'user_profiles', filter: `id=eq.${user.id}` },
          () => { reloadData(); }
        )
        .subscribe();

      unsubTopics = () => {
        supabase.removeChannel(channel);
      };
    };

    init();
    return () => { if (unsubTopics) unsubTopics(); };
  }, []);

  // Compute rank progression
  const totalLP = profile?.lp ?? 0;
  const rank = getRankForLP(totalLP);
  const nextRank = RANK_TIERS[RANK_TIERS.indexOf(rank) + 1];
  const lpToNext = nextRank ? nextRank.min - totalLP : 0;
  const rankProgress = nextRank
    ? Math.round(((totalLP - rank.min) / (nextRank.min - rank.min)) * 100)
    : 100;

  const overallAccuracy = profile ? Math.round(Number(profile.overall_accuracy) * 10) / 10 : 0;
  const avgAnswerSpeed = profile ? Math.round(Number(profile.avg_answer_speed_seconds)) : 0;
  const dailyStreak = profile?.daily_streak ?? 0;
  const longestStreak = profile?.longest_streak ?? 0;
  const totalProblemsSolved = profile?.total_questions_answered ?? 0;
  const totalCorrect = profile?.total_correct ?? 0;
  const totalSessions = profile?.total_sessions ?? 0;

  // LP trend for chart
  const lpChartData = useMemo(() => {
    if (lpTrend.length === 0) {
      return [
        { day: 'Mon', lp: 0 }, { day: 'Tue', lp: 0 }, { day: 'Wed', lp: 0 },
        { day: 'Thu', lp: 0 }, { day: 'Fri', lp: 0 }, { day: 'Sat', lp: 0 },
        { day: 'Sun', lp: totalLP },
      ];
    }
    return lpTrend.map((s: any) => ({
      day: new Date(s.session_date).toLocaleDateString('en-US', { weekday: 'short' }),
      lp: s.lp_after,
    }));
  }, [lpTrend, totalLP]);

  // Speed chart data
  const speedData = useMemo(() => {
    const sessions = sessionHistory.slice(-7).reverse();
    if (sessions.length === 0) {
      return [
        { session: 'S1', avg: 0 }, { session: 'S2', avg: 0 }, { session: 'S3', avg: 0 },
        { session: 'S4', avg: 0 }, { session: 'S5', avg: 0 }, { session: 'S6', avg: 0 },
        { session: 'S7', avg: 0 },
      ];
    }
    return sessions.map((s: any, i: number) => ({
      session: `S${i + 1}`,
      avg: Math.round(Number(s.avg_speed_seconds)),
    }));
  }, [sessionHistory]);

  // Accuracy trend chart data
  const accuracyChartData = useMemo(() => {
    return accuracyTrend.slice(-12).map((s: any, i: number) => ({
      session: `S${i + 1}`,
      accuracy: Math.round(Number(s.accuracy)),
      mode: s.mode,
    }));
  }, [accuracyTrend]);

  // Filter session history
  const filteredSessions = useMemo(() =>
    sessionFilter === 'All' ? sessionHistory : sessionHistory.filter((s: any) => s.mode === sessionFilter),
    [sessionFilter, sessionHistory]
  );

  // Activity calendar
  const activityWeeks = useMemo(() => {
    const data: { date: string; count: number }[][] = [];
    if (activityData.length === 0) return [];
    const flatData = activityData.map((d: any) => ({
      date: d.activity_date.slice(0, 10),
      count: d.session_count,
    }));
    for (let i = 0; i < flatData.length; i += 7) {
      data.push(flatData.slice(i, i + 7));
    }
    return data;
  }, [activityData]);

  // AI Insights
  const AI_INSIGHTS = useMemo(() => {
    const insights: { id: string; type: string; icon: string; text: string }[] = [];
    const strongTopics = topicMastery.filter((t: any) => t.mastery_percent >= 75);
    const weakTopics = topicMastery.filter((t: any) => t.mastery_percent > 0 && t.mastery_percent < 55);

    if (strongTopics.length > 0) {
      insights.push({ id: 'ai-1', type: 'strength', icon: '🔥', text: `Your ${strongTopics[0].topic} mastery is at ${strongTopics[0].mastery_percent}% — keep up the momentum!` });
    }
    if (weakTopics.length > 0) {
      insights.push({ id: 'ai-2', type: 'weakness', icon: '⚠️', text: `${weakTopics[0].topic} needs attention. Focus your next practice session here.` });
    }
    insights.push({ id: 'ai-3', type: 'tip', icon: '💡', text: 'Your fastest answers come in the first 10 minutes of a session. Consider shorter, focused sessions.' });
    if (profile && nextRank) {
      insights.push({ id: 'ai-4', type: 'goal', icon: '🎯', text: `You're ${lpToNext} LP away from ${nextRank.name}. At your current pace, you'll reach it soon!` });
    }
    return insights.slice(0, 4);
  }, [profile, topicMastery, nextRank, lpToNext]);

  if (loading) {
    return <AnalyticsSkeleton />;
  }

  return (
    <AppLayout>
      <div className="min-h-screen bg-background">
        {/* Header */}
        <div className="sticky top-0 z-10 bg-card/80 backdrop-blur-sm border-b border-border">
          <div className="max-w-screen-xl mx-auto px-4 lg:px-8 h-14 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <BarChart3 size={18} className="text-primary" />
              <span className="text-sm font-bold text-foreground">Analytics Dashboard</span>
            </div>
            <span className="text-xs text-muted-foreground">
              {loading ? 'Loading…' : 'Live from Supabase'}
            </span>
          </div>
        </div>

        <div className="max-w-screen-xl mx-auto px-4 lg:px-8 py-6 space-y-6">

          {/* ── Row 1: 8 Profile Stat Cards ───────────────────────────────────── */}
          <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-3 sm:gap-4">
            <div className="card-elevated p-4">
              <div className="flex items-center justify-between mb-3">
                <div className="w-8 h-8 rounded-lg bg-primary/20 flex items-center justify-center">
                  <Star size={15} className="text-primary" />
                </div>
                <span className="text-[10px] font-semibold text-success flex items-center gap-0.5">
                  <TrendingUp size={10} /> Live
                </span>
              </div>
              <p className="font-mono-data text-2xl font-extrabold text-foreground">{mounted ? totalLP : '—'}</p>
              <p className="text-[10px] text-muted-foreground mt-1">Total LP</p>
            </div>

            <div className="card-elevated p-4">
              <div className="flex items-center justify-between mb-3">
                <div className="w-8 h-8 rounded-lg flex items-center justify-center" style={{ background: `${rank.color}22` }}>
                  <Trophy size={15} style={{ color: rank.color }} />
                </div>
                {nextRank && (
                  <span className="text-[10px] text-muted-foreground">{lpToNext} LP to {nextRank.name}</span>
                )}
              </div>
              <p className="text-lg font-extrabold" style={{ color: rank.color }}>{mounted ? rank.name : '—'}</p>
              <div className="mt-2 h-1.5 bg-muted rounded-full overflow-hidden">
                <div className="h-full rounded-full transition-all duration-700" style={{ width: `${mounted ? rankProgress : 0}%`, background: rank.color }} />
              </div>
              <p className="text-[10px] text-muted-foreground mt-1">Current Rank</p>
            </div>

            <div className="card-elevated p-4">
              <div className="flex items-center justify-between mb-3">
                <div className="w-8 h-8 rounded-lg bg-success/20 flex items-center justify-center">
                  <Target size={15} className="text-success" />
                </div>
              </div>
              <p className="font-mono-data text-2xl font-extrabold text-success">{mounted ? `${overallAccuracy}%` : '—'}</p>
              <p className="text-[10px] text-muted-foreground mt-1">Accuracy Rate</p>
            </div>

            <div className="card-elevated p-4">
              <div className="flex items-center justify-between mb-3">
                <div className="w-8 h-8 rounded-lg bg-info/20 flex items-center justify-center">
                  <BookOpen size={15} className="text-info" />
                </div>
              </div>
              <p className="font-mono-data text-2xl font-extrabold text-info">{mounted ? totalProblemsSolved : '—'}</p>
              <p className="text-[10px] text-muted-foreground mt-1">Questions Answered</p>
            </div>

            <div className="card-elevated p-4">
              <div className="flex items-center justify-between mb-3">
                <div className="w-8 h-8 rounded-lg bg-success/20 flex items-center justify-center">
                  <BookOpenCheck size={15} className="text-success" />
                </div>
              </div>
              <p className="font-mono-data text-2xl font-extrabold text-success">{mounted ? totalCorrect : '—'}</p>
              <p className="text-[10px] text-muted-foreground mt-1">Correct Answers</p>
            </div>

            <div className="card-elevated p-4">
              <div className="flex items-center justify-between mb-3">
                <div className="w-8 h-8 rounded-lg bg-warning/20 flex items-center justify-center">
                  <Zap size={15} className="text-warning" />
                </div>
              </div>
              <p className="font-mono-data text-2xl font-extrabold text-warning">{mounted ? `${avgAnswerSpeed}s` : '—'}</p>
              <p className="text-[10px] text-muted-foreground mt-1">Avg Speed</p>
            </div>

            <div className="card-elevated p-4">
              <div className="flex items-center justify-between mb-3">
                <div className="w-8 h-8 rounded-lg bg-accent/20 flex items-center justify-center">
                  <Flame size={15} className="text-accent streak-flame" />
                </div>
                <span className="text-[10px] text-muted-foreground">Best: {longestStreak}</span>
              </div>
              <p className="font-mono-data text-2xl font-extrabold text-accent">{mounted ? dailyStreak : '—'}</p>
              <p className="text-[10px] text-muted-foreground mt-1">Day Streak 🔥</p>
            </div>

            <div className="card-elevated p-4">
              <div className="flex items-center justify-between mb-3">
                <div className="w-8 h-8 rounded-lg bg-info/20 flex items-center justify-center">
                  <Activity size={15} className="text-info" />
                </div>
              </div>
              <p className="font-mono-data text-2xl font-extrabold text-info">{mounted ? totalSessions : '—'}</p>
              <p className="text-[10px] text-muted-foreground mt-1">Total Sessions</p>
            </div>
          </div>

          {/* ── Row 2: Practice vs Ranked Breakdown ──────────────────────────── */}
          {modeBreakdown && (modeBreakdown.practice_sessions > 0 || modeBreakdown.ranked_sessions > 0) && (
            <div className="card-elevated p-5">
              <div className="flex items-center gap-2 mb-4">
                <Award size={15} className="text-primary" />
                <h2 className="text-sm font-semibold text-foreground">Practice vs Ranked Breakdown</h2>
              </div>
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
                {/* Practice Column */}
                <div className="p-4 rounded-xl bg-info/5 border border-info/20">
                  <div className="flex items-center gap-2 mb-3">
                    <BookOpen size={14} className="text-info" />
                    <h3 className="text-xs font-bold text-info uppercase tracking-wider">Practice Mode</h3>
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <p className="font-mono-data text-xl font-extrabold text-foreground">{modeBreakdown.practice_sessions}</p>
                      <p className="text-[10px] text-muted-foreground">Sessions</p>
                    </div>
                    <div>
                      <p className="font-mono-data text-xl font-extrabold text-foreground">{modeBreakdown.practice_questions}</p>
                      <p className="text-[10px] text-muted-foreground">Questions</p>
                    </div>
                    <div>
                      <p className="font-mono-data text-xl font-extrabold text-success">{modeBreakdown.practice_avg_accuracy}%</p>
                      <p className="text-[10px] text-muted-foreground">Avg Accuracy</p>
                    </div>
                    <div>
                      <p className="font-mono-data text-xl font-extrabold text-warning">{modeBreakdown.practice_avg_speed}s</p>
                      <p className="text-[10px] text-muted-foreground">Avg Speed</p>
                    </div>
                  </div>
                  <div className="mt-3 pt-3 border-t border-info/10 flex items-center gap-2 text-[10px] text-muted-foreground">
                    <Lightbulb size={10} className="text-accent" />
                    <span>{modeBreakdown.practice_hints_used} hints used</span>
                  </div>
                </div>

                {/* Comparison Bar */}
                <div className="p-4 rounded-xl bg-muted/30 flex flex-col items-center justify-center">
                  <p className="text-[10px] font-bold text-muted-foreground uppercase tracking-wider mb-3">Session Split</p>
                  <div className="w-full h-4 bg-muted rounded-full overflow-hidden flex">
                    {modeBreakdown.total_sessions > 0 && (
                      <>
                        <div
                          className="h-full bg-info transition-all duration-700"
                          style={{ width: `${Math.round((modeBreakdown.practice_sessions / modeBreakdown.total_sessions) * 100)}%` }}
                        />
                        <div
                          className="h-full bg-primary transition-all duration-700"
                          style={{ width: `${Math.round((modeBreakdown.ranked_sessions / modeBreakdown.total_sessions) * 100)}%` }}
                        />
                      </>
                    )}
                  </div>
                  <div className="flex items-center justify-between w-full mt-2">
                    <div className="flex items-center gap-1.5">
                      <div className="w-2.5 h-2.5 rounded-sm bg-info" />
                      <span className="text-[10px] text-muted-foreground">Practice {modeBreakdown.practice_sessions > 0 ? Math.round((modeBreakdown.practice_sessions / modeBreakdown.total_sessions) * 100) : 0}%</span>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <div className="w-2.5 h-2.5 rounded-sm bg-primary" />
                      <span className="text-[10px] text-muted-foreground">Ranked {modeBreakdown.ranked_sessions > 0 ? Math.round((modeBreakdown.ranked_sessions / modeBreakdown.total_sessions) * 100) : 0}%</span>
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-4 mt-4 w-full">
                    <div className="text-center">
                      <p className="font-mono-data text-xs font-bold text-foreground">{modeBreakdown.total_correct}/{modeBreakdown.total_questions}</p>
                      <p className="text-[10px] text-muted-foreground">Overall Correct</p>
                    </div>
                    <div className="text-center">
                      <p className="font-mono-data text-xs font-bold text-foreground">{modeBreakdown.total_timeout}</p>
                      <p className="text-[10px] text-muted-foreground">Timeouts</p>
                    </div>
                  </div>
                </div>

                {/* Ranked Column */}
                <div className="p-4 rounded-xl bg-primary/5 border border-primary/20">
                  <div className="flex items-center gap-2 mb-3">
                    <Trophy size={14} className="text-primary" />
                    <h3 className="text-xs font-bold text-primary uppercase tracking-wider">Ranked Mode</h3>
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <p className="font-mono-data text-xl font-extrabold text-foreground">{modeBreakdown.ranked_sessions}</p>
                      <p className="text-[10px] text-muted-foreground">Sessions</p>
                    </div>
                    <div>
                      <p className="font-mono-data text-xl font-extrabold text-foreground">{modeBreakdown.ranked_questions}</p>
                      <p className="text-[10px] text-muted-foreground">Questions</p>
                    </div>
                    <div>
                      <p className="font-mono-data text-xl font-extrabold text-success">{modeBreakdown.ranked_avg_accuracy}%</p>
                      <p className="text-[10px] text-muted-foreground">Avg Accuracy</p>
                    </div>
                    <div>
                      <p className="font-mono-data text-xl font-extrabold text-warning">{modeBreakdown.ranked_avg_speed}s</p>
                      <p className="text-[10px] text-muted-foreground">Avg Speed</p>
                    </div>
                  </div>
                  <div className="mt-3 pt-3 border-t border-primary/10 flex items-center justify-between text-[10px] text-muted-foreground">
                    <span>Net LP: <span className={`font-bold ${modeBreakdown.ranked_net_lp_change >= 0 ? 'text-success' : 'text-danger'}`}>
                      {modeBreakdown.ranked_net_lp_change >= 0 ? '+' : ''}{modeBreakdown.ranked_net_lp_change}
                    </span></span>
                    <span>Gained: <span className="font-bold text-success">+{modeBreakdown.ranked_lp_gained}</span></span>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* ── Row 3: LP Trend + Answer Speed ──────────────────────────────── */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            <div className="card-elevated p-5">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-2">
                  <TrendingUp size={15} className="text-primary" />
                  <h2 className="text-sm font-semibold text-foreground">LP Trend</h2>
                </div>
                <span className="text-xs text-muted-foreground">Last {lpTrend.length} sessions</span>
              </div>
              {mounted ? (
                <ResponsiveContainer width="100%" height={180}>
                  <AreaChart data={lpChartData} margin={{ top: 4, right: 4, left: -20, bottom: 0 }}>
                    <defs>
                      <linearGradient id="lpGrad" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#7C3AED" stopOpacity={0.3} />
                        <stop offset="95%" stopColor="#7C3AED" stopOpacity={0} />
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                    <XAxis dataKey="day" tick={{ fontSize: 11, fill: 'var(--muted-foreground)' }} axisLine={false} tickLine={false} />
                    <YAxis tick={{ fontSize: 11, fill: 'var(--muted-foreground)' }} axisLine={false} tickLine={false} />
                    <Tooltip content={<CustomTooltip />} />
                    <Area type="monotone" dataKey="lp" stroke="#7C3AED" strokeWidth={2} fill="url(#lpGrad)" dot={{ fill: '#7C3AED', r: 3 }} activeDot={{ r: 5 }} />
                  </AreaChart>
                </ResponsiveContainer>
              ) : <div className="h-[180px] bg-muted/20 rounded-lg animate-pulse" />}
            </div>

            <div className="card-elevated p-5">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-2">
                  <Clock size={15} className="text-info" />
                  <h2 className="text-sm font-semibold text-foreground">Answer Speed by Session</h2>
                </div>
                <span className="text-xs text-muted-foreground">Avg seconds/Q</span>
              </div>
              {mounted ? (
                <ResponsiveContainer width="100%" height={180}>
                  <BarChart data={speedData} margin={{ top: 4, right: 4, left: -20, bottom: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                    <XAxis dataKey="session" tick={{ fontSize: 11, fill: 'var(--muted-foreground)' }} axisLine={false} tickLine={false} />
                    <YAxis tick={{ fontSize: 11, fill: 'var(--muted-foreground)' }} axisLine={false} tickLine={false} />
                    <Tooltip content={<CustomTooltip />} />
                    <Bar dataKey="avg" fill="#06B6D4" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              ) : <div className="h-[180px] bg-muted/20 rounded-lg animate-pulse" />}
            </div>
          </div>

          {/* ── Row 4: Accuracy Trend + Topic Mastery ─────────────────────────── */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            <div className="card-elevated p-5">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-2">
                  <Target size={15} className="text-success" />
                  <h2 className="text-sm font-semibold text-foreground">Accuracy Trend</h2>
                </div>
                <span className="text-xs text-muted-foreground">Last {accuracyChartData.length} sessions</span>
              </div>
              {accuracyChartData.length > 0 ? (
                <ResponsiveContainer width="100%" height={180}>
                  <BarChart data={accuracyChartData} margin={{ top: 4, right: 4, left: -20, bottom: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                    <XAxis dataKey="session" tick={{ fontSize: 11, fill: 'var(--muted-foreground)' }} axisLine={false} tickLine={false} />
                    <YAxis domain={[0, 100]} tick={{ fontSize: 11, fill: 'var(--muted-foreground)' }} axisLine={false} tickLine={false} />
                    <Tooltip content={<CustomTooltip />} />
                    <Bar dataKey="accuracy" fill="#22C55E" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              ) : <div className="h-[180px] flex items-center justify-center text-xs text-muted-foreground">No sessions yet</div>}
            </div>

            <div className="card-elevated p-5">
              <div className="flex items-center gap-2 mb-4">
                <BookOpen size={15} className="text-primary" />
                <h2 className="text-sm font-semibold text-foreground">Topic Mastery</h2>
              </div>
              <div className="flex flex-col gap-3">
                {topicMastery.map((t: any) => (
                  <div key={`tm-${t.topic}`} className="flex items-center gap-3">
                    <div className="w-36 text-xs text-foreground font-medium truncate flex-shrink-0">{t.topic}</div>
                    <div className="flex-1 h-2 bg-muted rounded-full overflow-hidden">
                      <div
                        className="h-full rounded-full transition-all duration-700"
                        style={{
                          width: `${t.mastery_percent}%`,
                          background: t.mastery_percent >= 75 ? 'var(--success)' : t.mastery_percent >= 55 ? 'var(--warning)' : 'var(--danger)',
                        }}
                      />
                    </div>
                    <span className={`font-mono-data text-xs font-bold w-9 text-right flex-shrink-0 ${
                      t.mastery_percent >= 75 ? 'text-success' : t.mastery_percent >= 55 ? 'text-warning' : 'text-danger'
                    }`}>{t.mastery_percent}%</span>
                    <span className="text-[10px] text-muted-foreground w-10 text-right flex-shrink-0">{t.total_questions}Q</span>
                  </div>
                ))}
                {topicMastery.length === 0 && (
                  <p className="text-xs text-muted-foreground text-center py-8">Complete sessions to see topic mastery data.</p>
                )}
              </div>
            </div>
          </div>

          {/* ── Row 5: AI Coach + Suggested Next Steps ──────────────────────── */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            <div className="card-elevated p-5">
              <div className="flex items-center gap-2 mb-4">
                <Brain size={15} className="text-accent" />
                <h2 className="text-sm font-semibold text-foreground">AI Coach Insights</h2>
              </div>
              <div className="flex flex-col gap-3">
                {AI_INSIGHTS.map((insight) => (
                  <div key={insight.id} className={`flex items-start gap-3 p-3 rounded-xl border ${
                    insight.type === 'strength' ? 'bg-success/8 border-success/20' :
                    insight.type === 'weakness' ? 'bg-warning/8 border-warning/20' :
                    insight.type === 'goal' ? 'bg-primary/8 border-primary/20' : 'bg-muted/40 border-border'
                  }`}>
                    <span className="text-base flex-shrink-0 mt-0.5">{insight.icon}</span>
                    <p className="text-xs text-foreground leading-relaxed">{insight.text}</p>
                  </div>
                ))}
              </div>
            </div>

            <SuggestedNextSteps profile={profile} topicMastery={topicMastery} lpTrend={lpTrend} />
          </div>

          {/* ── Row 6: Session History + Activity Calendar ──────────────────── */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
            <div className="card-elevated p-5 lg:col-span-2">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-2">
                  <Activity size={15} className="text-primary" />
                  <h2 className="text-sm font-semibold text-foreground">Session History</h2>
                </div>
                <div className="flex items-center gap-1.5">
                  {(['All', 'Ranked', 'Practice'] as const).map((f) => (
                    <button key={`sf-${f}`} onClick={() => setSessionFilter(f)}
                      className={`px-2.5 py-1 rounded-lg text-xs font-medium transition-colors ${
                        sessionFilter === f ? 'bg-primary/20 text-primary border border-primary/30' : 'text-muted-foreground hover:text-foreground hover:bg-muted'
                      }`}>{f}</button>
                  ))}
                </div>
              </div>

              {sessionStats && (sessionStats.total_ranked_sessions > 0 || sessionStats.total_practice_sessions > 0) && (
                <div className="grid grid-cols-4 gap-2 mb-4 p-3 rounded-xl bg-muted/30">
                  <div className="text-center">
                    <p className="font-mono-data text-sm font-bold text-success">{sessionStats.ranked_wins}W</p>
                    <p className="text-[10px] text-muted-foreground">Wins</p>
                  </div>
                  <div className="text-center">
                    <p className="font-mono-data text-sm font-bold text-danger">{sessionStats.ranked_losses}L</p>
                    <p className="text-[10px] text-muted-foreground">Losses</p>
                  </div>
                  <div className="text-center">
                    <p className="font-mono-data text-sm font-bold text-primary">{sessionStats.ranked_win_rate}%</p>
                    <p className="text-[10px] text-muted-foreground">Win Rate</p>
                  </div>
                  <div className="text-center">
                    <p className="font-mono-data text-sm font-bold text-accent">{sessionStats.best_ranked_accuracy}%</p>
                    <p className="text-[10px] text-muted-foreground">Best Acc.</p>
                  </div>
                </div>
              )}

              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b border-border">
                      {['Date', 'Mode', 'Q', 'Correct', 'Accuracy', 'Speed', 'LP Δ'].map((h) => (
                        <th key={`sh-h-${h}`} className="text-left text-[11px] font-semibold text-muted-foreground pb-2 pr-3 last:pr-0">{h}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {filteredSessions.map((s: any) => (
                      <tr key={s.session_id} className="border-b border-border/40 hover:bg-muted/30 transition-colors">
                        <td className="py-2.5 pr-3 text-xs text-muted-foreground font-mono-data">{s.session_date?.slice(5, 10) || ''}</td>
                        <td className="py-2.5 pr-3">
                          <Badge variant={s.mode === 'Ranked' ? 'primary' : 'default'} size="sm">{s.mode}</Badge>
                        </td>
                        <td className="py-2.5 pr-3 font-mono-data text-xs text-foreground">{s.questions_total}</td>
                        <td className="py-2.5 pr-3 font-mono-data text-xs text-success">{s.questions_correct}</td>
                        <td className="py-2.5 pr-3">
                          <span className={`font-mono-data text-xs font-bold ${
                            s.accuracy >= 80 ? 'text-success' : s.accuracy >= 60 ? 'text-warning' : 'text-danger'
                          }`}>{Math.round(Number(s.accuracy))}%</span>
                        </td>
                        <td className="py-2.5 pr-3 font-mono-data text-xs text-info">{Math.round(Number(s.avg_speed_seconds))}s</td>
                        <td className="py-2.5">
                          {s.lp_change === 0 ? (
                            <span className="text-xs text-muted-foreground flex items-center gap-0.5"><Minus size={10} />—</span>
                          ) : s.lp_change > 0 ? (
                            <span className="text-xs text-success font-mono-data font-bold flex items-center gap-0.5"><ChevronUp size={12} />+{s.lp_change}</span>
                          ) : (
                            <span className="text-xs text-danger font-mono-data font-bold flex items-center gap-0.5"><ChevronDown size={12} />{s.lp_change}</span>
                          )}
                        </td>
                      </tr>
                    ))}
                    {filteredSessions.length === 0 && (
                      <tr><td colSpan={7} className="py-8 text-center text-xs text-muted-foreground">No sessions yet.</td></tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>

            <div className="card-elevated p-5">
              <div className="flex items-center gap-2 mb-4">
                <Calendar size={15} className="text-accent" />
                <h2 className="text-sm font-semibold text-foreground">Activity</h2>
              </div>
              <div className="flex flex-col gap-1.5">
                {activityWeeks.map((week: any[], wi: number) => (
                  <div key={`week-${wi}`} className="flex gap-1.5">
                    {week.map((day: any, di: number) => (
                      <ActivityCell key={`day-${wi}-${di}`} count={day?.count || 0} />
                    ))}
                  </div>
                ))}
                {activityWeeks.length === 0 && (
                  <p className="text-xs text-muted-foreground text-center py-4">No activity yet.</p>
                )}
              </div>
              <div className="flex items-center gap-2 mt-4 pt-3 border-t border-border">
                <span className="text-[10px] text-muted-foreground">Less</span>
                {[0, 1, 2, 3, 4].map((c) => (<ActivityCell key={`legend-${c}`} count={c} />))}
                <span className="text-[10px] text-muted-foreground">More</span>
              </div>
            </div>
          </div>

        </div>
      </div>
    </AppLayout>
  );
}