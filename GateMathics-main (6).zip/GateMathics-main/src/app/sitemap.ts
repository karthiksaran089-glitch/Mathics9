import { MetadataRoute } from 'next';

export default function sitemap(): MetadataRoute.Sitemap {
  const BASE = 'https://mathics24882.builtwithmatics.new';
  const now = new Date();

  return [
    { url: `${BASE}/`, lastModified: now, changeFrequency: 'daily', priority: 1.0 },
    { url: `${BASE}/ranked-mode-screen`, lastModified: now, changeFrequency: 'weekly', priority: 0.9 },
    { url: `${BASE}/practice`, lastModified: now, changeFrequency: 'weekly', priority: 0.9 },
    { url: `${BASE}/analytics`, lastModified: now, changeFrequency: 'weekly', priority: 0.7 },
    { url: `${BASE}/about`, lastModified: now, changeFrequency: 'monthly', priority: 0.6 },
    { url: `${BASE}/contact`, lastModified: now, changeFrequency: 'monthly', priority: 0.5 },
    { url: `${BASE}/privacy-policy`, lastModified: now, changeFrequency: 'yearly', priority: 0.3 },
    { url: `${BASE}/help`, lastModified: now, changeFrequency: 'monthly', priority: 0.5 },
  ];
}
