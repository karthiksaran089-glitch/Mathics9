import React from 'react';
import type { Metadata } from 'next';
import { PAGE_SEO } from '@/lib/seo/gateSeoConfig';
import HomePageClient from './HomePageClient';

export const metadata: Metadata = PAGE_SEO.home;

export default function HomePage() {
  return <HomePageClient />;
}