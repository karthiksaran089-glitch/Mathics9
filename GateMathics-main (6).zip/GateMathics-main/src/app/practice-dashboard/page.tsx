'use client';
// ─────────────────────────────────────────────────────────────
// Practice Dashboard
// ─────────────────────────────────────────────────────────────
// Data Source: `practice_sessions` table (Supabase)
// Written by: PracticeMode.tsx → savePracticeSession()
// Columns: user_id, session_date, questions_total, questions_correct,
//   questions_incorrect, questions_timeout, accuracy, avg_speed_seconds,
//   hints_used, topics_practiced, difficulty
//
// Real-time Sync: Subscribes to practice_sessions and user_profiles
//   via Supabase Realtime for cross-tab/cross-device sync.
// ─────────────────────────────────────────────────────────────

import React, { useState, useEffect, useMemo } from 'react';
import {
  BookOpen, TrendingUp, Target, Clock, Lightbulb, BarChart3, Activity,
  Zap, Flame, Play, Layers
} from 'lucide-react';
import { createClient } from '@/lib/supabase/client';
import AppLayout from '@/components/AppLayout';
import Badge from '@/components/ui/Badge';
import { Skeleton as LoadingSkeleton } from '@/components/ui/LoadingSkeleton';
import {
  AreaChart, Area, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell,
} from 'recharts';
import Link from 'next/link';

// ─── Types ────────────────────────────────────────────────────────────────────

interface PracticeSession {
  id: string;
  session_date: string;
  questions_total: number;
  questions_correct: number;
  questions_incorrect: number;
  questions_timeout: number;
  accuracy: number;
  avg_speed_seconds: number;
  hints_used: number;
  topics_practiced: string[];
  difficulty: string;
}

interface PracticeStatSummary {
  total_sessions: number;
  total_questions: number;
  total_correct: number;
  total_incorrect: number;
  total_timeout: number;
  total_hints: number;
  avg_accuracy: number;
  avg_speed: number;
  best_accuracy: number;
  current_streak: number;
}

function CustomTooltip({ active, payload, label }: { active?: boolean; payload?: { value: number }[]; label?: string }) {
  if (active && payload && payload.length) {
    return (
      <div className="card-elevated px-3 py-2 text-xs">
        <p className="text-muted-foreground mb-0.5">{label}</p>
        <p className="font-mono-data font-bold text-foreground">{payload[0].value}</p>
      </div>
    );
  }
  return null;
}

// ─── Loading Skeleton ─────────────────────────────────────────────────────────

function PracticeDashboardSkeleton() {
  return (
    <div className="min-h-screen bg-background">
      <div className="sticky top-0 z-10 bg-card/80 backdrop-blur-sm border-b border-border">
        <div className="max-w-screen-xl mx-auto px-4 lg:px-8 h-14 flex items-center">
          <LoadingSkeleton className="h-5 w-32" />
        </div>
      </div>
      <div className="max-w-screen-xl mx-auto px-4 lg:px-8 py-6 space-y-6">
        {[1,2,3,4].map(i => <LoadingSkeleton key={i} className="h-40 w-full rounded-xl" />)}
      </div>
    </div>
  );
}

// ─── Main Practice Dashboard ──────────────────────────────────────────────────

export default function PracticeDashboard() {
  const [mounted, setMounted] = useState(false);
  const [loading, setLoading] = useState(true);
  const [sessions, setSessions] = useState<PracticeSession[]>([]);
  const [profile, setProfile] = useState<any>(null);

  // Real-time subscription
  useEffect(() => {
    let unsub: (() => void) | undefined;
    const init = async () => {
      setMounted(true);
      const supabase = createClient();
      if (!supabase) { setLoading(false); return; }
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) { setLoading(false); return; }

      // Fetch initial data
      const [sessionRes, profileRes] = await Promise.all([
        supabase.from('practice_sessions')
          .select('*')
          .eq('user_id', user.id)
          .order('session_date', { ascending: false })
          .limit(50),
        supabase.from('profile_stats')
          .select('*')
          .eq('user_id', user.id)
          .maybeSingle(),
      ]);

      if (sessionRes.data) setSessions(sessionRes.data);
      if (profileRes.data) setProfile(profileRes.data);
      setLoading(false);

      // Subscribe to real-time changes
      const channel = supabase.channel('practice-dashboard-sync')
        .on('postgres_changes',
          { event: '*', schema: 'public', table: 'practice_sessions', filter: `user_id=eq.${user.id}` },
          (payload: any) => {
            if (payload.eventType === 'INSERT') {
              setSessions(prev => [payload.new as PracticeSession, ...prev].slice(0, 50));
            } else if (payload.eventType === 'DELETE') {
              setSessions(prev => prev.filter(s => s.id !== payload.old.id));
            } else if (payload.eventType === 'UPDATE') {
              setSessions(prev => prev.map(s => s.id === payload.new.id ? payload.new : s));
            }
          }
        )
        .on('postgres_changes',
          { event: 'UPDATE', schema: 'public', table: 'user_profiles', filter: `id=eq.${user.id}` },
          (payload: any) => {
            setProfile((prev: any) => ({ ...prev, ...payload.new }));
          }
        )
        .subscribe();

      unsub = () => { supabase.removeChannel(channel); };
    };
    init();
    return () => { if (unsub) unsub(); };
  }, []);

  // Compute practice-specific stats
  const stats: PracticeStatSummary = useMemo(() => {
    const total = sessions.length;
    const totalQ = sessions.reduce((s, r) => s + (r.questions_total || 0), 0);
    const totalCorrect = sessions.reduce((s, r) => s + (r.questions_correct || 0), 0);
    const totalIncorrect = sessions.reduce((s, r) => s + (r.questions_incorrect || 0), 0);
    const totalTimeout = sessions.reduce((s, r) => s + (r.questions_timeout || 0), 0);
    const totalHints = sessions.reduce((s, r) => s + (r.hints_used || 0), 0);
    const avgAcc = total > 0 ? Math.round(sessions.reduce((s, r) => s + Number(r.accuracy), 0) / total) : 0;
    const avgSpd = total > 0 ? Math.round(sessions.reduce((s, r) => s + Number(r.avg_speed_seconds), 0) / total) : 0;
    const bestAcc = total > 0 ? Math.max(...sessions.map(r => Number(r.accuracy))) : 0;
    const streak = profile?.daily_streak || 0;
    return { total_sessions: total, total_questions: totalQ, total_correct: totalCorrect, total_incorrect: totalIncorrect, total_timeout: totalTimeout, total_hints: totalHints, avg_accuracy: avgAcc, avg_speed: avgSpd, best_accuracy: bestAcc, current_streak: streak };
  }, [sessions, profile]);

  // Topic breakdown from practice sessions
  const topicBreakdown = useMemo(() => {
    const map: Record<string, { total: number; correct: number }> = {};
    for (const s of sessions) {
      const topics = s.topics_practiced || [];
      for (const t of topics) {
        if (!map[t]) map[t] = { total: 0, correct: 0 };
        map[t].total += (s.questions_total || 0);
        map[t].correct += (s.questions_correct || 0);
      }
    }
    return Object.entries(map)
      .map(([topic, v]) => ({ topic, total: v.total, correct: v.correct, accuracy: v.total > 0 ? Math.round((v.correct / v.total) * 100) : 0 }))
      .sort((a, b) => b.accuracy - a.accuracy);
  }, [sessions]);

  // Difficulty breakdown
  const difficultyBreakdown = useMemo(() => {
    const map: Record<string, { total: number; correct: number }> = {};
    for (const s of sessions) {
      const d = s.difficulty || 'Mixed';
      if (!map[d]) map[d] = { total: 0, correct: 0 };
      map[d].total += (s.questions_total || 0);
      map[d].correct += (s.questions_correct || 0);
    }
    return Object.entries(map).map(([difficulty, v]) => ({
      difficulty,
      total: v.total,
      correct: v.correct,
      accuracy: v.total > 0 ? Math.round((v.correct / v.total) * 100) : 0,
    }));
  }, [sessions]);

  // Accuracy trend (last 10 sessions)
  const accuracyTrend = useMemo(() => {
    return sessions.slice(0).reverse().slice(-10).map((s, i) => ({
      session: `S${i + 1}`,
      accuracy: Math.round(Number(s.accuracy)),
      speed: Math.round(Number(s.avg_speed_seconds)),
    }));
  }, [sessions]);

  // Speed trend
  const speedTrend = useMemo(() => {
    return sessions.slice(0).reverse().slice(-10).map((s, i) => ({
      session: `S${i + 1}`,
      speed: Math.round(Number(s.avg_speed_seconds)),
    }));
  }, [sessions]);

  // Pie chart data for correct/incorrect/timeout
  const pieData = useMemo(() => {
    const total = stats.total_correct + stats.total_incorrect + stats.total_timeout;
    if (total === 0) return [];
    return [
      { name: 'Correct', value: stats.total_correct, color: 'var(--success)' },
      { name: 'Incorrect', value: stats.total_incorrect, color: 'var(--danger)' },
      { name: 'Timeout', value: stats.total_timeout, color: 'var(--warning)' },
    ].filter(d => d.value > 0);
  }, [stats]);

  // Hints usage trend
  const hintsBySession = useMemo(() => {
    return sessions.slice(0).reverse().slice(-10).map((s, i) => ({
      session: `S${i + 1}`,
      hints: s.hints_used || 0,
    }));
  }, [sessions]);

  if (loading) return <PracticeDashboardSkeleton />;

  return (
    <AppLayout>
      <div className="min-h-screen bg-background">
        {/* Header */}
        <div className="sticky top-0 z-10 bg-card/80 backdrop-blur-sm border-b border-border">
          <div className="max-w-screen-xl mx-auto px-4 lg:px-8 h-14 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <BookOpen size={18} className="text-primary" />
              <span className="text-sm font-bold text-foreground">Practice Dashboard</span>
            </div>
            <div className="flex items-center gap-2">
              <Link href="/practice" className="btn-primary flex items-center gap-1.5 px-3 py-1.5 text-xs">
                <Play size={12} /> Practice Now
              </Link>
            </div>
          </div>
        </div>

        <div className="max-w-screen-xl mx-auto px-4 lg:px-8 py-6 space-y-6">

          {/* Row 1: Summary Cards */}
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
            <div className="card-elevated p-4">
              <div className="w-7 h-7 rounded-lg bg-primary/20 flex items-center justify-center mb-2">
                <Activity size={13} className="text-primary" />
              </div>
              <p className="font-mono-data text-2xl font-extrabold text-foreground">{mounted ? stats.total_sessions : '—'}</p>
              <p className="text-[10px] text-muted-foreground mt-0.5">Practice Sessions</p>
            </div>
            <div className="card-elevated p-4">
              <div className="w-7 h-7 rounded-lg bg-info/20 flex items-center justify-center mb-2">
                <BookOpen size={13} className="text-info" />
              </div>
              <p className="font-mono-data text-2xl font-extrabold text-foreground">{mounted ? stats.total_questions : '—'}</p>
              <p className="text-[10px] text-muted-foreground mt-0.5">Questions Answered</p>
            </div>
            <div className="card-elevated p-4">
              <div className="w-7 h-7 rounded-lg bg-success/20 flex items-center justify-center mb-2">
                <Target size={13} className="text-success" />
              </div>
              <p className="font-mono-data text-2xl font-extrabold text-success">{mounted ? `${stats.avg_accuracy}%` : '—'}</p>
              <p className="text-[10px] text-muted-foreground mt-0.5">Avg Accuracy</p>
            </div>
            <div className="card-elevated p-4">
              <div className="w-7 h-7 rounded-lg bg-warning/20 flex items-center justify-center mb-2">
                <Zap size={13} className="text-warning" />
              </div>
              <p className="font-mono-data text-2xl font-extrabold text-warning">{mounted ? `${stats.avg_speed}s` : '—'}</p>
              <p className="text-[10px] text-muted-foreground mt-0.5">Avg Speed</p>
            </div>
            <div className="card-elevated p-4">
              <div className="w-7 h-7 rounded-lg bg-accent/20 flex items-center justify-center mb-2">
                <Lightbulb size={13} className="text-accent" />
              </div>
              <p className="font-mono-data text-2xl font-extrabold text-accent">{mounted ? stats.total_hints : '—'}</p>
              <p className="text-[10px] text-muted-foreground mt-0.5">Hints Used</p>
            </div>
            <div className="card-elevated p-4">
              <div className="w-7 h-7 rounded-lg bg-warning/20 flex items-center justify-center mb-2">
                <Flame size={13} className="text-warning streak-flame" />
              </div>
              <p className="font-mono-data text-2xl font-extrabold text-warning">{mounted ? `${stats.current_streak}d` : '—'}</p>
              <p className="text-[10px] text-muted-foreground mt-0.5">Current Streak</p>
            </div>
          </div>

          {/* Row 2: Accuracy Trend + Speed Trend */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            <div className="card-elevated p-5">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-2">
                  <TrendingUp size={15} className="text-success" />
                  <h2 className="text-sm font-semibold text-foreground">Accuracy Trend</h2>
                </div>
                <span className="text-xs text-muted-foreground">Last {accuracyTrend.length} sessions</span>
              </div>
              {mounted && accuracyTrend.length > 0 ? (
                <ResponsiveContainer width="100%" height={180}>
                  <AreaChart data={accuracyTrend} margin={{ top: 4, right: 4, left: -20, bottom: 0 }}>
                    <defs><linearGradient id="accGrad" x1="0" y1="0" x2="0" y2="1"><stop offset="5%" stopColor="#22C55E" stopOpacity={0.3} /><stop offset="95%" stopColor="#22C55E" stopOpacity={0} /></linearGradient></defs>
                    <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                    <XAxis dataKey="session" tick={{ fontSize: 11, fill: 'var(--muted-foreground)' }} axisLine={false} tickLine={false} />
                    <YAxis domain={[0, 100]} tick={{ fontSize: 11, fill: 'var(--muted-foreground)' }} axisLine={false} tickLine={false} />
                    <Tooltip content={<CustomTooltip />} />
                    <Area type="monotone" dataKey="accuracy" stroke="#22C55E" strokeWidth={2} fill="url(#accGrad)" dot={{ fill: '#22C55E', r: 3 }} />
                  </AreaChart>
                </ResponsiveContainer>
              ) : <div className="h-[180px] flex items-center justify-center text-xs text-muted-foreground">No practice data yet</div>}
            </div>
            <div className="card-elevated p-5">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-2">
                  <Clock size={15} className="text-warning" />
                  <h2 className="text-sm font-semibold text-foreground">Speed Trend</h2>
                </div>
                <span className="text-xs text-muted-foreground">Avg seconds/Q</span>
              </div>
              {mounted && speedTrend.length > 0 ? (
                <ResponsiveContainer width="100%" height={180}>
                  <BarChart data={speedTrend} margin={{ top: 4, right: 4, left: -20, bottom: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                    <XAxis dataKey="session" tick={{ fontSize: 11, fill: 'var(--muted-foreground)' }} axisLine={false} tickLine={false} />
                    <YAxis tick={{ fontSize: 11, fill: 'var(--muted-foreground)' }} axisLine={false} tickLine={false} />
                    <Tooltip content={<CustomTooltip />} />
                    <Bar dataKey="speed" fill="#F59E0B" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              ) : <div className="h-[180px] flex items-center justify-center text-xs text-muted-foreground">No practice data yet</div>}
            </div>
          </div>

          {/* Row 3: Topic Breakdown + Difficulty Breakdown */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            <div className="card-elevated p-5">
              <div className="flex items-center gap-2 mb-4">
                <Layers size={15} className="text-primary" />
                <h2 className="text-sm font-semibold text-foreground">Topic Performance</h2>
              </div>
              {topicBreakdown.length > 0 ? (
                <div className="flex flex-col gap-3">
                  {topicBreakdown.map(t => (
                    <div key={`tp-${t.topic}`} className="flex items-center gap-3">
                      <div className="w-28 text-[11px] text-foreground font-medium truncate flex-shrink-0">{t.topic}</div>
                      <div className="flex-1 h-2 bg-muted rounded-full overflow-hidden">
                        <div className={`h-full rounded-full ${t.accuracy >= 80 ? 'bg-success' : t.accuracy >= 60 ? 'bg-warning' : 'bg-danger'}`} style={{ width: `${t.accuracy}%` }} />
                      </div>
                      <span className={`font-mono-data text-xs font-bold w-8 text-right ${t.accuracy >= 80 ? 'text-success' : t.accuracy >= 60 ? 'text-warning' : 'text-danger'}`}>{t.accuracy}%</span>
                      <span className="text-[10px] text-muted-foreground w-10 text-right">{t.correct}/{t.total}</span>
                    </div>
                  ))}
                </div>
              ) : <p className="text-xs text-muted-foreground text-center py-8">No data yet</p>}
            </div>

            <div className="card-elevated p-5">
              <div className="flex items-center gap-2 mb-4">
                <BarChart3 size={15} className="text-accent" />
                <h2 className="text-sm font-semibold text-foreground">By Difficulty</h2>
              </div>
              {difficultyBreakdown.length > 0 ? (
                <div className="flex flex-col gap-3">
                  {difficultyBreakdown.map(d => (
                    <div key={`diff-${d.difficulty}`} className="flex items-center gap-3">
                      <Badge variant={d.difficulty === 'Easy' ? 'success' : d.difficulty === 'Medium' ? 'warning' : 'danger'} size="sm">{d.difficulty}</Badge>
                      <div className="flex-1 h-2 bg-muted rounded-full overflow-hidden">
                        <div className={`h-full rounded-full ${d.accuracy >= 80 ? 'bg-success' : d.accuracy >= 60 ? 'bg-warning' : 'bg-danger'}`} style={{ width: `${d.accuracy}%` }} />
                      </div>
                      <span className="font-mono-data text-xs font-bold text-foreground w-10 text-right">{d.accuracy}%</span>
                      <span className="text-[10px] text-muted-foreground w-10 text-right">{d.correct}/{d.total}</span>
                    </div>
                  ))}
                </div>
              ) : <p className="text-xs text-muted-foreground text-center py-8">No data yet</p>}
            </div>
          </div>

          {/* Row 4: Pie Chart + Hint Usage */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            <div className="card-elevated p-5">
              <div className="flex items-center gap-2 mb-4">
                <Target size={15} className="text-success" />
                <h2 className="text-sm font-semibold text-foreground">Question Breakdown</h2>
              </div>
              {pieData.length > 0 ? (
                <div className="flex items-center justify-center gap-6">
                  <ResponsiveContainer width={160} height={160}>
                    <PieChart>
                      <Pie data={pieData} cx="50%" cy="50%" innerRadius={40} outerRadius={70} dataKey="value" paddingAngle={3}>
                        {pieData.map((entry, i) => <Cell key={`cell-${i}`} fill={entry.color} />)}
                      </Pie>
                      <Tooltip />
                    </PieChart>
                  </ResponsiveContainer>
                  <div className="flex flex-col gap-2">
                    {pieData.map(d => (
                      <div key={d.name} className="flex items-center gap-2 text-xs">
                        <div className="w-3 h-3 rounded-sm" style={{ background: d.color }} />
                        <span className="text-muted-foreground">{d.name}</span>
                        <span className="font-mono-data font-bold text-foreground">{d.value}</span>
                      </div>
                    ))}
                    <div className="pt-2 border-t border-border">
                      <p className="text-[10px] text-muted-foreground">Total: {stats.total_questions} questions</p>
                    </div>
                  </div>
                </div>
              ) : <p className="text-xs text-muted-foreground text-center py-8">No data yet</p>}
            </div>

            <div className="card-elevated p-5">
              <div className="flex items-center gap-2 mb-4">
                <Lightbulb size={15} className="text-accent" />
                <h2 className="text-sm font-semibold text-foreground">Hints Used by Session</h2>
              </div>
              {hintsBySession.length > 0 ? (
                <ResponsiveContainer width="100%" height={180}>
                  <BarChart data={hintsBySession} margin={{ top: 4, right: 4, left: -20, bottom: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                    <XAxis dataKey="session" tick={{ fontSize: 11, fill: 'var(--muted-foreground)' }} axisLine={false} tickLine={false} />
                    <YAxis allowDecimals={false} tick={{ fontSize: 11, fill: 'var(--muted-foreground)' }} axisLine={false} tickLine={false} />
                    <Tooltip />
                    <Bar dataKey="hints" fill="#A78BFA" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              ) : <p className="text-xs text-muted-foreground text-center py-8">No hints used yet</p>}
            </div>
          </div>

          {/* Row 5: Recent Sessions Table */}
          <div className="card-elevated p-5">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <Activity size={15} className="text-primary" />
                <h2 className="text-sm font-semibold text-foreground">Recent Practice Sessions</h2>
                <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-success/20 text-success font-semibold">Live</span>
              </div>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-border">
                    {['Date', 'Difficulty', 'Q', 'Correct', 'Accuracy', 'Speed', 'Hints', 'Topics'].map(h => (
                      <th key={`h-${h}`} className="text-left text-[11px] font-semibold text-muted-foreground pb-2 pr-3 last:pr-0">{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {sessions.slice(0, 20).map(s => (
                    <tr key={s.id} className="border-b border-border/40 hover:bg-muted/30 transition-colors">
                      <td className="py-2.5 pr-3 text-xs text-muted-foreground font-mono-data">{new Date(s.session_date).toLocaleDateString()}</td>
                      <td className="py-2.5 pr-3">
                        <Badge variant={s.difficulty === 'Easy' ? 'success' : s.difficulty === 'Medium' ? 'warning' : 'danger'} size="sm">{s.difficulty}</Badge>
                      </td>
                      <td className="py-2.5 pr-3 font-mono-data text-xs">{s.questions_total}</td>
                      <td className="py-2.5 pr-3 font-mono-data text-xs text-success">{s.questions_correct}</td>
                      <td className="py-2.5 pr-3"><span className={`font-mono-data text-xs font-bold ${Number(s.accuracy) >= 80 ? 'text-success' : Number(s.accuracy) >= 60 ? 'text-warning' : 'text-danger'}`}>{Math.round(Number(s.accuracy))}%</span></td>
                      <td className="py-2.5 pr-3 font-mono-data text-xs text-info">{Math.round(Number(s.avg_speed_seconds))}s</td>
                      <td className="py-2.5 pr-3 font-mono-data text-xs text-accent">{s.hints_used || 0}</td>
                      <td className="py-2.5 text-xs text-muted-foreground max-w-[120px] truncate">{(s.topics_practiced || []).join(', ') || '—'}</td>
                    </tr>
                  ))}
                  {sessions.length === 0 && (
                    <tr><td colSpan={8} className="py-8 text-center text-xs text-muted-foreground">No practice sessions yet. Start your first practice session!</td></tr>
                  )}
                </tbody>
              </table>
            </div>
            {sessions.length > 0 && (
              <div className="mt-4 pt-3 border-t border-border flex items-center gap-4 text-xs text-muted-foreground">
                <span className="text-success font-semibold">{stats.total_correct} correct</span>
                <span className="text-danger font-semibold">{stats.total_incorrect} incorrect</span>
                <span className="text-warning font-semibold">{stats.total_timeout} timeout</span>
                <span className="text-accent font-semibold ml-auto">{stats.total_hints} hints used</span>
                <Link href="/practice" className="btn-primary flex items-center gap-1.5 px-3 py-1 text-xs">
                  <Play size={10} /> New Practice
                </Link>
              </div>
            )}
          </div>

        </div>
      </div>
    </AppLayout>
  );
}