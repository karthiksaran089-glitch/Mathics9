'use client';
// ─────────────────────────────────────────────────────────────
// Ranked Dashboard
// ─────────────────────────────────────────────────────────────
// Data Source: `ranked_sessions` table (Supabase)
// Written by: RankedModeClient.tsx → saveRankedSession()
// Columns: user_id, session_date, questions_total, questions_correct,
//   questions_incorrect, questions_timeout, accuracy, avg_speed_seconds,
//   lp_before, lp_after, lp_change, rank_before, rank_after,
//   topics_played, topics_banned
//
// Real-time Sync: Subscribes to ranked_sessions and user_profiles
//   via Supabase Realtime for cross-tab/cross-device sync.
// ─────────────────────────────────────────────────────────────

import React, { useState, useEffect, useMemo } from 'react';
import {
  Trophy, TrendingUp, Target, Clock, BarChart3, Activity,
  CheckCircle2, XCircle, Zap, Flame, ChevronUp, ChevronDown,
  Play, Award, Swords, Minus
} from 'lucide-react';
import { createClient } from '@/lib/supabase/client';
import AppLayout from '@/components/AppLayout';
import Badge from '@/components/ui/Badge';
import { Skeleton as LoadingSkeleton } from '@/components/ui/LoadingSkeleton';
import {
  AreaChart, Area, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell,
} from 'recharts';
import Link from 'next/link';

// ─── Types ────────────────────────────────────────────────────────────────────

interface RankedSession {
  id: string;
  session_date: string;
  questions_total: number;
  questions_correct: number;
  questions_incorrect: number;
  questions_timeout: number;
  accuracy: number;
  avg_speed_seconds: number;
  lp_change: number;
  lp_before: number;
  lp_after: number;
  rank_before: string;
  rank_after: string;
  topics_played: string[];
  topics_banned: string[];
}

function CustomTooltip({ active, payload, label }: { active?: boolean; payload?: { value: number }[]; label?: string }) {
  if (active && payload && payload.length) {
    return (
      <div className="card-elevated px-3 py-2 text-xs">
        <p className="text-muted-foreground mb-0.5">{label}</p>
        <p className="font-mono-data font-bold text-foreground">{payload[0].value}</p>
      </div>
    );
  }
  return null;
}

const RANK_TIERS = [
  { name: 'Bronze', min: 0, max: 499, color: '#CD7F32' },
  { name: 'Silver', min: 500, max: 999, color: '#A8B8C8' },
  { name: 'Gold', min: 1000, max: 1499, color: '#F59E0B' },
  { name: 'Platinum', min: 1500, max: 1999, color: '#06B6D4' },
  { name: 'Diamond', min: 2000, max: 2499, color: '#818CF8' },
  { name: 'Grandmaster', min: 2500, max: Infinity, color: '#EC4899' },
];

function getRankForLP(lp: number) {
  return RANK_TIERS.find(r => lp >= r.min && lp <= r.max) || RANK_TIERS[0];
}

function RankedDashboardSkeleton() {
  return (
    <div className="min-h-screen bg-background">
      <div className="sticky top-0 z-10 bg-card/80 backdrop-blur-sm border-b border-border">
        <div className="max-w-screen-xl mx-auto px-4 lg:px-8 h-14 flex items-center">
          <LoadingSkeleton className="h-5 w-32" />
        </div>
      </div>
      <div className="max-w-screen-xl mx-auto px-4 lg:px-8 py-6 space-y-6">
        {[1,2,3,4].map(i => <LoadingSkeleton key={i} className="h-40 w-full rounded-xl" />)}
      </div>
    </div>
  );
}

export default function RankedDashboard() {
  const [mounted, setMounted] = useState(false);
  const [loading, setLoading] = useState(true);
  const [sessions, setSessions] = useState<RankedSession[]>([]);
  const [profile, setProfile] = useState<{ lp: number; rank: string; daily_streak: number; longest_streak: number; total_ranked_sessions: number } | null>(null);

  // Real-time subscription
  useEffect(() => {
    let unsub: (() => void) | undefined;
    const init = async () => {
      setMounted(true);
      const supabase = createClient();
      if (!supabase) { setLoading(false); return; }
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) { setLoading(false); return; }

      const [sessionRes, profileRes] = await Promise.all([
        supabase.from('ranked_sessions')
          .select('*')
          .eq('user_id', user.id)
          .order('session_date', { ascending: false })
          .limit(50),
        supabase.from('profile_stats')
          .select('lp, rank, daily_streak, longest_streak, total_ranked_sessions')
          .eq('user_id', user.id)
          .maybeSingle(),
      ]);

      if (sessionRes.data) setSessions(sessionRes.data);
      if (profileRes.data) setProfile(profileRes.data);
      setLoading(false);

      // Real-time sync
      const channel = supabase.channel('ranked-dashboard-sync')
        .on('postgres_changes',
          { event: '*', schema: 'public', table: 'ranked_sessions', filter: `user_id=eq.${user.id}` },
          (payload: any) => {
            if (payload.eventType === 'INSERT') {
              setSessions(prev => [payload.new as RankedSession, ...prev].slice(0, 50));
            } else if (payload.eventType === 'DELETE') {
              setSessions(prev => prev.filter(s => s.id !== payload.old.id));
            } else if (payload.eventType === 'UPDATE') {
              setSessions(prev => prev.map(s => s.id === payload.new.id ? payload.new : s));
            }
          }
        )
        .on('postgres_changes',
          { event: 'UPDATE', schema: 'public', table: 'user_profiles', filter: `id=eq.${user.id}` },
          (payload: any) => {
            setProfile((prev: any) => ({ ...prev, ...payload.new }));
          }
        )
        .subscribe();

      unsub = () => { supabase.removeChannel(channel); };
    };
    init();
    return () => { if (unsub) unsub(); };
  }, []);

  const totalLP = profile?.lp ?? 0;
  const rank = getRankForLP(totalLP);
  const nextRank = RANK_TIERS[RANK_TIERS.indexOf(rank) + 1];
  const rankProgress = nextRank ? Math.round(((totalLP - rank.min) / (nextRank.min - rank.min)) * 100) : 100;
  const totalRanked = sessions.length;

  // Compute ranked-specific stats
  const stats = useMemo(() => {
    const wins = sessions.filter(s => s.lp_change > 0).length;
    const losses = sessions.filter(s => s.lp_change < 0).length;
    const draws = sessions.filter(s => s.lp_change === 0).length;
    const winRate = totalRanked > 0 ? Math.round((wins / totalRanked) * 100) : 0;
    const totalQ = sessions.reduce((sum, s) => sum + (s.questions_total || 0), 0);
    const totalCorrect = sessions.reduce((sum, s) => sum + (s.questions_correct || 0), 0);
    const totalLPGained = sessions.reduce((sum, s) => sum + (s.lp_change > 0 ? s.lp_change : 0), 0);
    const totalLPLost = sessions.reduce((sum, s) => sum + (s.lp_change < 0 ? Math.abs(s.lp_change) : 0), 0);
    const avgAccuracy = totalRanked > 0 ? Math.round(sessions.reduce((sum, s) => sum + Number(s.accuracy), 0) / totalRanked) : 0;
    const avgSpeed = totalRanked > 0 ? Math.round(sessions.reduce((sum, s) => sum + Number(s.avg_speed_seconds), 0) / totalRanked) : 0;
    const bestAccuracy = totalRanked > 0 ? Math.max(...sessions.map(s => Number(s.accuracy))) : 0;
    const bestLPGain = totalRanked > 0 ? Math.max(...sessions.map(s => s.lp_change)) : 0;
    return { wins, losses, draws, winRate, totalQ, totalCorrect, totalLPGained, totalLPLost, avgAccuracy, avgSpeed, bestAccuracy, bestLPGain, totalRanked };
  }, [sessions]);

  // LP trend chart
  const lpChartData = useMemo(() => {
    const sorted = [...sessions].reverse();
    return sorted.slice(-10).map((s, i) => ({
      session: `M${i + 1}`,
      lp: s.lp_after,
      change: s.lp_change,
    }));
  }, [sessions]);

  // Accuracy trend
  const accuracyTrend = useMemo(() => {
    return [...sessions].reverse().slice(-10).map((s, i) => ({
      session: `M${i + 1}`,
      accuracy: Math.round(Number(s.accuracy)),
      speed: Math.round(Number(s.avg_speed_seconds)),
    }));
  }, [sessions]);

  // Topic performance
  const topicBreakdown = useMemo(() => {
    const map: Record<string, { total: number; correct: number }> = {};
    for (const s of sessions) {
      const topics = s.topics_played || [];
      for (const t of topics) {
        if (!map[t]) map[t] = { total: 0, correct: 0 };
        map[t].total += (s.questions_total || 0);
        map[t].correct += (s.questions_correct || 0);
      }
    }
    return Object.entries(map).map(([topic, v]) => ({ topic, total: v.total, correct: v.correct, accuracy: v.total > 0 ? Math.round((v.correct / v.total) * 100) : 0 })).sort((a, b) => b.accuracy - a.accuracy);
  }, [sessions]);

  // Pie data
  const pieData = useMemo(() => {
    const total = stats.wins + stats.losses + stats.draws;
    if (total === 0) return [];
    return [
      { name: 'Wins', value: stats.wins, color: 'var(--success)' },
      { name: 'Losses', value: stats.losses, color: 'var(--danger)' },
      { name: 'Draws', value: stats.draws, color: 'var(--warning)' },
    ].filter(d => d.value > 0);
  }, [stats]);

  // LP change chart
  const lpChangeData = useMemo(() => {
    return sessions.slice(0, 15).map((s, i) => ({
      match: `M${totalRanked - i}`,
      change: s.lp_change,
    })).reverse();
  }, [sessions, totalRanked]);

  if (loading) return <RankedDashboardSkeleton />;

  return (
    <AppLayout>
      <div className="min-h-screen bg-background">
        {/* Header */}
        <div className="sticky top-0 z-10 bg-card/80 backdrop-blur-sm border-b border-border">
          <div className="max-w-screen-xl mx-auto px-4 lg:px-8 h-14 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Swords size={18} className="text-primary" />
              <span className="text-sm font-bold text-foreground">Ranked Dashboard</span>
            </div>
            <div className="flex items-center gap-2">
              <Link href="/ranked-mode-screen" className="btn-primary flex items-center gap-1.5 px-3 py-1.5 text-xs">
                <Play size={12} /> Play Ranked
              </Link>
            </div>
          </div>
        </div>

        <div className="max-w-screen-xl mx-auto px-4 lg:px-8 py-6 space-y-6">

          {/* Row 1: Rank + Key Stats */}
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
            <div className="card-elevated p-4 lg:col-span-1">
              <div className="flex items-center justify-between mb-2">
                <div className="w-7 h-7 rounded-lg flex items-center justify-center" style={{ background: `${rank.color}22` }}>
                  <Trophy size={13} style={{ color: rank.color }} />
                </div>
                {nextRank && <span className="text-[10px] text-muted-foreground">{nextRank.min - totalLP} LP to {nextRank.name}</span>}
              </div>
              <p className="text-lg font-extrabold" style={{ color: rank.color }}>{mounted ? rank.name : '—'}</p>
              <div className="mt-1.5 h-1.5 bg-muted rounded-full overflow-hidden">
                <div className="h-full rounded-full transition-all duration-700" style={{ width: `${mounted ? rankProgress : 0}%`, background: rank.color }} />
              </div>
              <p className="text-[10px] text-muted-foreground mt-1">{mounted ? totalLP : '—'} LP</p>
            </div>
            <div className="card-elevated p-4">
              <div className="w-7 h-7 rounded-lg bg-primary/20 flex items-center justify-center mb-2">
                <Swords size={13} className="text-primary" />
              </div>
              <p className="font-mono-data text-2xl font-extrabold text-foreground">{mounted ? stats.totalRanked : '—'}</p>
              <p className="text-[10px] text-muted-foreground">Ranked Matches</p>
            </div>
            <div className="card-elevated p-4">
              <div className="w-7 h-7 rounded-lg bg-success/20 flex items-center justify-center mb-2">
                <TrendingUp size={13} className="text-success" />
              </div>
              <p className="font-mono-data text-2xl font-extrabold text-success">{mounted ? `${stats.winRate}%` : '—'}</p>
              <p className="text-[10px] text-muted-foreground">Win Rate</p>
            </div>
            <div className="card-elevated p-4">
              <div className="w-7 h-7 rounded-lg bg-success/20 flex items-center justify-center mb-2">
                <CheckCircle2 size={13} className="text-success" />
              </div>
              <p className="font-mono-data text-2xl font-extrabold text-success">{mounted ? stats.wins : '—'}</p>
              <p className="text-[10px] text-muted-foreground">Wins</p>
            </div>
            <div className="card-elevated p-4">
              <div className="w-7 h-7 rounded-lg bg-danger/20 flex items-center justify-center mb-2">
                <XCircle size={13} className="text-danger" />
              </div>
              <p className="font-mono-data text-2xl font-extrabold text-danger">{mounted ? stats.losses : '—'}</p>
              <p className="text-[10px] text-muted-foreground">Losses</p>
            </div>
            <div className="card-elevated p-4">
              <div className="w-7 h-7 rounded-lg bg-accent/20 flex items-center justify-center mb-2">
                <Award size={13} className="text-accent" />
              </div>
              <p className="font-mono-data text-2xl font-extrabold text-accent">{mounted ? stats.bestLPGain : '—'}</p>
              <p className="text-[10px] text-muted-foreground">Best LP Gain</p>
            </div>
          </div>

          {/* Row 2: LP Trend + Win/Loss Pie */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            <div className="card-elevated p-5">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-2">
                  <TrendingUp size={15} className="text-primary" />
                  <h2 className="text-sm font-semibold text-foreground">LP Progression</h2>
                </div>
                <span className="text-xs text-muted-foreground">Last {lpChartData.length} matches</span>
              </div>
              {lpChartData.length > 0 ? (
                <ResponsiveContainer width="100%" height={180}>
                  <AreaChart data={lpChartData} margin={{ top: 4, right: 4, left: -20, bottom: 0 }}>
                    <defs><linearGradient id="lpGradR" x1="0" y1="0" x2="0" y2="1"><stop offset="5%" stopColor="#7C3AED" stopOpacity={0.3} /><stop offset="95%" stopColor="#7C3AED" stopOpacity={0} /></linearGradient></defs>
                    <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                    <XAxis dataKey="session" tick={{ fontSize: 11, fill: 'var(--muted-foreground)' }} axisLine={false} tickLine={false} />
                    <YAxis tick={{ fontSize: 11, fill: 'var(--muted-foreground)' }} axisLine={false} tickLine={false} />
                    <Tooltip content={<CustomTooltip />} />
                    <Area type="monotone" dataKey="lp" stroke="#7C3AED" strokeWidth={2} fill="url(#lpGradR)" dot={{ fill: '#7C3AED', r: 3 }} />
                  </AreaChart>
                </ResponsiveContainer>
              ) : <div className="h-[180px] flex items-center justify-center text-xs text-muted-foreground">No matches yet</div>}
            </div>
            <div className="card-elevated p-5">
              <div className="flex items-center gap-2 mb-4">
                <Target size={15} className="text-success" />
                <h2 className="text-sm font-semibold text-foreground">Match Results</h2>
              </div>
              {pieData.length > 0 ? (
                <div className="flex items-center justify-center gap-6">
                  <ResponsiveContainer width={160} height={160}>
                    <PieChart>
                      <Pie data={pieData} cx="50%" cy="50%" innerRadius={40} outerRadius={70} dataKey="value" paddingAngle={3}>
                        {pieData.map((e, i) => <Cell key={i} fill={e.color} />)}
                      </Pie>
                      <Tooltip />
                    </PieChart>
                  </ResponsiveContainer>
                  <div className="flex flex-col gap-2">
                    {pieData.map(d => (
                      <div key={d.name} className="flex items-center gap-2 text-xs">
                        <div className="w-3 h-3 rounded-sm" style={{ background: d.color }} />
                        <span className="text-muted-foreground">{d.name}</span>
                        <span className="font-mono-data font-bold text-foreground">{d.value}</span>
                      </div>
                    ))}
                    <div className="pt-2 border-t border-border">
                      <p className="text-[10px] text-muted-foreground">{stats.totalRanked} total matches</p>
                    </div>
                  </div>
                </div>
              ) : <div className="h-[180px] flex items-center justify-center text-xs text-muted-foreground">No matches yet</div>}
            </div>
          </div>

          {/* Row 3: Accuracy Trend + LP Change Chart */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            <div className="card-elevated p-5">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-2">
                  <Target size={15} className="text-success" />
                  <h2 className="text-sm font-semibold text-foreground">Accuracy per Match</h2>
                </div>
                <span className="text-xs text-muted-foreground">Avg: {stats.avgAccuracy}%</span>
              </div>
              {accuracyTrend.length > 0 ? (
                <ResponsiveContainer width="100%" height={180}>
                  <BarChart data={accuracyTrend} margin={{ top: 4, right: 4, left: -20, bottom: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                    <XAxis dataKey="session" tick={{ fontSize: 11, fill: 'var(--muted-foreground)' }} axisLine={false} tickLine={false} />
                    <YAxis domain={[0, 100]} tick={{ fontSize: 11, fill: 'var(--muted-foreground)' }} axisLine={false} tickLine={false} />
                    <Tooltip content={<CustomTooltip />} />
                    <Bar dataKey="accuracy" fill="#22C55E" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              ) : <div className="h-[180px] flex items-center justify-center text-xs text-muted-foreground">No matches yet</div>}
            </div>
            <div className="card-elevated p-5">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-2">
                  <Zap size={15} className="text-accent" />
                  <h2 className="text-sm font-semibold text-foreground">LP Change per Match</h2>
                </div>
                <span className="text-xs text-muted-foreground">Gained: +{stats.totalLPGained} · Lost: -{stats.totalLPLost}</span>
              </div>
              {lpChangeData.length > 0 ? (
                <ResponsiveContainer width="100%" height={180}>
                  <BarChart data={lpChangeData} margin={{ top: 4, right: 4, left: -20, bottom: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                    <XAxis dataKey="match" tick={{ fontSize: 11, fill: 'var(--muted-foreground)' }} axisLine={false} tickLine={false} />
                    <YAxis tick={{ fontSize: 11, fill: 'var(--muted-foreground)' }} axisLine={false} tickLine={false} />
                    <Tooltip />
                    <Bar dataKey="change" radius={[4, 4, 0, 0]}>
                      {lpChangeData.map((entry, i) => (
                        <Cell key={i} fill={entry.change >= 0 ? 'var(--success)' : 'var(--danger)'} />
                      ))}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              ) : <div className="h-[180px] flex items-center justify-center text-xs text-muted-foreground">No matches yet</div>}
            </div>
          </div>

          {/* Row 4: Topic + Speed Stats */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            <div className="card-elevated p-5">
              <div className="flex items-center gap-2 mb-4">
                <BarChart3 size={15} className="text-primary" />
                <h2 className="text-sm font-semibold text-foreground">Topic Performance</h2>
              </div>
              {topicBreakdown.length > 0 ? (
                <div className="flex flex-col gap-3">
                  {topicBreakdown.map(t => (
                    <div key={`rt-${t.topic}`} className="flex items-center gap-3">
                      <div className="w-28 text-[11px] text-foreground font-medium truncate flex-shrink-0">{t.topic}</div>
                      <div className="flex-1 h-2 bg-muted rounded-full overflow-hidden">
                        <div className={`h-full rounded-full ${t.accuracy >= 80 ? 'bg-success' : t.accuracy >= 60 ? 'bg-warning' : 'bg-danger'}`} style={{ width: `${t.accuracy}%` }} />
                      </div>
                      <span className={`font-mono-data text-xs font-bold w-8 text-right ${t.accuracy >= 80 ? 'text-success' : t.accuracy >= 60 ? 'text-warning' : 'text-danger'}`}>{t.accuracy}%</span>
                      <span className="text-[10px] text-muted-foreground w-10 text-right">{t.correct}/{t.total}</span>
                    </div>
                  ))}
                </div>
              ) : <p className="text-xs text-muted-foreground text-center py-8">No data yet</p>}
            </div>
            <div className="card-elevated p-5">
              <div className="flex items-center gap-2 mb-4">
                <Clock size={15} className="text-warning" />
                <h2 className="text-sm font-semibold text-foreground">Performance Summary</h2>
              </div>
              {totalRanked > 0 ? (
                <div className="grid grid-cols-2 gap-4">
                  {[
                    { label: 'Avg Accuracy', value: `${stats.avgAccuracy}%`, color: 'text-success' },
                    { label: 'Best Accuracy', value: `${stats.bestAccuracy}%`, color: 'text-success' },
                    { label: 'Avg Speed', value: `${stats.avgSpeed}s`, color: 'text-info' },
                    { label: 'Total Questions', value: `${stats.totalQ}`, color: 'text-foreground' },
                    { label: 'Total Correct', value: `${stats.totalCorrect}`, color: 'text-success' },
                    { label: 'LP Gained', value: `+${stats.totalLPGained}`, color: 'text-success' },
                    { label: 'LP Lost', value: `-${stats.totalLPLost}`, color: 'text-danger' },
                    { label: 'Net LP', value: `${stats.totalLPGained - stats.totalLPLost >= 0 ? '+' : ''}${stats.totalLPGained - stats.totalLPLost}`, color: stats.totalLPGained - stats.totalLPLost >= 0 ? 'text-success' : 'text-danger' },
                  ].map(item => (
                    <div key={item.label} className="flex items-center justify-between p-3 rounded-xl bg-muted/30">
                      <span className="text-xs text-muted-foreground">{item.label}</span>
                      <span className={`font-mono-data text-sm font-bold ${item.color}`}>{item.value}</span>
                    </div>
                  ))}
                </div>
              ) : <p className="text-xs text-muted-foreground text-center py-8">No matches yet</p>}
            </div>
          </div>

          {/* Row 5: Full Match History */}
          <div className="card-elevated p-5">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <Activity size={15} className="text-primary" />
                <h2 className="text-sm font-semibold text-foreground">Match History</h2>
                <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-success/20 text-success font-semibold">Live</span>
              </div>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-border">
                    {['Date', 'Q', 'Correct', 'Accuracy', 'Speed', 'LP Δ', 'Result', 'Topics'].map(h => (
                      <th key={`h-${h}`} className="text-left text-[11px] font-semibold text-muted-foreground pb-2 pr-3 last:pr-0">{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {sessions.slice(0, 20).map(s => (
                    <tr key={s.id} className="border-b border-border/40 hover:bg-muted/30 transition-colors">
                      <td className="py-2.5 pr-3 text-xs text-muted-foreground font-mono-data">{new Date(s.session_date).toLocaleDateString()}</td>
                      <td className="py-2.5 pr-3 font-mono-data text-xs">{s.questions_total}</td>
                      <td className="py-2.5 pr-3 font-mono-data text-xs text-success">{s.questions_correct}</td>
                      <td className="py-2.5 pr-3"><span className={`font-mono-data text-xs font-bold ${Number(s.accuracy) >= 80 ? 'text-success' : Number(s.accuracy) >= 60 ? 'text-warning' : 'text-danger'}`}>{Math.round(Number(s.accuracy))}%</span></td>
                      <td className="py-2.5 pr-3 font-mono-data text-xs text-info">{Math.round(Number(s.avg_speed_seconds))}s</td>
                      <td className="py-2.5 pr-3">
                        {s.lp_change === 0 ? (
                          <span className="text-xs text-muted-foreground flex items-center gap-0.5"><Minus size={10} />—</span>
                        ) : s.lp_change > 0 ? (
                          <span className="text-xs text-success font-mono-data font-bold flex items-center gap-0.5"><ChevronUp size={12} />+{s.lp_change}</span>
                        ) : (
                          <span className="text-xs text-danger font-mono-data font-bold flex items-center gap-0.5"><ChevronDown size={12} />{s.lp_change}</span>
                        )}
                      </td>
                      <td className="py-2.5 pr-3">
                        <Badge variant={s.lp_change > 0 ? 'success' : s.lp_change < 0 ? 'danger' : 'default'} size="sm">
                          {s.lp_change > 0 ? 'Win' : s.lp_change < 0 ? 'Loss' : 'Draw'}
                        </Badge>
                      </td>
                      <td className="py-2.5 text-xs text-muted-foreground max-w-[120px] truncate">{(s.topics_played || []).join(', ') || '—'}</td>
                    </tr>
                  ))}
                  {sessions.length === 0 && (
                    <tr><td colSpan={8} className="py-8 text-center text-xs text-muted-foreground">No ranked matches yet. Play your first ranked match!</td></tr>
                  )}
                </tbody>
              </table>
            </div>
            {totalRanked > 0 && (
              <div className="mt-4 pt-3 border-t border-border flex items-center gap-4 text-xs text-muted-foreground">
                <span className="text-success font-semibold">{stats.wins} wins</span>
                <span className="text-danger font-semibold">{stats.losses} losses</span>
                <span className="text-warning font-semibold">{stats.draws} draws</span>
                <span className="text-accent font-semibold ml-auto">{stats.winRate}% win rate</span>
                <Link href="/ranked-mode-screen" className="btn-primary flex items-center gap-1.5 px-3 py-1 text-xs">
                  <Play size={10} /> New Match
                </Link>
              </div>
            )}
          </div>

        </div>
      </div>
    </AppLayout>
  );
}