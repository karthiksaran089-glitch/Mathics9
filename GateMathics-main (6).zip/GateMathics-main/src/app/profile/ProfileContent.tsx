'use client';
import React, { useEffect, useState } from 'react';
import { Star, Zap, Flame, Target, BookOpen, Trophy, Edit2, Mail, LogOut, ChevronRight, X, Check, Shield, Camera, Award, Clock, BarChart3 } from 'lucide-react';
import { createClient } from '@/lib/supabase/client';
import Badge from '@/components/ui/Badge';
import BadgeGrid from '@/components/BadgeGrid';
import { useRouter } from 'next/navigation';
import { useAuth } from '@/contexts/AuthContext';
import { getLevelInfo, type UserProfileStats } from '@/lib/gamification';

interface UserProfile {
  display_name: string;
  email: string;
  rank: string;
  lp: number;
  daily_streak: number;
  longest_streak: number;
  overall_accuracy: number;
  total_questions_answered: number;
  total_correct: number;
  total_incorrect: number;
  total_timeout: number;
  total_sessions: number;
  total_ranked_sessions: number;
  total_practice_sessions: number;
  avg_answer_speed_seconds: number;
  auth_method: string;
  avatar_url?: string;
  created_at?: string;
  // New fields from raw data views
  account_status?: string;
  account_type?: string;
  account_age_days?: number;
  ranked_wins?: number;
  ranked_losses?: number;
  ranked_draws?: number;
  ranked_win_rate?: number;
  ranked_net_lp_change?: number;
  practice_hints_used?: number;
}

const DEFAULT_PROFILE: UserProfile = {
  display_name: 'User',
  email: '',
  rank: 'Silver',
  lp: 0,
  daily_streak: 0,
  longest_streak: 0,
  overall_accuracy: 0,
  total_questions_answered: 0,
  total_correct: 0,
  total_incorrect: 0,
  total_timeout: 0,
  total_sessions: 0,
  total_ranked_sessions: 0,
  total_practice_sessions: 0,
  avg_answer_speed_seconds: 0,
  auth_method: 'email_otp',
  avatar_url: '',
};

const RANK_ORDER = ['Bronze', 'Silver', 'Gold', 'Platinum', 'Diamond', 'Grandmaster'];
const LP_TO_NEXT: Record<string, number> = {
  Bronze: 500,
  Silver: 1000,
  Gold: 1500,
  Platinum: 2000,
  Diamond: 2500,
  Grandmaster: 0,
};

const RANK_TIERS = [
  { name: 'Bronze', min: 0, max: 499, color: '#CD7F32' },
  { name: 'Silver', min: 500, max: 999, color: '#A8B8C8' },
  { name: 'Gold', min: 1000, max: 1499, color: '#F59E0B' },
  { name: 'Platinum', min: 1500, max: 1999, color: '#06B6D4' },
  { name: 'Diamond', min: 2000, max: 2499, color: '#818CF8' },
  { name: 'Grandmaster', min: 2500, max: Infinity, color: '#EC4899' },
];

function getRankColor(rank: string) {
  switch (rank) {
    case 'Gold': return 'text-rank-gold';
    case 'Silver': return 'text-rank-silver';
    case 'Bronze': return 'text-rank-bronze';
    case 'Platinum': return 'text-info';
    case 'Diamond': return 'text-[#818CF8]';
    case 'Grandmaster': return 'text-danger';
    default: return 'text-rank-silver';
  }
}

function getRankBadgeVariant(rank: string): 'silver' | 'warning' | 'danger' | 'success' | 'info' {
  switch (rank) {
    case 'Gold': return 'warning';
    case 'Silver': return 'silver';
    case 'Bronze': return 'warning';
    case 'Platinum': return 'info';
    case 'Diamond': return 'info';
    case 'Grandmaster': return 'danger';
    default: return 'silver';
  }
}

function getRankForLP(lp: number) {
  return RANK_TIERS.find((r) => lp >= r.min && lp <= r.max) || RANK_TIERS[0];
}

function getStatusColor(status: string) {
  switch (status) {
    case 'active_today': return 'text-success';
    case 'active_yesterday': return 'text-warning';
    case 'active_this_week': return 'text-muted-foreground';
    default: return 'text-danger';
  }
}

function getStatusLabel(status: string) {
  switch (status) {
    case 'active_today': return 'Active Today';
    case 'active_yesterday': return 'Active Yesterday';
    case 'active_this_week': return 'Active This Week';
    case 'inactive': return 'Inactive';
    case 'never_active': return 'New User';
    default: return 'Unknown';
  }
}

// ── Edit Profile Modal ────────────────────────────────────────────────────────
interface EditProfileModalProps {
  profile: UserProfile;
  onClose: () => void;
  onSave: (displayName: string) => Promise<void>;
}

function EditProfileModal({ profile, onClose, onSave }: EditProfileModalProps) {
  const [displayName, setDisplayName] = useState(profile.display_name);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState(false);

  const handleSave = async () => {
    if (!displayName.trim()) { setError('Display name cannot be empty.'); return; }
    if (displayName.trim().length < 2) { setError('Display name must be at least 2 characters.'); return; }
    setSaving(true);
    setError('');
    try {
      await onSave(displayName.trim());
      setSuccess(true);
      setTimeout(onClose, 800);
    } catch (e: any) {
      setError(e?.message || 'Failed to save. Please try again.');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm px-4">
      <div className="bg-card border border-border rounded-2xl w-full max-w-md shadow-2xl">
        <div className="flex items-center justify-between px-6 py-4 border-b border-border">
          <div className="flex items-center gap-2">
            <Edit2 size={16} className="text-primary" />
            <h2 className="text-sm font-bold text-foreground">Edit Profile</h2>
          </div>
          <button onClick={onClose} className="w-7 h-7 rounded-lg hover:bg-muted flex items-center justify-center text-muted-foreground hover:text-foreground transition-colors">
            <X size={14} />
          </button>
        </div>
        <div className="px-6 py-5 flex flex-col gap-5">
          <div className="flex flex-col items-center gap-3">
            <div className="relative">
              <div className="w-20 h-20 rounded-full bg-gradient-to-br from-primary to-info flex items-center justify-center text-3xl font-bold text-white">
                {displayName.charAt(0).toUpperCase() || 'U'}
              </div>
              <div className="absolute -bottom-1 -right-1 w-7 h-7 rounded-full bg-muted border border-border flex items-center justify-center">
                <Camera size={12} className="text-muted-foreground" />
              </div>
            </div>
            <p className="text-xs text-muted-foreground">Avatar uses your display name initial</p>
          </div>
          <div className="flex flex-col gap-1.5">
            <label className="text-xs font-semibold text-foreground">Display Name</label>
            <input
              type="text"
              value={displayName}
              onChange={(e) => { setDisplayName(e.target.value); setError(''); }}
              placeholder="Enter your display name"
              maxLength={32}
              className="input-field text-sm"
            />
            <div className="flex items-center justify-between">
              {error ? <p className="text-xs text-danger">{error}</p> : <span />}
              <span className="text-[11px] text-muted-foreground">{displayName.length}/32</span>
            </div>
          </div>
          <div className="flex flex-col gap-1.5">
            <label className="text-xs font-semibold text-foreground">Email</label>
            <input
              type="email"
              value={profile.email}
              readOnly
              className="input-field text-sm opacity-60 cursor-not-allowed"
            />
            <p className="text-[11px] text-muted-foreground">Email cannot be changed</p>
          </div>
        </div>
        <div className="flex items-center gap-3 px-6 py-4 border-t border-border">
          <button onClick={onClose} className="flex-1 px-4 py-2.5 rounded-xl border border-border text-sm font-semibold text-muted-foreground hover:text-foreground hover:bg-muted transition-colors">
            Cancel
          </button>
          <button
            onClick={handleSave}
            disabled={saving || success}
            className="flex-1 px-4 py-2.5 rounded-xl bg-primary text-white text-sm font-semibold hover:bg-primary/90 transition-colors disabled:opacity-60 flex items-center justify-center gap-2"
          >
            {success ? <><Check size={14} /> Saved!</> : saving ? 'Saving…' : 'Save Changes'}
          </button>
        </div>
      </div>
    </div>
  );
}

// ── Account Details Modal ─────────────────────────────────────────────────────
interface AccountDetailsModalProps {
  profile: UserProfile;
  onClose: () => void;
}

function AccountDetailsModal({ profile, onClose }: AccountDetailsModalProps) {
  const joinedDate = profile.created_at
    ? new Date(profile.created_at).toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' })
    : 'N/A';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm px-4">
      <div className="bg-card border border-border rounded-2xl w-full max-w-md shadow-2xl">
        <div className="flex items-center justify-between px-6 py-4 border-b border-border">
          <div className="flex items-center gap-2">
            <Shield size={16} className="text-muted-foreground" />
            <h2 className="text-sm font-bold text-foreground">Account Details</h2>
          </div>
          <button onClick={onClose} className="w-7 h-7 rounded-lg hover:bg-muted flex items-center justify-center text-muted-foreground hover:text-foreground transition-colors">
            <X size={14} />
          </button>
        </div>
        <div className="px-6 py-5 flex flex-col gap-3">
          {[
            { label: 'Display Name', value: profile.display_name || 'Not set' },
            { label: 'Email Address', value: profile.email || 'Not set' },
            { label: 'Sign-in Method', value: profile.auth_method === 'google' ? 'Google OAuth' : profile.auth_method === 'guest' ? 'Guest Session' : 'Email OTP' },
            { label: 'Account Type', value: profile.account_type || 'Authenticated User' },
            { label: 'Account Status', value: getStatusLabel(profile.account_status || 'unknown') },
            { label: 'Member Since', value: joinedDate },
            { label: 'Account Age', value: profile.account_age_days ? `${profile.account_age_days} days` : 'N/A' },
            { label: 'Current Rank', value: profile.rank },
            { label: 'Total LP', value: `${profile.lp} LP` },
            { label: 'Total Sessions', value: `${profile.total_sessions}` },
            { label: 'Questions Answered', value: `${profile.total_questions_answered}` },
          ].map((item) => (
            <div key={item.label} className="flex items-center justify-between py-2.5 border-b border-border/50 last:border-0">
              <span className="text-xs text-muted-foreground">{item.label}</span>
              <span className="text-sm font-semibold text-foreground">{item.value}</span>
            </div>
          ))}
          <div className="mt-2 p-3 rounded-xl bg-info/10 border border-info/20">
            <p className="text-xs text-info font-medium">
              🔐 Signed in via {profile.auth_method === 'google' ? 'Google OAuth' : profile.auth_method === 'guest' ? 'Guest Session' : 'Email OTP'}. Your account is secure.
            </p>
          </div>
        </div>
        <div className="px-6 py-4 border-t border-border">
          <button onClick={onClose} className="w-full px-4 py-2.5 rounded-xl bg-muted text-sm font-semibold text-foreground hover:bg-muted/80 transition-colors">
            Close
          </button>
        </div>
      </div>
    </div>
  );
}

// ── Main Profile Page ─────────────────────────────────────────────────────────
export default function ProfilePage() {
  const router = useRouter();
  const { signOut, signOutGuest, isGuest, guestSession } = useAuth();
  const [profile, setProfile] = useState<UserProfile>(DEFAULT_PROFILE);
  const [mounted, setMounted] = useState(false);
  const [loading, setLoading] = useState(true);
  const [activeModal, setActiveModal] = useState<'edit' | 'account' | null>(null);

  const loadProfile = async () => {
    if (isGuest && guestSession) {
      setProfile({
        ...DEFAULT_PROFILE,
        display_name: guestSession.name,
        auth_method: 'guest',
        account_type: 'Guest',
        account_status: 'active_today',
      });
      setLoading(false);
      return;
    }

    const supabase = createClient();
    if (!supabase) { setLoading(false); return; }
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) { setLoading(false); return; }

    // Use the new profile_details view for identity + progression
    const { data: profileData } = await supabase
      .from('profile_details')
      .select('*')
      .eq('user_id', user.id)
      .single();

    // Use the new user_session_breakdown view for session activity
    const { data: sessionData } = await supabase
      .from('user_session_breakdown')
      .select('*')
      .eq('user_id', user.id)
      .maybeSingle();

    if (profileData) {
      setProfile({
        display_name: profileData.display_name || user.email?.split('@')[0] || 'User',
        email: profileData.email || user.email || '',
        rank: profileData.rank || 'Silver',
        lp: profileData.lp || 0,
        daily_streak: profileData.daily_streak || 0,
        longest_streak: profileData.longest_streak || 0,
        overall_accuracy: profileData.overall_accuracy || 0,
        total_questions_answered: profileData.total_questions_answered || 0,
        total_correct: profileData.total_correct || 0,
        total_incorrect: profileData.total_incorrect || 0,
        total_timeout: profileData.total_timeout || 0,
        total_sessions: profileData.total_sessions || 0,
        total_ranked_sessions: profileData.total_ranked_sessions || 0,
        total_practice_sessions: profileData.total_practice_sessions || 0,
        avg_answer_speed_seconds: profileData.avg_answer_speed_seconds || 0,
        auth_method: profileData.auth_method || 'email_otp',
        avatar_url: profileData.avatar_url || '',
        created_at: profileData.account_created_at || '',
        // From session breakdown
        account_status: profileData.is_active_today ? 'active_today' : 'active_this_week',
        account_type: profileData.auth_method === 'google' ? 'Google OAuth' : profileData.auth_method === 'guest' ? 'Guest' : 'Email OTP',
        account_age_days: profileData.account_age_days || 0,
        ranked_wins: sessionData?.ranked_wins || 0,
        ranked_losses: sessionData?.ranked_losses || 0,
        ranked_draws: sessionData?.ranked_draws || 0,
        ranked_win_rate: sessionData?.ranked_win_rate || 0,
        ranked_net_lp_change: sessionData?.ranked_net_lp_change || 0,
        practice_hints_used: sessionData?.practice_hints_used || 0,
      });
    }
    setLoading(false);
  };

  useEffect(() => {
    let unsub: (() => void) | undefined;

    const init = async () => {
      setMounted(true);
      await loadProfile();

      const supabase = createClient();
      if (!supabase) return;
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const channel = supabase.channel('profile-realtime-sync')
        .on('postgres_changes',
          { event: 'UPDATE', schema: 'public', table: 'user_profiles', filter: `id=eq.${user.id}` },
          () => { loadProfile(); }
        )
        .on('postgres_changes',
          { event: 'INSERT', schema: 'public', table: 'practice_sessions', filter: `user_id=eq.${user.id}` },
          () => { loadProfile(); }
        )
        .on('postgres_changes',
          { event: 'INSERT', schema: 'public', table: 'ranked_sessions', filter: `user_id=eq.${user.id}` },
          () => { loadProfile(); }
        )
        .subscribe();

      unsub = () => { supabase.removeChannel(channel); };
    };

    init();
    return () => { if (unsub) unsub(); };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isGuest, guestSession]);

  const handleSaveDisplayName = async (newName: string) => {
    const supabase = createClient();
    if (!supabase) throw new Error('Supabase not available');
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) throw new Error('Not authenticated');

    const { data: result, error } = await supabase.rpc('update_profile_display_name', {
      p_user_id: user.id,
      p_display_name: newName,
    });

    if (error) throw new Error(error.message);
    if (!result?.success) throw new Error(result?.error || 'Failed to update name');

    setProfile((prev) => ({ ...prev, display_name: result.display_name }));
  };

  const handleSignOut = async () => {
    try {
      if (isGuest) {
        signOutGuest();
      } else {
        await signOut();
      }
    } catch {
      localStorage.removeItem('gm_guest_session');
    }
    router.push('/sign-up-login-screen');
  };

  const rank = getRankForLP(profile.lp);
  const rankIdx = RANK_ORDER.indexOf(profile.rank);
  const nextRank = rankIdx >= 0 && rankIdx < RANK_ORDER.length - 1 ? RANK_ORDER[rankIdx + 1] : null;
  const lpToNext = LP_TO_NEXT[profile.rank] || 1000;
  const lpProgress = Math.min((profile.lp / lpToNext) * 100, 100);
  const rankColor = getRankColor(profile.rank);
  const rankBadgeVariant = getRankBadgeVariant(profile.rank);

  // Compute practice vs ranked split
  const totalSessions = profile.total_sessions || 0;
  const rankedPct = totalSessions > 0 ? Math.round((profile.total_ranked_sessions / totalSessions) * 100) : 0;
  const practicePct = totalSessions > 0 ? Math.round((profile.total_practice_sessions / totalSessions) * 100) : 0;

  const stats = [
    { id: 'st-rank', label: 'Current Rank', value: mounted ? profile.rank : '—', color: rankColor, icon: Trophy },
    { id: 'st-lp', label: 'League Points', value: mounted ? `${profile.lp} LP` : '—', color: 'text-accent', icon: Zap },
    { id: 'st-streak', label: 'Daily Streak', value: mounted ? `${profile.daily_streak} days` : '—', color: 'text-warning', icon: Flame },
    { id: 'st-accuracy', label: 'Overall Accuracy', value: mounted ? `${Number(profile.overall_accuracy).toFixed(1)}%` : '—', color: 'text-success', icon: Target },
    { id: 'st-questions', label: 'Questions Answered', value: mounted ? `${profile.total_questions_answered}` : '—', color: 'text-foreground', icon: BookOpen },
    { id: 'st-correct', label: 'Correct Answers', value: mounted ? `${profile.total_correct}` : '—', color: 'text-success', icon: Target },
    { id: 'st-sessions', label: 'Total Sessions', value: mounted ? `${profile.total_sessions}` : '—', color: 'text-info', icon: Star },
    { id: 'st-speed', label: 'Avg Speed', value: mounted ? `${Math.round(Number(profile.avg_answer_speed_seconds))}s` : '—', color: 'text-warning', icon: Clock },
  ];

  const accountOptions = [
    {
      id: 'opt-edit',
      icon: Edit2,
      label: 'Edit Profile',
      description: 'Update your display name and avatar',
      color: 'text-primary',
      modal: 'edit' as const,
    },
    {
      id: 'opt-account',
      icon: Mail,
      label: 'Account Details',
      description: `Signed in via ${profile.auth_method === 'google' ? 'Google' : profile.auth_method === 'guest' ? 'Guest' : 'Email OTP'}`,
      color: 'text-muted-foreground',
      modal: 'account' as const,
    },
  ];

  return (
    <div className="w-full px-4 py-4 lg:p-6 lg:max-w-screen-2xl lg:mx-auto">
      {/* Modals */}
      {activeModal === 'edit' && (
        <EditProfileModal
          profile={profile}
          onClose={() => setActiveModal(null)}
          onSave={handleSaveDisplayName}
        />
      )}
      {activeModal === 'account' && (
        <AccountDetailsModal profile={profile} onClose={() => setActiveModal(null)} />
      )}

      {/* Profile Hero */}
      <div className="card-elevated p-6 mb-6 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-full opacity-5 pointer-events-none">
          <div className="absolute top-4 right-8 w-32 h-32 rounded-full bg-primary blur-3xl" />
        </div>
        <div className="relative flex items-start gap-5">
          {/* Avatar */}
          <div className="relative flex-shrink-0">
            <div className="w-16 h-16 rounded-full bg-gradient-to-br from-primary to-info flex items-center justify-center text-2xl font-bold text-white">
              {mounted ? profile.display_name.charAt(0).toUpperCase() : 'U'}
            </div>
            <div className="absolute -bottom-1 -right-1 w-6 h-6 rounded-full rank-badge-silver flex items-center justify-center">
              <Star size={10} />
            </div>
          </div>

          {/* Info */}
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 flex-wrap mb-1">
              <h1 className="text-xl font-bold text-foreground">
                {mounted ? profile.display_name : '—'}
              </h1>
              <Badge variant={rankBadgeVariant} size="sm">
                {mounted ? profile.rank : 'Silver'}
              </Badge>
              {profile.account_status && (
                <span className={`text-[10px] font-semibold ${getStatusColor(profile.account_status)}`}>
                  {getStatusLabel(profile.account_status)}
                </span>
              )}
            </div>
            <p className="text-sm text-muted-foreground mb-1">
              {mounted ? profile.email : '—'}
            </p>
            <p className="text-[11px] text-muted-foreground mb-3">
              {profile.account_type || 'Email OTP'} · Member for {profile.account_age_days || 0} days
            </p>

            {/* Rank Progress */}
            {nextRank && (
              <div>
                <div className="flex items-center justify-between mb-1">
                  <span className="text-xs text-muted-foreground">
                    Progress to <span className={`font-semibold ${getRankColor(nextRank)}`}>{nextRank}</span>
                  </span>
                  <span className="text-xs font-mono-data text-accent">
                    {mounted ? profile.lp : 0} / {lpToNext} LP
                  </span>
                </div>
                <div className="w-full h-2 progress-bar-bg">
                  <div
                    className="progress-bar-fill transition-all duration-700"
                    style={{ width: `${mounted ? lpProgress : 0}%`, height: '8px' }}
                  />
                </div>
                <p className="text-[11px] text-muted-foreground mt-1">
                  {mounted ? Math.max(0, lpToNext - profile.lp) : lpToNext} LP to {nextRank}
                </p>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Level & XP Section */}
      {mounted && (() => {
        const gamStats: UserProfileStats = {
          total_questions_answered: profile.total_questions_answered,
          total_correct: profile.total_correct,
          total_incorrect: profile.total_incorrect || 0,
          total_timeout: profile.total_timeout || 0,
          total_sessions: profile.total_sessions,
          total_ranked_sessions: profile.total_ranked_sessions,
          total_practice_sessions: profile.total_practice_sessions,
          overall_accuracy: Number(profile.overall_accuracy),
          avg_answer_speed_seconds: Number(profile.avg_answer_speed_seconds),
          daily_streak: profile.daily_streak,
          longest_streak: profile.longest_streak,
          lp: profile.lp,
          rank: profile.rank,
        };
        const info = getLevelInfo(gamStats);
        return (
          <div className="card-elevated p-5 mb-6">
            <div className="flex items-center gap-4 mb-4">
              <div
                className="w-14 h-14 rounded-2xl flex items-center justify-center text-2xl font-extrabold text-white font-mono-data flex-shrink-0"
                style={{ background: info.tier.gradient, boxShadow: `0 0 24px ${info.tier.color}44` }}
              >
                {info.level}
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-1">
                  <p className="text-sm font-bold text-foreground">{info.tier.emoji} {info.tier.name}</p>
                  <span className="text-xs text-muted-foreground">Level {info.level}</span>
                </div>
                <div className="flex items-center gap-2 mb-1">
                  <div className="flex-1 h-2 rounded-full overflow-hidden" style={{ background: 'var(--muted)' }}>
                    <div
                      className="h-full rounded-full transition-all duration-700"
                      style={{ width: `${info.progressPct}%`, background: info.tier.gradient }}
                    />
                  </div>
                  <span className="text-[11px] font-mono-data text-muted-foreground flex-shrink-0">{info.progressPct}%</span>
                </div>
                <p className="text-[11px] text-muted-foreground">
                  {info.xpInLevel} / {info.xpToNext} XP to next level · {info.totalXP} total XP
                </p>
              </div>
            </div>
          </div>
        );
      })()}

      {/* Practice vs Ranked Activity Breakdown */}
      {mounted && totalSessions > 0 && (
        <div className="card-elevated p-5 mb-6">
          <div className="flex items-center gap-2 mb-4">
            <BarChart3 size={15} className="text-primary" />
            <h2 className="text-sm font-semibold text-foreground">Activity Breakdown</h2>
          </div>
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
            {/* Practice Column */}
            <div className="p-4 rounded-xl bg-info/5 border border-info/20">
              <div className="flex items-center gap-2 mb-3">
                <BookOpen size={14} className="text-info" />
                <h3 className="text-xs font-bold text-info uppercase tracking-wider">Practice</h3>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <p className="font-mono-data text-xl font-extrabold text-foreground">{profile.total_practice_sessions}</p>
                  <p className="text-[10px] text-muted-foreground">Sessions</p>
                </div>
                <div>
                  <p className="font-mono-data text-xl font-extrabold text-foreground">{practicePct}%</p>
                  <p className="text-[10px] text-muted-foreground">of Total</p>
                </div>
              </div>
              <div className="mt-3 pt-3 border-t border-info/10 flex items-center gap-2 text-[10px] text-muted-foreground">
                <span>{profile.practice_hints_used || 0} hints used</span>
              </div>
            </div>

            {/* Session Split Bar */}
            <div className="p-4 rounded-xl bg-muted/30 flex flex-col items-center justify-center">
              <p className="text-[10px] font-bold text-muted-foreground uppercase tracking-wider mb-3">Session Split</p>
              <div className="w-full h-4 bg-muted rounded-full overflow-hidden flex">
                <div className="h-full bg-info transition-all duration-700" style={{ width: `${practicePct}%` }} />
                <div className="h-full bg-primary transition-all duration-700" style={{ width: `${rankedPct}%` }} />
              </div>
              <div className="flex items-center justify-between w-full mt-2">
                <div className="flex items-center gap-1.5">
                  <div className="w-2.5 h-2.5 rounded-sm bg-info" />
                  <span className="text-[10px] text-muted-foreground">Practice {practicePct}%</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <div className="w-2.5 h-2.5 rounded-sm bg-primary" />
                  <span className="text-[10px] text-muted-foreground">Ranked {rankedPct}%</span>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4 mt-4 w-full">
                <div className="text-center">
                  <p className="font-mono-data text-xs font-bold text-foreground">{profile.total_correct}/{profile.total_questions_answered}</p>
                  <p className="text-[10px] text-muted-foreground">Overall Correct</p>
                </div>
                <div className="text-center">
                  <p className="font-mono-data text-xs font-bold text-foreground">{profile.total_timeout}</p>
                  <p className="text-[10px] text-muted-foreground">Timeouts</p>
                </div>
              </div>
            </div>

            {/* Ranked Column */}
            <div className="p-4 rounded-xl bg-primary/5 border border-primary/20">
              <div className="flex items-center gap-2 mb-3">
                <Trophy size={14} className="text-primary" />
                <h3 className="text-xs font-bold text-primary uppercase tracking-wider">Ranked</h3>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <p className="font-mono-data text-xl font-extrabold text-foreground">{profile.total_ranked_sessions}</p>
                  <p className="text-[10px] text-muted-foreground">Sessions</p>
                </div>
                <div>
                  <p className="font-mono-data text-xl font-extrabold text-foreground">{rankedPct}%</p>
                  <p className="text-[10px] text-muted-foreground">of Total</p>
                </div>
              </div>
              <div className="mt-3 pt-3 border-t border-primary/10 flex items-center justify-between text-[10px] text-muted-foreground">
                <span>W: <span className="font-bold text-success">{profile.ranked_wins || 0}</span></span>
                <span>L: <span className="font-bold text-danger">{profile.ranked_losses || 0}</span></span>
                <span>Win: <span className="font-bold text-primary">{profile.ranked_win_rate || 0}%</span></span>
              </div>
              <div className="mt-2 flex items-center gap-1 text-[10px]">
                <span className="text-muted-foreground">Net LP:</span>
                <span className={`font-bold ${(profile.ranked_net_lp_change || 0) >= 0 ? 'text-success' : 'text-danger'}`}>
                  {(profile.ranked_net_lp_change || 0) >= 0 ? '+' : ''}{profile.ranked_net_lp_change || 0}
                </span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Stats Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-6">
        {stats.map((stat) => {
          const StatIcon = stat.icon;
          return (
            <div key={stat.id} className="card-elevated p-4">
              <div className="flex items-center justify-between mb-2">
                <p className="text-xs text-muted-foreground">{stat.label}</p>
                <StatIcon size={14} className={stat.color} />
              </div>
              <p className={`text-xl font-bold font-mono-data ${stat.color}`}>{stat.value}</p>
            </div>
          );
        })}
      </div>

      {/* Account Options */}
      <div className="card-elevated p-5 mb-6">
        <h2 className="text-sm font-semibold text-foreground mb-4">Account & Settings</h2>
        <div className="flex flex-col gap-1">
          {accountOptions.map((opt) => {
            const OptIcon = opt.icon;
            return (
              <button
                key={opt.id}
                onClick={() => setActiveModal(opt.modal)}
                className="flex items-center gap-4 p-3 rounded-xl hover:bg-muted/60 transition-colors text-left w-full group"
              >
                <div className={`w-9 h-9 rounded-lg bg-muted flex items-center justify-center ${opt.color}`}>
                  <OptIcon size={16} />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-semibold text-foreground">{opt.label}</p>
                  <p className="text-xs text-muted-foreground">{opt.description}</p>
                </div>
                <ChevronRight size={16} className="text-muted-foreground group-hover:text-foreground transition-colors" />
              </button>
            );
          })}
        </div>
      </div>

      {/* Badges & Achievements */}
      {mounted && (() => {
        const gamStats: UserProfileStats = {
          total_questions_answered: profile.total_questions_answered,
          total_correct: profile.total_correct,
          total_incorrect: profile.total_incorrect || 0,
          total_timeout: profile.total_timeout || 0,
          total_sessions: profile.total_sessions,
          total_ranked_sessions: profile.total_ranked_sessions,
          total_practice_sessions: profile.total_practice_sessions,
          overall_accuracy: Number(profile.overall_accuracy),
          avg_answer_speed_seconds: Number(profile.avg_answer_speed_seconds),
          daily_streak: profile.daily_streak,
          longest_streak: profile.longest_streak,
          lp: profile.lp,
          rank: profile.rank,
        };
        return (
          <div className="card-elevated p-5 mb-6">
            <div className="flex items-center gap-2 mb-4">
              <Award size={15} className="text-accent" />
              <h2 className="text-sm font-semibold text-foreground">Achievements</h2>
              <span className="text-[10px] text-muted-foreground ml-auto">
                {gamStats.total_sessions >= 1 ? 'Keep unlocking!' : 'Play to earn badges'}
              </span>
            </div>
            <BadgeGrid stats={gamStats} />
          </div>
        );
      })()}

      {/* Sign Out */}
      <button
        onClick={handleSignOut}
        className="flex items-center gap-3 px-4 py-3 rounded-xl border border-danger/30 bg-danger/5 text-danger hover:bg-danger/10 transition-colors w-full"
      >
        <LogOut size={16} />
        <span className="text-sm font-semibold">Sign Out</span>
      </button>
    </div>
  );
}