'use client';

import React, { Suspense } from 'react';
import dynamic from 'next/dynamic';
import AppLayout from '@/components/AppLayout';
import { Skeleton as LoadingSkeleton } from '@/components/ui/LoadingSkeleton';

const ProfileContent = dynamic(
  () => import('./ProfileContent'),
  {
    loading: () => (
      <div className="p-6 space-y-4">
        <LoadingSkeleton className="h-24 w-full" />
        <LoadingSkeleton className="h-16 w-full" />
        <LoadingSkeleton className="h-48 w-full" />
      </div>
    ),
    ssr: false,
  }
);

export default function ProfilePage() {
  return (
    <AppLayout>
      <Suspense fallback={
        <div className="p-6 space-y-4">
          <LoadingSkeleton className="h-24 w-full" />
          <LoadingSkeleton className="h-16 w-full" />
        </div>
      }>
        <ProfileContent />
      </Suspense>
    </AppLayout>
  );
}
