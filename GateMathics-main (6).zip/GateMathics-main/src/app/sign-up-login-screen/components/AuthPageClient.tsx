'use client';
import React, { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { useAuth } from '@/contexts/AuthContext';
import AuthHeroPanel from './AuthHeroPanel';
import AuthForm from './AuthForm';
import GuestModal from './GuestModal';

export default function AuthPageClient() {
  const [showGuestModal, setShowGuestModal] = useState(false);
  const { user, guestSession, loading } = useAuth();
  const router = useRouter();

  useEffect(() => {
    if (!loading && (user || guestSession)) {
      router?.replace('/');
    }
  }, [user, guestSession, loading, router]);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  if (user || guestSession) {
    return null;
  }

  return (
    <div className="min-h-screen flex bg-background">
      {/* Left hero panel — hidden on mobile */}
      <div className="hidden lg:flex lg:w-1/2 xl:w-[55%]">
        <AuthHeroPanel />
      </div>

      {/* Right auth form */}
      <div className="flex-1 flex items-center justify-center p-6 lg:p-12">
        <AuthForm onGuestClick={() => setShowGuestModal(true)} />
      </div>

      <GuestModal open={showGuestModal} onClose={() => setShowGuestModal(false)} />
    </div>
  );
}