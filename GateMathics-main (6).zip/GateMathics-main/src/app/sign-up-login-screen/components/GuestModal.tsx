'use client';
import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import { useRouter } from 'next/navigation';
import { toast } from 'sonner';
import { Loader2, UserCircle, AlertTriangle } from 'lucide-react';
import Modal from '@/components/ui/Modal';
import { useAuth } from '@/contexts/AuthContext';

interface GuestForm {
  guestName: string;
}

interface GuestModalProps {
  open: boolean;
  onClose: () => void;
}

export default function GuestModal({ open, onClose }: GuestModalProps) {
  const router = useRouter();
  const { signInAsGuest } = useAuth();
  const [isLoading, setIsLoading] = useState(false);
  const { register, handleSubmit, formState: { errors }, reset } = useForm<GuestForm>();

  const handleGuestSubmit = async (data: GuestForm) => {
    setIsLoading(true);
    try {
      await signInAsGuest(data.guestName);
      toast.success(`Welcome, ${data.guestName}! Guest session started.`);
      reset();
      onClose();
      router.push('/');
      router.refresh();
    } catch (err: any) {
      toast.error(err?.message || 'Failed to start guest session. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Modal open={open} onClose={onClose} title="Continue as Guest">
      <div className="flex flex-col gap-4">
        {/* Warning */}
        <div className="flex items-start gap-3 p-3 rounded-lg bg-warning/10 border border-warning/20">
          <AlertTriangle size={15} className="text-warning flex-shrink-0 mt-0.5" />
          <div>
            <p className="text-xs font-semibold text-warning">Temporary session</p>
            <p className="text-xs text-muted-foreground mt-0.5">
              Guest progress is stored for 24 hours only. LP, rank, and analytics will not be saved permanently. Sign in with Google or Email to keep your progress.
            </p>
          </div>
        </div>

        <form onSubmit={handleSubmit(handleGuestSubmit)} className="flex flex-col gap-4">
          <div>
            <label className="block text-sm font-medium text-foreground mb-1.5" htmlFor="guestName">
              Your name
            </label>
            <p className="text-xs text-muted-foreground mb-2">
              This is how you&apos;ll appear on the leaderboard during your session.
            </p>
            <div className="relative">
              <UserCircle size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
              <input
                id="guestName"
                type="text"
                className="input-field pl-9"
                placeholder="e.g. Rohan Verma"
                {...register('guestName', {
                  required: 'Please enter your name',
                  minLength: { value: 2, message: 'Name must be at least 2 characters' },
                  maxLength: { value: 30, message: 'Name must be 30 characters or less' },
                })}
              />
            </div>
            {errors.guestName && (
              <p className="text-danger text-xs mt-1.5">{errors.guestName.message}</p>
            )}
          </div>

          <div className="flex gap-3">
            <button
              type="button"
              onClick={onClose}
              className="btn-secondary flex-1 py-2.5 text-sm"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isLoading}
              className="btn-primary flex-1 py-2.5 text-sm flex items-center justify-center gap-2"
            >
              {isLoading && <Loader2 size={14} className="animate-spin-slow" />}
              {isLoading ? 'Starting...' : '🎮 Enter as Guest'}
            </button>
          </div>
        </form>

        <p className="text-center text-xs text-muted-foreground">
          Want to save progress?{' '}
          <button onClick={onClose} className="text-primary hover:underline">
            Sign in with Google or Email
          </button>
        </p>
      </div>
    </Modal>
  );
}