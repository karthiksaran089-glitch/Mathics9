'use client';
import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import { useRouter } from 'next/navigation';
import { toast } from 'sonner';
import AppLogo from '@/components/ui/AppLogo';
import { Mail, Loader2 } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';

type AuthMode = 'choose' | 'email-otp' | 'otp-verify';

interface EmailForm {
  email: string;
}

interface OTPForm {
  otp: string;
}

interface AuthFormProps {
  onGuestClick: () => void;
}

export default function AuthForm({ onGuestClick }: AuthFormProps) {
  const router = useRouter();
  const { signInWithGoogle, sendEmailOTP, verifyEmailOTP } = useAuth();
  const [mode, setMode] = useState<AuthMode>('choose');
  const [isLoading, setIsLoading] = useState(false);

  const emailForm = useForm<EmailForm>();
  const otpForm = useForm<OTPForm>();

  const handleGoogleAuth = async () => {
    setIsLoading(true);
    try {
      await signInWithGoogle();
      // Redirect handled by OAuth callback
    } catch (err: any) {
      toast.error(err?.message || 'Google sign-in failed. Please try again.');
      setIsLoading(false);
    }
  };

  const handleEmailSubmit = async (data: EmailForm) => {
    setIsLoading(true);
    try {
      await sendEmailOTP(data.email);
      toast.success(`OTP sent to ${data.email}`);
      setMode('otp-verify');
    } catch (err: any) {
      toast.error(err?.message || 'Failed to send OTP. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleOTPVerify = async (data: OTPForm) => {
    setIsLoading(true);
    try {
      await verifyEmailOTP(emailForm.getValues('email'), data.otp);
      toast.success('Welcome to GateMathics!');
      router.push('/');
      router.refresh();
    } catch (err: any) {
      toast.error(err?.message || 'Invalid OTP. Please check your email and try again.');
      otpForm.setError('otp', { message: 'Invalid or expired OTP' });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="w-full max-w-sm">
      {/* Mobile logo */}
      <div className="flex items-center gap-2.5 mb-8 lg:hidden">
        <AppLogo size={32} />
        <span className="font-extrabold text-xl tracking-tight text-gradient-primary">GateMathics</span>
      </div>

      <div className="mb-8">
        <h1 className="text-2xl font-extrabold text-foreground">
          {mode === 'choose' && 'Sign in to train'}
          {mode === 'email-otp' && 'Enter your email'}
          {mode === 'otp-verify' && 'Check your inbox'}
        </h1>
        <p className="text-sm text-muted-foreground mt-1.5">
          {mode === 'choose' && 'Choose how you want to access GateMathics'}
          {mode === 'email-otp' && "We'll send a one-time passcode — no password needed"}
          {mode === 'otp-verify' && 'Enter the 6-digit code we sent to your email'}
        </p>
      </div>

      {/* AUTH METHOD: CHOOSE */}
      {mode === 'choose' && (
        <div className="flex flex-col gap-3">
          {/* Google OAuth */}
          <button
            onClick={handleGoogleAuth}
            disabled={isLoading}
            className="btn-secondary flex items-center justify-center gap-3 w-full py-3 text-sm font-semibold relative"
          >
            {isLoading ? (
              <Loader2 size={16} className="animate-spin-slow" />
            ) : (
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" aria-hidden="true">
                <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4" />
                <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853" />
                <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05" />
                <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335" />
              </svg>
            )}
            Continue with Google
          </button>

          {/* Email OTP */}
          <button
            onClick={() => setMode('email-otp')}
            className="btn-secondary flex items-center justify-center gap-3 w-full py-3 text-sm font-semibold"
          >
            <Mail size={16} />
            Continue with Email OTP
          </button>

          {/* Divider */}
          <div className="flex items-center gap-3 my-1">
            <div className="flex-1 h-px bg-border" />
            <span className="text-xs text-muted-foreground">or</span>
            <div className="flex-1 h-px bg-border" />
          </div>

          {/* Guest Access */}
          <button
            onClick={onGuestClick}
            className="w-full py-3 text-sm font-semibold rounded-lg border border-dashed border-border text-muted-foreground hover:text-foreground hover:border-primary/50 transition-all duration-150"
          >
            🎮 Continue as Guest
          </button>

          <p className="text-[11px] text-muted-foreground text-center mt-1">
            Guest sessions are temporary and cannot save LP or rank progress.
          </p>
        </div>
      )}

      {/* AUTH METHOD: EMAIL OTP */}
      {mode === 'email-otp' && (
        <form onSubmit={emailForm.handleSubmit(handleEmailSubmit)} className="flex flex-col gap-4">
          <div>
            <label className="block text-sm font-medium text-foreground mb-1.5" htmlFor="email">
              Email address
            </label>
            <input
              id="email"
              type="email"
              className="input-field"
              placeholder="arjun@example.com"
              {...emailForm.register('email', {
                required: 'Email is required',
                pattern: { value: /^[^\s@]+@[^\s@]+\.[^\s@]+$/, message: 'Enter a valid email address' },
              })}
            />
            {emailForm.formState.errors.email && (
              <p className="text-danger text-xs mt-1.5">{emailForm.formState.errors.email.message}</p>
            )}
          </div>

          <button
            type="submit"
            disabled={isLoading}
            className="btn-primary flex items-center justify-center gap-2 w-full py-3 text-sm"
          >
            {isLoading ? <Loader2 size={16} className="animate-spin-slow" /> : null}
            {isLoading ? 'Sending OTP...' : 'Send OTP'}
          </button>

          <button
            type="button"
            onClick={() => setMode('choose')}
            className="text-sm text-muted-foreground hover:text-foreground text-center transition-colors"
          >
            ← Back to sign-in options
          </button>
        </form>
      )}

      {/* AUTH METHOD: OTP VERIFY */}
      {mode === 'otp-verify' && (
        <form onSubmit={otpForm.handleSubmit(handleOTPVerify)} className="flex flex-col gap-4">
          <div className="p-3 rounded-lg bg-info/10 border border-info/20 text-xs text-info">
            OTP sent to <strong>{emailForm.getValues('email')}</strong>. Check your inbox — valid for 10 minutes.
          </div>

          <div>
            <label className="block text-sm font-medium text-foreground mb-1.5" htmlFor="otp">
              6-digit OTP code
            </label>
            <input
              id="otp"
              type="text"
              inputMode="numeric"
              maxLength={6}
              className="input-field font-mono-data text-center text-xl tracking-[0.5em] py-3"
              placeholder="• • • • • •"
              {...otpForm.register('otp', {
                required: 'OTP is required',
                pattern: { value: /^\d{6}$/, message: 'Enter the 6-digit code' },
              })}
            />
            {otpForm.formState.errors.otp && (
              <p className="text-danger text-xs mt-1.5">{otpForm.formState.errors.otp.message}</p>
            )}
          </div>

          <button
            type="submit"
            disabled={isLoading}
            className="btn-primary flex items-center justify-center gap-2 w-full py-3 text-sm"
          >
            {isLoading ? <Loader2 size={16} className="animate-spin-slow" /> : null}
            {isLoading ? 'Verifying...' : 'Verify & Sign In'}
          </button>

          <div className="flex items-center justify-between">
            <button
              type="button"
              onClick={() => { setMode('email-otp'); otpForm.reset(); }}
              className="text-sm text-muted-foreground hover:text-foreground transition-colors"
            >
              ← Change email
            </button>
            <button
              type="button"
              disabled={isLoading}
              onClick={() => emailForm.handleSubmit(handleEmailSubmit)()}
              className="text-sm text-primary hover:underline transition-colors"
            >
              Resend OTP
            </button>
          </div>
        </form>
      )}
    </div>
  );
}