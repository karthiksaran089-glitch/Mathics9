import React from 'react';
import AppLogo from '@/components/ui/AppLogo';
import { Flame, Trophy, Star, Zap, Shield, TrendingUp } from 'lucide-react';
import Icon from '@/components/ui/AppIcon';


const rankTiers = [
  { key: 'tier-bronze', label: 'Bronze', range: '0–199 LP', cls: 'rank-badge-bronze', icon: Shield },
  { key: 'tier-silver', label: 'Silver', range: '200–399 LP', cls: 'rank-badge-silver', icon: Star },
  { key: 'tier-gold', label: 'Gold', range: '400–599 LP', cls: 'rank-badge-gold', icon: Trophy },
  { key: 'tier-platinum', label: 'Platinum', range: '600–799 LP', cls: 'rank-badge-platinum', icon: Zap },
  { key: 'tier-diamond', label: 'Diamond', range: '800–999 LP', cls: 'rank-badge-diamond', icon: TrendingUp },
  { key: 'tier-gm', label: 'Grandmaster', range: '1000+ LP', cls: 'rank-badge-grandmaster', icon: Flame },
];

const stats = [
  { key: 'stat-users', value: '12,400+', label: 'GATE aspirants' },
  { key: 'stat-q', value: '8,500+', label: 'curated questions' },
  { key: 'stat-topics', value: '12', label: 'GATE CS topics' },
];

export default function AuthHeroPanel() {
  return (
    <div className="flex-1 relative overflow-hidden bg-gradient-to-br from-[#0F0F1A] via-[#16162A] to-[#0A0A16] flex flex-col justify-between p-10 border-r border-border">
      {/* Background orbs */}
      <div className="absolute top-20 left-10 w-72 h-72 rounded-full bg-primary opacity-5 blur-3xl pointer-events-none" />
      <div className="absolute bottom-32 right-8 w-56 h-56 rounded-full bg-accent opacity-5 blur-3xl pointer-events-none" />
      <div className="absolute top-1/2 left-1/3 w-40 h-40 rounded-full bg-info opacity-4 blur-2xl pointer-events-none" />
      {/* Top: Logo + tagline */}
      <div>
        <div className="flex items-center gap-3 mb-6">
          <AppLogo size={40} />
          <span className="font-extrabold text-2xl tracking-tight text-gradient-primary">
            GateMathics
          </span>
        </div>
        <h2 className="text-3xl xl:text-4xl font-extrabold text-foreground leading-tight max-w-sm">
          Train Smarter.<br />
          <span className="text-gradient-primary">Rank Higher.</span><br />
          Crack GATE CS.
        </h2>
        <p className="text-sm text-muted-foreground mt-3 max-w-xs leading-relaxed">
          Gamified ranked matches, AI-powered practice, and real-time analytics — built specifically for the GATE Computer Science syllabus.
        </p>
      </div>
      {/* Middle: Rank tier showcase */}
      <div>
        <p className="text-[11px] font-bold uppercase tracking-widest text-muted-foreground mb-3">
          Rank Progression System
        </p>
        <div className="grid grid-cols-3 gap-2">
          {rankTiers?.map((tier) => {
            const Icon = tier?.icon;
            return (
              <div
                key={tier?.key}
                className="flex flex-col items-center gap-1.5 p-3 rounded-xl bg-card/50 border border-border/50 hover:border-border transition-colors"
              >
                <div className={`w-8 h-8 rounded-full flex items-center justify-center ${tier?.cls}`}>
                  <Icon size={14} />
                </div>
                <span className="text-xs font-semibold text-foreground">{tier?.label}</span>
                <span className="text-[10px] text-muted-foreground font-mono-data">{tier?.range}</span>
              </div>
            );
          })}
        </div>
      </div>
      {/* Bottom: Stats */}
      <div>
        <div className="flex items-center gap-6">
          {stats?.map((stat) => (
            <div key={stat?.key}>
              <p className="text-xl font-extrabold text-foreground font-mono-data">{stat?.value}</p>
              <p className="text-[11px] text-muted-foreground">{stat?.label}</p>
            </div>
          ))}
        </div>
        <p className="text-[11px] text-muted-foreground mt-4 border-t border-border pt-4">
          Questions aligned to official GATE CS 2025 syllabus · Negative marking simulated
        </p>
      </div>
    </div>
  );
}