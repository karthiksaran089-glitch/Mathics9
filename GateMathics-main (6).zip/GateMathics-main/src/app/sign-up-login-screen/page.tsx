import React from 'react';
import Toast from '@/components/ui/Toast';
import AuthPageClient from './components/AuthPageClient';

export default function SignUpLoginPage() {
  return (
    <>
      <AuthPageClient />
      <Toast />
    </>
  );
}