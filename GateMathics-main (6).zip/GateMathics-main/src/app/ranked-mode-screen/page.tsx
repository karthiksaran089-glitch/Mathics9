import React from 'react';
import type { Metadata } from 'next';
import { PAGE_SEO } from '@/lib/seo/gateSeoConfig';

export const metadata: Metadata = PAGE_SEO.ranked;

export { default } from './RankedModePage';