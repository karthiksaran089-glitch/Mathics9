'use client';
import React from 'react';
import Link from 'next/link';
import AppLogo from '@/components/ui/AppLogo';

import { Trophy, ChevronRight, Flame, Star } from 'lucide-react';
import type { SessionState } from './RankedModeClient';

const STEPS = [
  { key: 'step-draft', label: 'Draft & Ban', phase: 'lobby' },
  { key: 'step-question', label: 'Question', phase: 'question' },
  { key: 'step-feedback', label: 'Feedback', phase: 'feedback' },
  { key: 'step-summary', label: 'Summary', phase: 'summary' },
];

interface RankedHeaderProps {
  session: SessionState;
}

export default function RankedHeader({ session }: RankedHeaderProps) {
  const activeIndex = STEPS.findIndex((s) => s.phase === session.phase);
  const lpDelta = session.currentLP - session.baseLP;

  return (
    <header className="sticky top-0 z-10 bg-card/90 backdrop-blur-md border-b border-border">
      <div className="w-full px-4 h-14 flex items-center justify-between gap-2">
        {/* Left: Logo + LP */}
        <div className="flex items-center gap-2 flex-shrink-0">
          <Link href="/" className="flex items-center gap-2">
            <AppLogo size={26} />
            <span className="font-bold text-sm text-gradient-primary">GateMathics</span>
          </Link>
          <div className="hidden sm:flex items-center gap-1.5 ml-2">
            <Trophy size={13} className="text-accent" />
            <span className="font-mono-data text-sm font-bold text-accent">{session.currentLP} LP</span>
            {lpDelta !== 0 && (
              <span className={`font-mono-data text-xs font-semibold ${lpDelta > 0 ? 'text-success' : 'text-danger'}`}>
                ({lpDelta > 0 ? '+' : ''}{lpDelta})
              </span>
            )}
          </div>
        </div>

        {/* Center: Step progress (desktop only) */}
        <div className="hidden md:flex items-center gap-1">
          {STEPS.map((step, i) => {
            const isActive = step.phase === session.phase;
            const isPast = i < activeIndex;
            return (
              <React.Fragment key={step.key}>
                <div
                  className={`flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold transition-all ${
                    isActive
                      ? 'bg-accent/20 text-accent border border-accent/40'
                      : isPast
                      ? 'text-success' :'text-muted-foreground'
                  }`}
                >
                  <span
                    className={`w-4 h-4 rounded-full flex items-center justify-center text-[10px] font-bold ${
                      isActive
                        ? 'bg-accent text-accent-foreground'
                        : isPast
                        ? 'bg-success text-white' :'bg-muted text-muted-foreground'
                    }`}
                  >
                    {isPast ? '✓' : i + 1}
                  </span>
                  {step.label}
                </div>
                {i < STEPS.length - 1 && (
                  <ChevronRight size={12} className="text-border" />
                )}
              </React.Fragment>
            );
          })}
        </div>

        {/* Right: Streak + Rank badge */}
        <div className="flex items-center gap-2 flex-shrink-0">
          {/* Mobile LP display */}
          <div className="flex sm:hidden items-center gap-1">
            <Trophy size={12} className="text-accent" />
            <span className="font-mono-data text-xs font-bold text-accent">{session.currentLP}</span>
          </div>
          {/* Streak */}
          <div className="flex items-center gap-1 px-2 py-1 rounded-full bg-accent/10 border border-accent/20">
            <Flame size={12} className="text-accent streak-flame" />
            <span className="font-mono-data text-xs font-bold text-accent">7</span>
          </div>
          {/* Rank badge */}
          <div className="flex items-center gap-1 px-2.5 py-1 rounded-full bg-yellow-500/20 border border-yellow-500/40">
            <Star size={10} className="text-yellow-400" />
            <span className="text-[11px] font-bold text-yellow-400 uppercase tracking-wide">GOLD III</span>
          </div>
        </div>
      </div>

      {/* Mobile phase subtitle */}
      {session.phase === 'lobby' && (
        <div className="px-4 pb-3 md:hidden">
          <p className="text-xs text-muted-foreground">
            5 questions · Gold III bracket
          </p>
          <div className="flex items-center gap-2 mt-1">
            <h2 className="text-lg font-bold text-foreground">Draft &amp; Ban</h2>
            <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-accent/20 text-accent border border-accent/30 uppercase tracking-wide">
              Ranked Match
            </span>
          </div>
          <p className="text-xs text-muted-foreground mt-0.5">
            Ban up to 2 topics from the question pool, then set your LP wager.
          </p>
        </div>
      )}
    </header>
  );
}