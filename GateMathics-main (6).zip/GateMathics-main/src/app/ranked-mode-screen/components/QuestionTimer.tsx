'use client';
import React, { useEffect, useRef, useState } from 'react';

interface QuestionTimerProps {
  totalSeconds: number;
  stopped: boolean;
  onTimeout: () => void;
  onTick?: (remaining: number) => void;
}

export default function QuestionTimer({ totalSeconds, stopped, onTimeout, onTick }: QuestionTimerProps) {
  const [remaining, setRemaining] = useState(totalSeconds);
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const hasTimedOut = useRef(false);

  useEffect(() => {
    setRemaining(totalSeconds);
    hasTimedOut.current = false;
  }, [totalSeconds]);

  useEffect(() => {
    if (stopped) {
      if (intervalRef.current) clearInterval(intervalRef.current);
      return;
    }

    intervalRef.current = setInterval(() => {
      setRemaining((prev) => {
        const next = prev - 1;
        if (next <= 0 && !hasTimedOut.current) {
          hasTimedOut.current = true;
          clearInterval(intervalRef.current!);
          setTimeout(() => onTimeout(), 0);
          return 0;
        }
        return next;
      });
    }, 1000);

    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current);
    };
  }, [stopped, onTimeout]);

  // Fire onTick outside the state updater to avoid setState-in-render warnings
  useEffect(() => {
    if (!stopped) {
      onTick?.(remaining);
    }
  }, [remaining, stopped]);

  const pct = (remaining / totalSeconds) * 100;
  const isUrgent = remaining <= 10;
  const circumference = 2 * Math.PI * 26;
  const strokeDashoffset = circumference - (pct / 100) * circumference;

  return (
    <div className="flex flex-col items-center gap-1" aria-label={`${remaining} seconds remaining`}>
      <div className="relative w-16 h-16">
        <svg className="w-full h-full -rotate-90" viewBox="0 0 60 60" aria-hidden="true">
          <circle cx="30" cy="30" r="26" fill="none" stroke="var(--border)" strokeWidth="4" />
          <circle
            cx="30"
            cy="30"
            r="26"
            fill="none"
            stroke={isUrgent ? 'var(--danger)' : remaining <= 20 ? 'var(--warning)' : 'var(--primary)'}
            strokeWidth="4"
            strokeLinecap="round"
            strokeDasharray={circumference}
            strokeDashoffset={strokeDashoffset}
            style={{ transition: 'stroke-dashoffset 0.9s linear, stroke 0.3s ease' }}
          />
        </svg>
        <div className="absolute inset-0 flex items-center justify-center">
          <span
            className={`font-mono-data text-lg font-bold ${
              isUrgent ? 'text-danger timer-pulse' : remaining <= 20 ? 'text-warning' : 'text-foreground'
            }`}
          >
            {remaining}
          </span>
        </div>
      </div>
      <span className="text-[10px] text-muted-foreground">seconds</span>
    </div>
  );
}