'use client';
import React from 'react';
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ReferenceLine,
} from 'recharts';
import type { QuestionResult } from './RankedModeClient';

interface SummaryLPChartProps {
  results: QuestionResult[];
  baseLP: number;
}

interface CustomTooltipProps {
  active?: boolean;
  payload?: Array<{ value: number }>;
  label?: string;
}

function CustomTooltip({ active, payload, label }: CustomTooltipProps) {
  if (!active || !payload || !payload.length) return null;
  return (
    <div className="card-elevated px-3 py-2 text-xs shadow-xl">
      <p className="text-muted-foreground mb-1">After Q{label}</p>
      <p className="font-mono-data font-bold text-foreground">{payload[0].value} LP</p>
    </div>
  );
}

export default function SummaryLPChart({ results, baseLP }: SummaryLPChartProps) {
  let running = baseLP;
  const data = [
    { key: 'lp-start', label: '0', lp: baseLP },
    ...results.map((r) => {
      running += r.lpDelta;
      return { key: `lp-q${r.questionNum}`, label: String(r.questionNum), lp: running };
    }),
  ];

  return (
    <ResponsiveContainer width="100%" height={140}>
      <LineChart data={data} margin={{ top: 8, right: 8, left: -20, bottom: 0 }}>
        <defs>
          <linearGradient id="lpLineGrad" x1="0" y1="0" x2="1" y2="0">
            <stop offset="0%" stopColor="var(--primary)" />
            <stop offset="100%" stopColor="var(--info)" />
          </linearGradient>
        </defs>
        <CartesianGrid stroke="var(--border)" strokeDasharray="3 3" vertical={false} />
        <XAxis
          dataKey="label"
          tick={{ fill: 'var(--muted-foreground)', fontSize: 10 }}
          axisLine={false}
          tickLine={false}
        />
        <YAxis
          tick={{ fill: 'var(--muted-foreground)', fontSize: 10 }}
          axisLine={false}
          tickLine={false}
          width={40}
        />
        <ReferenceLine y={baseLP} stroke="var(--border)" strokeDasharray="4 4" />
        <Tooltip content={<CustomTooltip />} />
        <Line
          type="monotone"
          dataKey="lp"
          stroke="url(#lpLineGrad)"
          strokeWidth={2.5}
          dot={{ fill: 'var(--primary)', r: 3, strokeWidth: 0 }}
          activeDot={{ r: 5, fill: 'var(--accent)' }}
        />
      </LineChart>
    </ResponsiveContainer>
  );
}