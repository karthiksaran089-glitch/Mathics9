'use client';
import React from 'react';

import { CheckCircle2, XCircle, Clock, ChevronRight, BookOpen } from 'lucide-react';
import type { SessionState } from './RankedModeClient';

interface FeedbackData {
  correct: boolean | 'timeout';
  selectedOption: number | null;
  correctOption: number;
  explanation: string;
  questionText: string;
  options: string[];
  lpDelta: number;
  topic: string;
  timeUsed: number;
}

interface FeedbackPhaseProps {
  feedback: FeedbackData;
  session: SessionState;
  onNext: () => void;
}

export default function FeedbackPhase({ feedback, session, onNext }: FeedbackPhaseProps) {
  const isCorrect = feedback.correct === true;
  const isTimeout = feedback.correct === 'timeout';
  const optionLabels = ['A', 'B', 'C', 'D'];
  const isLastQuestion = session.currentQuestion >= session.totalQuestions;

  return (
    <div className="max-w-3xl mx-auto fade-in-up">
      {/* Verdict banner */}
      <div className={`flex items-center justify-between gap-4 p-4 rounded-xl mb-5 border ${
        isCorrect
          ? 'bg-success/10 border-success/30'
          : isTimeout
          ? 'bg-warning/10 border-warning/30' :'bg-danger/10 border-danger/30'
      }`}>
        <div className="flex items-center gap-3">
          {isCorrect ? (
            <CheckCircle2 size={24} className="text-success" />
          ) : isTimeout ? (
            <Clock size={24} className="text-warning" />
          ) : (
            <XCircle size={24} className="text-danger" />
          )}
          <div>
            <p className={`text-base font-bold ${
              isCorrect ? 'text-success' : isTimeout ? 'text-warning' : 'text-danger'
            }`}>
              {isCorrect ? 'Correct!' : isTimeout ? 'Time Out' : 'Incorrect'}
            </p>
            <p className="text-xs text-muted-foreground">
              {isTimeout
                ? 'You ran out of time — no answer submitted'
                : isCorrect
                ? `Answered in ${feedback.timeUsed}s`
                : `You selected option ${feedback.selectedOption !== null ? optionLabels[feedback.selectedOption] : '—'}`}
            </p>
          </div>
        </div>
        <div className="text-right flex-shrink-0">
          <p className={`font-mono-data text-xl font-bold ${
            feedback.lpDelta > 0 ? 'text-success' : 'text-danger'
          }`}>
            {feedback.lpDelta > 0 ? '+' : ''}{feedback.lpDelta} LP
          </p>
          <p className="text-xs text-muted-foreground">New total: {session.currentLP} LP</p>
        </div>
      </div>

      {/* Question recap */}
      <div className="card-elevated p-5 mb-4">
        <div className="flex items-center gap-2 mb-3">
          <BookOpen size={13} className="text-muted-foreground" />
          <span className="text-xs text-muted-foreground font-medium">{feedback.topic}</span>
        </div>
        <p className="text-sm font-medium text-foreground leading-relaxed mb-4">
          {feedback.questionText}
        </p>

        {/* Options with correct/wrong highlight */}
        <div className="flex flex-col gap-2">
          {feedback.options.map((option, idx) => {
            const isCorrectOption = idx === feedback.correctOption;
            const isSelectedOption = idx === feedback.selectedOption;
            const isWrongSelected = isSelectedOption && !isCorrect;

            let cls = 'option-idle opacity-50';
            if (isCorrectOption) cls = 'option-correct';
            else if (isWrongSelected) cls = 'option-wrong';

            return (
              <div
                key={`feedback-opt-${idx}`}
                className={`flex items-start gap-3 p-3 rounded-xl border ${cls}`}
              >
                <span className={`w-6 h-6 rounded-lg flex items-center justify-center text-xs font-bold flex-shrink-0 ${
                  isCorrectOption
                    ? 'bg-success text-white'
                    : isWrongSelected
                    ? 'bg-danger text-white' :'bg-muted text-muted-foreground'
                }`}>
                  {optionLabels[idx]}
                </span>
                <span className="text-sm text-foreground leading-relaxed pt-0.5 flex-1">{option}</span>
                {isCorrectOption && (
                  <CheckCircle2 size={15} className="text-success flex-shrink-0 mt-0.5" />
                )}
                {isWrongSelected && (
                  <XCircle size={15} className="text-danger flex-shrink-0 mt-0.5" />
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* Explanation */}
      <div className="card-elevated p-5 mb-5">
        <p className="text-xs font-bold uppercase tracking-widest text-muted-foreground mb-2">
          Explanation
        </p>
        <p className="text-sm text-foreground leading-relaxed">{feedback.explanation}</p>
      </div>

      {/* Next action */}
      <div className="flex justify-end">
        <button
          onClick={onNext}
          className="btn-primary flex items-center gap-2 px-6 py-3 text-sm"
        >
          {isLastQuestion ? 'View Session Summary' : 'Next Question'}
          <ChevronRight size={16} />
        </button>
      </div>
    </div>
  );
}