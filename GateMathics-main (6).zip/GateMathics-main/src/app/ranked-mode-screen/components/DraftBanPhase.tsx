'use client';
import React, { useState } from 'react';
import { toast } from 'sonner';
import { Trophy, Ban, Info } from 'lucide-react';

const ALL_TOPICS = [
  { id: 'topic-os', name: 'Operating Systems', short: 'OS', completion: 72, weight: 'High' },
  { id: 'topic-dbms', name: 'DBMS', short: 'DBMS', completion: 58, weight: 'Medium' },
  { id: 'topic-algo', name: 'Algorithms', short: 'ALGO', completion: 81, weight: 'High' },
  { id: 'topic-ds', name: 'Data Structures', short: 'DS', completion: 76, weight: 'High' },
  { id: 'topic-cn', name: 'Computer Networks', short: 'CN', completion: 64, weight: 'High' },
  { id: 'topic-toc', name: 'Theory of Computation', short: 'TOC', completion: 43, weight: 'High' },
  { id: 'topic-co', name: 'Computer Organisation', short: 'COA', completion: 55, weight: 'Medium' },
  { id: 'topic-dm', name: 'Discrete Mathematics', short: 'DM', completion: 69, weight: 'Medium' },
  { id: 'topic-pl', name: 'Programming Languages', short: 'PL', completion: 77, weight: 'Low' },
  { id: 'topic-cd', name: 'Software Engineering', short: 'CD', completion: 82, weight: 'Medium' },
  { id: 'topic-se', name: 'Compiler Software', short: 'SE', completion: 82, weight: 'Low' },
  { id: 'topic-ai', name: 'Artificial Intelligence', short: 'AI', completion: 48, weight: 'Low' },
];

const LP_WAGERS = [
  { key: 'wager-25', value: 25, label: '25 LP' },
  { key: 'wager-50', value: 50, label: '50 LP' },
  { key: 'wager-75', value: 75, label: '75 LP' },
  { key: 'wager-100', value: 100, label: '100 LP' },
  { key: 'wager-150', value: 150, label: '150 LP' },
];

interface DraftBanPhaseProps {
  onStart: (lpWager: number, selectedTopics: string[], bannedTopics: string[]) => void;
}

export default function DraftBanPhase({ onStart }: DraftBanPhaseProps) {
  const [selectedTopics, setSelectedTopics] = useState<string[]>([]);
  const [bannedTopics, setBannedTopics] = useState<string[]>([]);
  const [lpWager, setLpWager] = useState(50);
  const [mode, setMode] = useState<'select' | 'ban'>('select');

  const toggleTopic = (topicId: string) => {
    if (mode === 'select') {
      if (bannedTopics.includes(topicId)) return;
      setSelectedTopics((prev) =>
        prev.includes(topicId) ? prev.filter((t) => t !== topicId) : [...prev, topicId]
      );
    } else {
      if (selectedTopics.includes(topicId)) {
        toast.error('Cannot ban a selected topic. Deselect it first.');
        return;
      }
      if (!bannedTopics.includes(topicId) && bannedTopics.length >= 2) {
        toast.error('You can only ban up to 2 topics.');
        return;
      }
      setBannedTopics((prev) =>
        prev.includes(topicId) ? prev.filter((t) => t !== topicId) : [...prev, topicId]
      );
    }
  };

  const handleStart = () => {
    if (selectedTopics.length === 0 && bannedTopics.length === ALL_TOPICS.length) {
      toast.error('You must leave at least one topic available.');
      return;
    }
    onStart(lpWager, selectedTopics, bannedTopics);
  };

  const getTopicState = (topicId: string) => {
    if (bannedTopics.includes(topicId)) return 'banned';
    if (selectedTopics.includes(topicId)) return 'selected';
    return 'idle';
  };

  return (
    <div className="w-full">
      {/* Topic Pool */}
      <div className="card-elevated p-4 mb-4">
        <div className="flex items-center justify-between mb-3">
          <div>
            <h2 className="text-sm font-semibold text-foreground">Topic Pool</h2>
            <p className="text-xs text-muted-foreground mt-0.5">Ban topics you want to avoid.</p>
          </div>
          <span className="text-xs text-muted-foreground">{bannedTopics.length}/2 bans</span>
        </div>

        {/* Responsive grid: 1-col on small phones, 2-col on tablets, 3-col on desktop */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2">
          {ALL_TOPICS.map((topic) => {
            const state = getTopicState(topic.id);
            const isBanned = state === 'banned';
            const isSelected = state === 'selected';
            return (
              <button
                key={topic.id}
                onClick={() => toggleTopic(topic.id)}
                className={`flex flex-col p-3 rounded-xl border text-left transition-all duration-150 w-full ${
                  isSelected
                    ? 'border-primary/60 bg-primary/10'
                    : isBanned
                    ? 'border-danger/40 bg-danger/10 opacity-60' :'border-border bg-muted/30 hover:border-border/80 hover:bg-muted/60'
                }`}
              >
                {/* Short label + percentage row */}
                <div className="flex items-center justify-between mb-1">
                  <span className="text-[10px] font-bold text-muted-foreground bg-muted px-1.5 py-0.5 rounded">
                    {topic.short}
                  </span>
                  <span className={`text-[11px] font-bold font-mono-data ${
                    topic.completion >= 80 ? 'text-success' :
                    topic.completion >= 65 ? 'text-accent' : 'text-danger'
                  }`}>
                    {isBanned && <span className="text-danger">●</span>}
                    {topic.completion}%
                  </span>
                </div>
                {/* Topic name */}
                <p className={`text-xs font-semibold leading-tight mb-2 ${
                  isSelected ? 'text-primary' : isBanned ? 'text-danger line-through' : 'text-foreground'
                }`}>
                  {topic.name}
                </p>
                {/* Progress bar */}
                <div className="w-full h-1 progress-bar-bg rounded-full">
                  <div
                    className={`h-1 rounded-full ${
                      topic.completion >= 80 ? 'bg-success' :
                      topic.completion >= 65 ? 'bg-accent' : 'bg-danger'
                    }`}
                    style={{ width: `${topic.completion}%` }}
                  />
                </div>
              </button>
            );
          })}
        </div>

        <div className="flex items-center gap-4 mt-3 pt-3 border-t border-border">
          <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
            <div className="w-2 h-2 rounded-full bg-primary" />
            {selectedTopics.length} selected
          </div>
          <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
            <div className="w-2 h-2 rounded-full bg-danger" />
            {bannedTopics.length} banned
          </div>
          <div className="flex items-center gap-1.5 text-xs text-muted-foreground ml-auto">
            <Info size={11} />
            {selectedTopics.length === 0 ? 'All topics in pool' : `${selectedTopics.length} topic${selectedTopics.length > 1 ? 's' : ''} in pool`}
          </div>
        </div>
      </div>

      {/* LP Wager */}
      <div className="card-elevated p-4 mb-4">
        <h2 className="text-sm font-semibold text-foreground mb-3">LP Wager</h2>
        <div className="flex flex-wrap gap-2">
          {LP_WAGERS.map((wager) => (
            <button
              key={wager.key}
              onClick={() => setLpWager(wager.value)}
              className={`flex items-center gap-1.5 px-4 py-2 rounded-full border text-sm font-semibold transition-all duration-150 ${
                lpWager === wager.value
                  ? 'border-primary bg-primary/20 text-primary ring-2 ring-primary/30' :'border-border bg-muted/30 text-muted-foreground hover:bg-muted/60'
              }`}
            >
              <span className="text-accent">⚡</span>
              {wager.label}
            </button>
          ))}
        </div>
      </div>

      {/* Start Button */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 p-4 card-elevated mb-20 md:mb-4">
        <div>
          <p className="text-sm font-semibold text-foreground">Ready to compete?</p>
          <p className="text-xs text-muted-foreground mt-0.5">
            10 questions · {lpWager} LP wager
          </p>
        </div>
        <button
          onClick={handleStart}
          className="btn-primary flex items-center justify-center gap-2 px-6 py-2.5 text-sm glow-primary"
        >
          <Trophy size={15} />
          Start Match
        </button>
      </div>
    </div>
  );
}