'use client';
import React from 'react';
import dynamic from 'next/dynamic';
import Link from 'next/link';
import Badge from '@/components/ui/Badge';
import { Trophy, CheckCircle2, XCircle, Clock, BarChart3, RotateCcw, BookOpen, Star } from 'lucide-react';
import type { SessionState, QuestionResult } from './RankedModeClient';

const SummaryLPChart = dynamic(() => import('./SummaryLPChart'), { ssr: false });

interface SummaryPhaseProps {
  session: SessionState;
  onPlayAgain: () => void;
}

function getResultBadge(result: QuestionResult) {
  if (result.correct === true) return <Badge variant="success" size="sm"><CheckCircle2 size={9} />Correct</Badge>;
  if (result.correct === 'timeout') return <Badge variant="warning" size="sm"><Clock size={9} />Timeout</Badge>;
  return <Badge variant="danger" size="sm"><XCircle size={9} />Wrong</Badge>;
}

export default function SummaryPhase({ session, onPlayAgain }: SummaryPhaseProps) {
  const { results, currentLP, baseLP, lpWager } = session;

  const totalLPDelta = currentLP - baseLP;
  const correct = results.filter((r) => r.correct === true).length;
  const wrong = results.filter((r) => r.correct === false).length;
  const timeout = results.filter((r) => r.correct === 'timeout').length;
  const accuracy = results.length > 0 ? Math.round((correct / results.length) * 100) : 0;
  const avgSpeed = results.length > 0
    ? Math.round(results.reduce((sum, r) => sum + r.timeUsed, 0) / results.length)
    : 0;

  // Best streak
  let bestStreak = 0;
  let streak = 0;
  for (const r of results) {
    if (r.correct === true) { streak++; bestStreak = Math.max(bestStreak, streak); }
    else streak = 0;
  }

  const isPositive = totalLPDelta >= 0;

  return (
    <div className="max-w-3xl mx-auto fade-in-up">
      {/* Session complete header */}
      <div className="text-center mb-8">
        <div className="w-16 h-16 rounded-2xl mx-auto mb-4 flex items-center justify-center glow-gold"
          style={{ background: 'linear-gradient(135deg, #FCD34D 0%, #F59E0B 100%)' }}>
          <Trophy size={28} className="text-accent-foreground" />
        </div>
        <h1 className="text-2xl font-extrabold text-foreground mb-1">Session Complete</h1>
        <p className="text-sm text-muted-foreground">
          {correct >= 8 ? 'Outstanding performance! 🔥' :
           correct >= 6 ? 'Solid run — keep grinding! 💪': 'Tough session — review the breakdowns below 📚'}
        </p>
      </div>

      {/* LP delta hero */}
      <div className={`flex items-center justify-between p-5 rounded-2xl mb-5 border ${
        isPositive ? 'bg-success/10 border-success/30' : 'bg-danger/10 border-danger/30'
      }`}>
        <div>
          <p className="text-xs text-muted-foreground mb-1">LP Change This Session</p>
          <p className={`font-mono-data text-4xl font-extrabold ${isPositive ? 'text-success' : 'text-danger'}`}>
            {isPositive ? '+' : ''}{totalLPDelta}
          </p>
          <p className="text-xs text-muted-foreground mt-1">
            {baseLP} LP → <span className="text-foreground font-semibold">{currentLP} LP</span>
          </p>
        </div>
        <div className="text-right">
          <Badge variant="silver" size="md">
            <Star size={11} />
            Silver Rank
          </Badge>
          <p className="text-xs text-muted-foreground mt-2">
            {1000 - currentLP > 0 ? `${1000 - currentLP} LP to Gold` : 'Gold unlocked! 🥇'}
          </p>
        </div>
      </div>

      {/* Stats row */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-5">
        {[
          { id: 'sum-acc', label: 'Accuracy', value: `${accuracy}%`, color: accuracy >= 70 ? 'text-success' : accuracy >= 50 ? 'text-warning' : 'text-danger' },
          { id: 'sum-speed', label: 'Avg Speed', value: `${avgSpeed}s`, color: 'text-info' },
          { id: 'sum-streak', label: 'Best Streak', value: `${bestStreak}`, color: 'text-accent' },
          { id: 'sum-wager', label: 'LP Wager', value: `${lpWager}`, color: 'text-primary' },
        ].map((stat) => (
          <div key={stat.id} className="card-elevated p-4 text-center">
            <p className="text-[10px] text-muted-foreground mb-1">{stat.label}</p>
            <p className={`font-mono-data text-2xl font-bold ${stat.color}`}>{stat.value}</p>
          </div>
        ))}
      </div>

      {/* LP Progression chart */}
      <div className="card-elevated p-5 mb-5">
        <h2 className="text-sm font-semibold text-foreground mb-4">LP Progression This Session</h2>
        <SummaryLPChart results={results} baseLP={baseLP} />
      </div>

      {/* Question breakdown */}
      <div className="card-elevated p-5 mb-6">
        <h2 className="text-sm font-semibold text-foreground mb-4">Question Breakdown</h2>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-border">
                {['#', 'Topic', 'Time', 'LP', 'Result'].map((h) => (
                  <th key={`th-${h}`} className="text-left text-[11px] font-semibold text-muted-foreground pb-2 pr-4 last:pr-0">
                    {h}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {results.map((result) => (
                <tr
                  key={result.questionId}
                  className="border-b border-border/40 hover:bg-muted/30 transition-colors"
                >
                  <td className="py-2.5 pr-4 font-mono-data text-xs text-muted-foreground">
                    Q{result.questionNum}
                  </td>
                  <td className="py-2.5 pr-4 text-xs text-foreground max-w-[140px] truncate">
                    {result.topic}
                  </td>
                  <td className="py-2.5 pr-4 font-mono-data text-xs text-muted-foreground">
                    {result.timeUsed}s
                  </td>
                  <td className={`py-2.5 pr-4 font-mono-data text-xs font-bold ${
                    result.lpDelta > 0 ? 'text-success' : 'text-danger'
                  }`}>
                    {result.lpDelta > 0 ? '+' : ''}{result.lpDelta}
                  </td>
                  <td className="py-2.5">
                    {getResultBadge(result)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Totals row */}
        <div className="flex items-center justify-between mt-4 pt-3 border-t border-border">
          <div className="flex items-center gap-4 text-xs">
            <span className="text-success font-semibold">{correct} correct</span>
            <span className="text-danger font-semibold">{wrong} wrong</span>
            <span className="text-warning font-semibold">{timeout} timeout</span>
          </div>
          <span className={`font-mono-data text-sm font-bold ${isPositive ? 'text-success' : 'text-danger'}`}>
            {isPositive ? '+' : ''}{totalLPDelta} LP net
          </span>
        </div>
      </div>

      {/* Actions */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
        <button
          onClick={onPlayAgain}
          className="btn-primary flex items-center justify-center gap-2 flex-1 py-3 text-sm"
        >
          <RotateCcw size={15} />
          Play Again
        </button>
        <Link
          href="/practice"
          className="btn-secondary flex items-center justify-center gap-2 flex-1 py-3 text-sm"
        >
          <BookOpen size={15} />
          Practice Mode
        </Link>
        <Link
          href="/analytics"
          className="btn-secondary flex items-center justify-center gap-2 flex-1 py-3 text-sm"
        >
          <BarChart3 size={15} />
          View Analytics
        </Link>
      </div>
    </div>
  );
}