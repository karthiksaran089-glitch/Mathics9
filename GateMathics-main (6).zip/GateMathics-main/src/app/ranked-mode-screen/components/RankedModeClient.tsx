'use client';
import React, { useState, useCallback, useEffect } from 'react';
import Toast from '@/components/ui/Toast';
import RankedHeader from './RankedHeader';
import DraftBanPhase from './DraftBanPhase';
import QuestionPhase from './QuestionPhase';
import FeedbackPhase from './FeedbackPhase';
import SummaryPhase from './SummaryPhase';
import LevelUpModal from '@/components/LevelUpModal';
import { createClient } from '@/lib/supabase/client';
import { getLevelInfo, getBadgesWithState, type UserProfileStats, type LevelInfo, type BadgeDefinition } from '@/lib/gamification';

export type RankedPhase = 'lobby' | 'question' | 'feedback' | 'summary';

export interface QuestionResult {
  questionId: string;
  questionNum: number;
  topic: string;
  correct: boolean | 'timeout';
  lpDelta: number;
  timeUsed: number;
}

export interface SessionState {
  phase: RankedPhase;
  currentQuestion: number;
  totalQuestions: number;
  lpWager: number;
  selectedTopics: string[];
  bannedTopics: string[];
  results: QuestionResult[];
  currentLP: number;
  baseLP: number;
  previousQuestionIds: string[];
}

const FALLBACK_LP = 0;

// Save completed ranked session to Supabase and update user profile stats
async function saveRankedSession(session: SessionState) {
  const supabase = createClient();
  if (!supabase) return;
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return;

  const results = session.results;
  const correct = results.filter((r) => r.correct === true).length;
  const incorrect = results.filter((r) => r.correct === false).length;
  const timeout = results.filter((r) => r.correct === 'timeout').length;
  const total = results.length;
  const accuracy = total > 0 ? Math.round((correct / total) * 100 * 100) / 100 : 0;
  const avgSpeed = total > 0 ? Math.round((results.reduce((s, r) => s + r.timeUsed, 0) / total) * 100) / 100 : 0;
  const lpChange = session.currentLP - session.baseLP;

  // Determine rank from LP
  const getRank = (lp: number) => {
    if (lp >= 2500) return 'Grandmaster';
    if (lp >= 2000) return 'Diamond';
    if (lp >= 1500) return 'Platinum';
    if (lp >= 1000) return 'Gold';
    if (lp >= 500) return 'Silver';
    return 'Bronze';
  };

  const rankBefore = getRank(session.baseLP);
  const rankAfter = getRank(session.currentLP);

  // Insert session record
  const { error: sessionError } = await supabase.from('ranked_sessions').insert({
    user_id: user.id,
    questions_total: total,
    questions_correct: correct,
    questions_incorrect: incorrect,
    questions_timeout: timeout,
    accuracy,
    avg_speed_seconds: avgSpeed,
    lp_before: session.baseLP,
    lp_after: session.currentLP,
    lp_change: lpChange,
    rank_before: rankBefore,
    rank_after: rankAfter,
    topics_played: session.selectedTopics,
    topics_banned: session.bannedTopics,
  });
  if (sessionError) {
    console.error('[RankedMode] Failed to save ranked session:', JSON.stringify(sessionError));
  } else {
    console.log('[RankedMode] Ranked session saved successfully. LP change:', lpChange, 'Accuracy:', accuracy);
  }

  // Fetch current profile stats
  const { data: profile } = await supabase
    .from('user_profiles')
    .select('total_questions_answered, total_correct, total_incorrect, total_timeout, total_sessions, total_ranked_sessions, total_practice_sessions, avg_answer_speed_seconds, lp, rank, daily_streak, longest_streak, last_active_date')
    .eq('id', user.id)
    .single();

  if (profile) {
    const newTotalQ = (profile.total_questions_answered || 0) + total;
    const newTotalCorrect = (profile.total_correct || 0) + correct;
    const newTotalIncorrect = (profile.total_incorrect || 0) + incorrect;
    const newTotalTimeout = (profile.total_timeout || 0) + timeout;
    const newOverallAccuracy = newTotalQ > 0 ? Math.round((newTotalCorrect / newTotalQ) * 100 * 100) / 100 : 0;
    const newAvgSpeed = profile.avg_answer_speed_seconds
      ? Math.round(((Number(profile.avg_answer_speed_seconds) + avgSpeed) / 2) * 100) / 100
      : avgSpeed;
    const newLP = Math.max(0, session.currentLP);
    const newRank = getRank(newLP);

    // Update streak based on last_active_date
    const today = new Date().toISOString().split('T')[0];
    const lastActive = profile.last_active_date;
    let newStreak = profile.daily_streak || 0;
    
    if (lastActive !== today) {
      if (lastActive) {
        const lastDate = new Date(lastActive);
        const currentDate = new Date(today);
        const diffTime = Math.abs(currentDate.getTime() - lastDate.getTime());
        const diffDays = Math.round(diffTime / (1000 * 60 * 60 * 24));
        if (diffDays === 1) {
          newStreak += 1;
        } else if (diffDays > 1) {
          newStreak = 1;
        }
      } else {
        newStreak = 1;
      }
    } else if (newStreak === 0) {
      newStreak = 1; // First session today
    }
    const newLongestStreak = Math.max(profile.longest_streak || 0, newStreak);

    // Compute level before update
    const oldStats: UserProfileStats = {
      total_questions_answered: profile.total_questions_answered || 0,
      total_correct: profile.total_correct || 0,
      total_incorrect: profile.total_incorrect || 0,
      total_timeout: profile.total_timeout || 0,
      total_sessions: profile.total_sessions || 0,
      total_ranked_sessions: profile.total_ranked_sessions || 0,
      total_practice_sessions: profile.total_practice_sessions || 0,
      overall_accuracy: Number(profile.overall_accuracy) || 0,
      avg_answer_speed_seconds: Number(profile.avg_answer_speed_seconds) || 0,
      daily_streak: profile.daily_streak || 0,
      longest_streak: profile.longest_streak || 0,
      lp: profile.lp || 0,
      rank: profile.rank || 'Silver',
    };
    const oldLevel = getLevelInfo(oldStats);
    const oldBadgeIds = getBadgesWithState(oldStats).filter(b => b.unlocked).map(b => b.id);

    await supabase.from('user_profiles').update({
      lp: newLP,
      rank: newRank,
      total_questions_answered: newTotalQ,
      total_correct: newTotalCorrect,
      total_incorrect: newTotalIncorrect,
      total_timeout: newTotalTimeout,
      overall_accuracy: newOverallAccuracy,
      avg_answer_speed_seconds: newAvgSpeed,
      total_sessions: (profile.total_sessions || 0) + 1,
      total_ranked_sessions: (profile.total_ranked_sessions || 0) + 1,
      daily_streak: newStreak,
      longest_streak: newLongestStreak,
      last_active_date: today,
    }).eq('id', user.id);

    // Compute level after update
    const newStats: UserProfileStats = {
      ...oldStats,
      total_correct: newTotalCorrect,
      total_sessions: (profile.total_sessions || 0) + 1,
      total_ranked_sessions: (profile.total_ranked_sessions || 0) + 1,
      lp: newLP,
      rank: newRank,
    };
    const newLevelInfo = getLevelInfo(newStats);
    const newBadges = getBadgesWithState(newStats)
      .filter(b => b.unlocked && !oldBadgeIds.includes(b.id));

    if (newLevelInfo.level > oldLevel.level || newBadges.length > 0) {
      return {
        leveledUp: newLevelInfo.level > oldLevel.level,
        previousLevel: oldLevel.level,
        newLevelInfo,
        newBadges,
      };
    }
  }
  return null;
}

export default function RankedModeClient() {
  const [userLP, setUserLP] = useState<number>(FALLBACK_LP);
  const [lpLoaded, setLpLoaded] = useState(false);

  // Load real LP from DB on mount
  useEffect(() => {
    const loadLP = async () => {
      const supabase = createClient();
      if (!supabase) { setLpLoaded(true); return; }
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) { setLpLoaded(true); return; }
      const { data } = await supabase
        .from('user_profiles')
        .select('lp')
        .eq('id', user.id)
        .single();
      if (data) setUserLP(data.lp ?? FALLBACK_LP);
      setLpLoaded(true);
    };
    loadLP();
  }, []);

  const [session, setSession] = useState<SessionState>({
    phase: 'lobby',
    currentQuestion: 0,
    totalQuestions: 10,
    lpWager: 100,
    selectedTopics: [],
    bannedTopics: [],
    results: [],
    currentLP: FALLBACK_LP,
    baseLP: FALLBACK_LP,
    previousQuestionIds: [],
  });

  const [levelUpData, setLevelUpData] = useState<{
    previousLevel: number;
    newLevelInfo: LevelInfo;
    newBadges: BadgeDefinition[];
  } | null>(null);

  // Sync LP into session once loaded
  useEffect(() => {
    if (lpLoaded) {
      setSession((prev) => ({
        ...prev,
        currentLP: userLP,
        baseLP: userLP,
      }));
    }
  }, [lpLoaded, userLP]);

  const [currentFeedback, setCurrentFeedback] = useState<{
    correct: boolean | 'timeout';
    selectedOption: number | null;
    correctOption: number;
    explanation: string;
    questionText: string;
    options: string[];
    lpDelta: number;
    topic: string;
    timeUsed: number;
  } | null>(null);

  const startMatch = (lpWager: number, selectedTopics: string[], bannedTopics: string[]) => {
      setSession((prev) => ({
        ...prev,
        phase: 'question',
        currentQuestion: 1,
        lpWager,
        selectedTopics,
        bannedTopics,
        results: [],
        currentLP: userLP,
        baseLP: userLP,
        previousQuestionIds: prev.results.map((r) => r.questionId),
      }));
  };

  const submitAnswer = (
    selectedOption: number | null,
    correctOption: number,
    isCorrect: boolean | 'timeout',
    questionText: string,
    options: string[],
    explanation: string,
    topic: string,
    timeUsed: number
  ) => {
    const lpDelta = isCorrect === true
      ? session.lpWager
      : isCorrect === 'timeout'
      ? -Math.floor(session.lpWager * 0.5)
      : -session.lpWager;

    const result: QuestionResult = {
      questionId: `q-${session.currentQuestion}`,
      questionNum: session.currentQuestion,
      topic,
      correct: isCorrect,
      lpDelta,
      timeUsed,
    };

    setCurrentFeedback({
      correct: isCorrect,
      selectedOption,
      correctOption,
      explanation,
      questionText,
      options,
      lpDelta,
      topic,
      timeUsed,
    });

    setSession((prev) => ({
      ...prev,
      phase: 'feedback',
      results: [...prev.results, result],
      currentLP: prev.currentLP + lpDelta,
    }));
  };

  const nextQuestion = () => {
    if (session.currentQuestion >= session.totalQuestions) {
      // Build final session state and save before showing summary
      const finalSession = { ...session, phase: 'summary' as RankedPhase };
      saveRankedSession(finalSession).then((result) => {
        if (result && (result.leveledUp || result.newBadges.length > 0)) {
          setLevelUpData({
            previousLevel: result.previousLevel,
            newLevelInfo: result.newLevelInfo,
            newBadges: result.newBadges,
          });
        }
      });
      // Update local LP so next match starts from correct value
      setUserLP(Math.max(0, finalSession.currentLP));
      setSession(finalSession);
    } else {
      setSession((prev) => ({
        ...prev,
        phase: 'question',
        currentQuestion: prev.currentQuestion + 1,
      }));
      setCurrentFeedback(null);
    }
  };

  const playAgain = () => {
    const previousQuestionIds = [
      ...new Set([...session.previousQuestionIds, ...session.results.map((r) => r.questionId)]),
    ];
    setSession({
      phase: 'lobby',
      currentQuestion: 0,
      totalQuestions: 10,
      lpWager: 100,
      selectedTopics: [],
      bannedTopics: [],
      results: [],
      currentLP: userLP,
      baseLP: userLP,
      previousQuestionIds,
    });
    setCurrentFeedback(null);
  };

  return (
    <div className="min-h-screen bg-background">
      <RankedHeader session={session} />

      <div className="w-full px-4 py-4 lg:max-w-screen-xl lg:mx-auto lg:px-8 lg:py-6">
        {session.phase === 'lobby' && (
          <DraftBanPhase onStart={startMatch} />
        )}
        {session.phase === 'question' && (
          <QuestionPhase session={session} onSubmit={submitAnswer} />
        )}
        {session.phase === 'feedback' && currentFeedback && (
          <FeedbackPhase
            feedback={currentFeedback}
            session={session}
            onNext={nextQuestion}
          />
        )}
        {session.phase === 'summary' && (
          <SummaryPhase session={session} onPlayAgain={playAgain} />
        )}
      </div>
      <Toast />

      {/* Level Up Modal */}
      {levelUpData && (
        <LevelUpModal
          previousLevel={levelUpData.previousLevel}
          newLevelInfo={levelUpData.newLevelInfo}
          newBadges={levelUpData.newBadges}
          onClose={() => setLevelUpData(null)}
        />
      )}
    </div>
  );
}
