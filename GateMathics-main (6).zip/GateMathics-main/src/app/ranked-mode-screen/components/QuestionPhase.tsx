'use client';
import React, { useState, useCallback, useRef, useEffect } from 'react';
import QuestionTimer from './QuestionTimer';
import Badge from '@/components/ui/Badge';
import { BookOpen, Clock, Loader2 } from 'lucide-react';
import type { SessionState } from './RankedModeClient';
import {
  fetchRankedQuestionPool,
  type FallbackQuestion,
} from '@/lib/questions/fallbackQuestions';

interface QuestionPhaseProps {
  session: SessionState;
  onSubmit: (
    selectedOption: number | null,
    correctOption: number,
    isCorrect: boolean | 'timeout',
    questionText: string,
    options: string[],
    explanation: string,
    topic: string,
    timeUsed: number
  ) => void;
}

export default function QuestionPhase({ session, onSubmit }: QuestionPhaseProps) {
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [timerStopped, setTimerStopped] = useState(false);
  const [timeUsed, setTimeUsed] = useState(0);
  const [question, setQuestion] = useState<FallbackQuestion | null>(null);
  const [loading, setLoading] = useState(true);
  const hasSubmitted = useRef(false);
  const usedIdsRef = useRef<string[]>([]);
  const questionPoolRef = useRef<FallbackQuestion[]>([]);
  const poolSignatureRef = useRef<string>('');

  // Load question: try Supabase ranked_questions table, fall back to local bank
  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    setSelectedOption(null);
    setTimerStopped(false);
    setTimeUsed(0);
    hasSubmitted.current = false;

    const load = async () => {
      // Map topic IDs to topic names (same mapping as DraftBanPhase)
      const topicMap: Record<string, string> = {
        'topic-os': 'Operating Systems', 'topic-dbms': 'DBMS', 'topic-algo': 'Algorithms',
        'topic-ds': 'Data Structures', 'topic-cn': 'Computer Networks', 'topic-toc': 'Theory of Computation',
        'topic-co': 'Computer Organisation', 'topic-dm': 'Discrete Mathematics', 'topic-pl': 'Programming Languages',
        'topic-cd': 'Compiler Design', 'topic-se': 'Software Engineering', 'topic-ai': 'Artificial Intelligence',
      };
      const topicNames = session.selectedTopics.map((id) => topicMap[id] || id).filter(Boolean);
      const poolSignature = `${session.totalQuestions}|${topicNames.join(',')}|${session.previousQuestionIds.join(',')}`;

      const excludedIds = [...new Set([...session.previousQuestionIds, ...usedIdsRef.current])];

      if (session.currentQuestion === 1 || questionPoolRef.current.length === 0 || poolSignatureRef.current !== poolSignature) {
        const pool = await fetchRankedQuestionPool(topicNames, session.totalQuestions, excludedIds);
        questionPoolRef.current = pool.filter((q) => !excludedIds.includes(q.id)).slice(0, session.totalQuestions);
        usedIdsRef.current = [];
        poolSignatureRef.current = poolSignature;
      }

      const poolQuestion = questionPoolRef.current[session.currentQuestion - 1];
      if (poolQuestion) {
        usedIdsRef.current = [...usedIdsRef.current, poolQuestion.id];
        if (!cancelled) {
          setQuestion(poolQuestion);
          setLoading(false);
        }
        return;
      }

      const loaded = questionPoolRef.current[session.currentQuestion - 1] ?? null;
      if (!loaded) {
        if (!cancelled) {
          setLoading(false);
        }
        return;
      }

      if (!cancelled) {
        usedIdsRef.current = [...usedIdsRef.current, loaded.id];
        setQuestion(loaded);
        setLoading(false);
      }
    };

    load();
    return () => { cancelled = true; };
  }, [session.currentQuestion, session.selectedTopics]);

  const handleOptionSelect = (optionIndex: number) => {
    if (timerStopped || hasSubmitted.current || !question) return;
    setSelectedOption(optionIndex);
    setTimerStopped(true);
    hasSubmitted.current = true;
    const isCorrect = optionIndex === question.correct;
    setTimeout(() => {
      onSubmit(optionIndex, question.correct, isCorrect, question.text, question.options as string[], question.explanation, question.topic, timeUsed);
    }, 600);
  };

  const handleTimeout = useCallback(() => {
    if (hasSubmitted.current || !question) return;
    hasSubmitted.current = true;
    setTimerStopped(true);
    setTimeout(() => {
      onSubmit(null, question.correct, 'timeout', question.text, question.options as string[], question.explanation, question.topic, question.timeLimit);
    }, 400);
  }, [question, onSubmit]);

  const handleTick = useCallback((remaining: number) => {
    if (question) setTimeUsed(question.timeLimit - remaining);
  }, [question]);

  if (loading || !question) {
    return (
      <div className="max-w-3xl mx-auto flex items-center justify-center py-24">
        <Loader2 size={32} className="animate-spin text-primary" />
        <span className="ml-3 text-muted-foreground text-sm">Loading question…</span>
      </div>
    );
  }

  const difficultyVariant = question.difficulty === 'Easy' ? 'success' : question.difficulty === 'Medium' ? 'warning' : 'danger';

  return (
    <div className="max-w-3xl mx-auto fade-in-up">
      {/* Question header */}
      <div className="flex items-start justify-between gap-4 mb-5">
        <div className="flex items-center gap-2 flex-wrap">
          <span className="font-mono-data text-sm font-bold text-muted-foreground">
            Question {session.currentQuestion} of {session.totalQuestions}
          </span>
          <Badge variant={difficultyVariant} size="sm">{question.difficulty}</Badge>
          <div className="flex items-center gap-1 px-2 py-0.5 rounded-full bg-muted border border-border">
            <BookOpen size={10} className="text-muted-foreground" />
            <span className="text-[11px] text-muted-foreground font-medium">{question.topic}</span>
          </div>
          <div className="flex items-center gap-1 px-2 py-0.5 rounded-full bg-accent/10 border border-accent/20">
            <Clock size={10} className="text-accent" />
            <span className="text-[11px] text-accent font-semibold font-mono-data">±{session.lpWager} LP</span>
          </div>
        </div>

        {/* Timer */}
        <QuestionTimer
          key={`timer-q${session.currentQuestion}`}
          totalSeconds={question.timeLimit}
          stopped={timerStopped}
          onTimeout={handleTimeout}
          onTick={handleTick}
        />
      </div>

      {/* Question Card */}
      <div className="card-elevated p-6 mb-5">
        <p className="text-base font-medium text-foreground leading-relaxed">
          {question.text}
        </p>
      </div>

      {/* Options */}
      <div className="flex flex-col gap-3">
        {question.options.map((option, idx) => {
          const optionKeys = ['A', 'B', 'C', 'D'];
          const isSelected = selectedOption === idx;
          const optionClass = !timerStopped
            ? isSelected
              ? 'option-selected' : 'option-idle cursor-pointer'
            : isSelected
            ? 'option-selected' : 'option-idle opacity-60 cursor-not-allowed';

          return (
            <button
              key={`option-${session.currentQuestion}-${idx}`}
              onClick={() => handleOptionSelect(idx)}
              disabled={timerStopped}
              className={`flex items-start gap-4 p-4 rounded-xl text-left transition-all duration-150 w-full ${optionClass}`}
            >
              <span className={`w-7 h-7 rounded-lg flex items-center justify-center text-sm font-bold flex-shrink-0 ${
                isSelected ? 'bg-primary text-white' : 'bg-muted text-muted-foreground'
              }`}>
                {optionKeys[idx]}
              </span>
              <span className="text-sm text-foreground leading-relaxed pt-0.5">{option}</span>
            </button>
          );
        })}
      </div>

      {timerStopped && selectedOption === null && (
        <div className="mt-4 p-3 rounded-lg bg-danger/10 border border-danger/20 text-sm text-danger font-medium text-center">
          ⏱ Time&apos;s up! Moving to feedback…
        </div>
      )}
    </div>
  );
}
