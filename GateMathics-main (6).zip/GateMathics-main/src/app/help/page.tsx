'use client';
import React, { useState } from 'react';
import AppLayout from '@/components/AppLayout';
import {
  HelpCircle,
  BookOpen,
  Trophy,
  BarChart3,
  ChevronDown,
  ChevronUp,
  Search,
  MessageCircle,
  Zap,
  Shield,
  Star,
  Send,
  CheckCircle,
  AlertCircle,
} from 'lucide-react';
import { createClient } from '@/lib/supabase/client';

interface FAQItem {
  question: string;
  answer: string;
  category: string;
}

const faqs: FAQItem[] = [
  {
    category: 'Getting Started',
    question: 'What is GateMathics?',
    answer:
      'GateMathics is a GATE CS brain-training platform that helps aspirants master every syllabus topic through ranked matches, timed practice sessions, and real-time LP rank progression. Think of it as a competitive gaming experience built around GATE preparation.',
  },
  {
    category: 'Getting Started',
    question: 'How do I start practicing?',
    answer:
      'Navigate to Practice Mode from the sidebar. You can configure your session by selecting topics, difficulty, and number of questions. Your performance is tracked and reflected in your Topic Health grid on the dashboard.',
  },
  {
    category: 'Ranked Mode',
    question: 'How does the LP (League Points) system work?',
    answer:
      'LP is earned or lost based on your performance in Ranked matches. Correct answers earn LP; wrong answers deduct LP. Your total LP determines your rank tier: Bronze → Silver → Gold → Platinum → Diamond → Grandmaster.',
  },
  {
    category: 'Ranked Mode',
    question: 'What is the Draft/Ban phase?',
    answer:
      'Before a ranked match begins, you enter a Draft/Ban phase where you can ban topics you want to avoid and draft topics you feel confident about. This adds a strategic layer to your preparation.',
  },
  {
    category: 'Ranked Mode',
    question: 'How is my rank determined?',
    answer:
      'Your rank is determined by your cumulative LP. Each rank tier has an LP threshold. Consistently performing well in ranked matches will promote you to higher tiers, while poor performance may demote you.',
  },
  {
    category: 'Analytics',
    question: 'What does the Analytics screen show?',
    answer:
      'The Analytics screen provides a detailed breakdown of your performance across all GATE CS topics, accuracy trends over time, LP history charts, and topic-wise health scores to help you identify weak areas.',
  },
  {
    category: 'Analytics',
    question: 'What is Topic Health?',
    answer:
      'Topic Health is a score (0–100) that reflects how well you perform on questions from a specific topic. It is calculated from your recent accuracy, speed, and consistency. Green = strong, Yellow = needs work, Red = critical.',
  },
  {
    category: 'Account',
    question: 'How do I update my profile?',
    answer:
      'Go to Profile from the sidebar. You can update your display name, avatar, and view your rank history and achievement badges from there.',
  },
  {
    category: 'Account',
    question: 'Is my progress saved automatically?',
    answer:
      'Yes. All your practice sessions, ranked match results, LP changes, and topic health scores are saved automatically to your account in real time.',
  },
  {
    category: 'Account',
    question: 'How do I maintain my streak?',
    answer:
      'Complete at least one practice session or ranked match every day to maintain your streak. Streaks are tracked from midnight to midnight in your local timezone.',
  },
];

const categories = [
  { label: 'All', icon: HelpCircle },
  { label: 'Getting Started', icon: Zap },
  { label: 'Ranked Mode', icon: Trophy },
  { label: 'Analytics', icon: BarChart3 },
  { label: 'Account', icon: Shield },
];

const quickLinks = [
  { icon: Trophy, title: 'Ranked Mode', desc: 'Compete and earn LP', href: '/ranked-mode-screen' },
  { icon: BookOpen, title: 'Practice Mode', desc: 'Structured topic study', href: '/practice' },
  { icon: BarChart3, title: 'Analytics', desc: 'Track your progress', href: '/analytics' },
  { icon: Star, title: 'Profile', desc: 'View your rank & badges', href: '/profile' },
];

export default function HelpPage() {
  const [openIndex, setOpenIndex] = useState<number | null>(null);
  const [activeCategory, setActiveCategory] = useState('All');
  const [searchQuery, setSearchQuery] = useState('');

  // Support message state
  const [message, setMessage] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [submitStatus, setSubmitStatus] = useState<'idle' | 'success' | 'error'>('idle');
  const [submitError, setSubmitError] = useState('');

  const filtered = faqs.filter((faq) => {
    const matchesCategory = activeCategory === 'All' || faq.category === activeCategory;
    const matchesSearch =
      searchQuery === '' ||
      faq.question.toLowerCase().includes(searchQuery.toLowerCase()) ||
      faq.answer.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  const handleSubmitMessage = async () => {
    if (!message.trim()) return;
    if (message.trim().length < 10) {
      setSubmitError('Please write at least 10 characters.');
      return;
    }
    setSubmitting(true);
    setSubmitError('');
    try {
      const supabase = createClient();
      if (!supabase) throw new Error('Service unavailable');

      // Get current user if logged in
      const { data: { user } } = await supabase.auth.getUser();

      const { error } = await supabase.from('support_messages').insert({
        user_id: user?.id || null,
        email: user?.email || null,
        message: message.trim(),
        status: 'open',
      });

      if (error) throw new Error(error.message);

      setSubmitStatus('success');
      setMessage('');
    } catch (e: any) {
      setSubmitStatus('error');
      setSubmitError(e?.message || 'Failed to send message. Please try again.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <AppLayout>
      <div className="min-h-screen bg-background">
        {/* Header */}
        <div className="bg-card border-b border-border px-6 py-8">
          <div className="max-w-3xl mx-auto text-center">
            <div className="inline-flex items-center justify-center w-14 h-14 rounded-2xl bg-primary/10 mb-4">
              <HelpCircle size={28} className="text-primary" />
            </div>
            <h1 className="text-3xl font-extrabold text-foreground mb-2">Help Center</h1>
            <p className="text-muted-foreground text-base mb-6">
              Find answers to common questions about GateMathics
            </p>
            {/* Search */}
            <div className="relative max-w-xl mx-auto">
              <Search size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-muted-foreground" />
              <input
                type="text"
                placeholder="Search for answers…"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="input-field pl-10 text-sm"
              />
            </div>
          </div>
        </div>

        <div className="max-w-3xl mx-auto px-4 py-8">
          {/* Quick Links */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-8">
            {quickLinks.map((link) => {
              const LinkIcon = link.icon;
              return (
                <a
                  key={link.title}
                  href={link.href}
                  className="card-elevated p-4 flex flex-col items-center gap-2 text-center hover:border-primary/50 transition-all duration-150 group"
                >
                  <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center group-hover:bg-primary/20 transition-colors">
                    <LinkIcon size={18} className="text-primary" />
                  </div>
                  <span className="text-xs font-semibold text-foreground">{link.title}</span>
                  <span className="text-[11px] text-muted-foreground">{link.desc}</span>
                </a>
              );
            })}
          </div>

          {/* Category Filter */}
          <div className="flex flex-wrap gap-2 mb-6">
            {categories.map((cat) => {
              const CatIcon = cat.icon;
              return (
                <button
                  key={cat.label}
                  onClick={() => { setActiveCategory(cat.label); setOpenIndex(null); }}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-semibold border transition-all duration-150 ${
                    activeCategory === cat.label
                      ? 'bg-primary text-white border-primary' :'bg-muted text-muted-foreground border-border hover:border-primary hover:text-foreground'
                  }`}
                >
                  <CatIcon size={12} />
                  {cat.label}
                </button>
              );
            })}
          </div>

          {/* FAQ Accordion */}
          {filtered.length === 0 ? (
            <div className="text-center py-16">
              <HelpCircle size={40} className="text-muted-foreground mx-auto mb-3" />
              <p className="text-foreground font-semibold mb-1">No results found</p>
              <p className="text-muted-foreground text-sm">Try a different search term or category.</p>
            </div>
          ) : (
            <div className="flex flex-col gap-2">
              {filtered.map((faq, idx) => {
                const isOpen = openIndex === idx;
                return (
                  <div
                    key={idx}
                    className={`card-elevated overflow-hidden transition-all duration-200 ${isOpen ? 'border-primary/40' : ''}`}
                  >
                    <button
                      onClick={() => setOpenIndex(isOpen ? null : idx)}
                      className="w-full flex items-center justify-between px-5 py-4 text-left gap-3"
                    >
                      <div className="flex items-start gap-3 flex-1 min-w-0">
                        <span className="inline-block mt-0.5 px-2 py-0.5 rounded-full bg-primary/10 text-primary text-[10px] font-semibold whitespace-nowrap flex-shrink-0">
                          {faq.category}
                        </span>
                        <span className="text-sm font-semibold text-foreground">{faq.question}</span>
                      </div>
                      {isOpen ? (
                        <ChevronUp size={16} className="text-primary flex-shrink-0" />
                      ) : (
                        <ChevronDown size={16} className="text-muted-foreground flex-shrink-0" />
                      )}
                    </button>
                    {isOpen && (
                      <div className="px-5 pb-5">
                        <div className="h-px bg-border mb-4" />
                        <p className="text-sm text-muted-foreground leading-relaxed">{faq.answer}</p>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}

          {/* Still Need Help — Message Box */}
          <div className="mt-10 card-elevated p-6">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-2xl bg-info/10 flex items-center justify-center flex-shrink-0">
                <MessageCircle size={20} className="text-info" />
              </div>
              <div>
                <p className="text-sm font-bold text-foreground">Still need help?</p>
                <p className="text-xs text-muted-foreground">
                  Can't find what you're looking for? Send us a message and we'll get back to you within 24 hours.
                </p>
              </div>
            </div>

            {submitStatus === 'success' ? (
              <div className="flex items-center gap-3 p-4 rounded-xl bg-success/10 border border-success/20">
                <CheckCircle size={18} className="text-success flex-shrink-0" />
                <div>
                  <p className="text-sm font-semibold text-success">Message sent!</p>
                  <p className="text-xs text-muted-foreground">We'll get back to you within 24 hours.</p>
                </div>
                <button
                  onClick={() => setSubmitStatus('idle')}
                  className="ml-auto text-xs text-muted-foreground hover:text-foreground underline"
                >
                  Send another
                </button>
              </div>
            ) : (
              <div className="flex flex-col gap-3">
                <textarea
                  value={message}
                  onChange={(e) => { setMessage(e.target.value); setSubmitError(''); setSubmitStatus('idle'); }}
                  placeholder="Describe your issue or question in detail…"
                  rows={4}
                  maxLength={1000}
                  className="input-field text-sm resize-none leading-relaxed"
                />
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    {submitStatus === 'error' && (
                      <div className="flex items-center gap-1.5 text-danger">
                        <AlertCircle size={13} />
                        <span className="text-xs">{submitError}</span>
                      </div>
                    )}
                    {submitError && submitStatus !== 'error' && (
                      <span className="text-xs text-danger">{submitError}</span>
                    )}
                  </div>
                  <div className="flex items-center gap-3">
                    <span className="text-[11px] text-muted-foreground">{message.length}/1000</span>
                    <button
                      onClick={handleSubmitMessage}
                      disabled={submitting || !message.trim()}
                      className="flex items-center gap-2 px-4 py-2 rounded-xl bg-primary text-white text-sm font-semibold hover:bg-primary/90 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                      <Send size={13} />
                      {submitting ? 'Sending…' : 'Submit'}
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </AppLayout>
  );
}
