import { createClient } from '../../../lib/supabase/server';
import { NextResponse } from 'next/server';
import type { NextRequest } from 'next/server';

export async function GET(request: NextRequest) {
  const { searchParams, origin } = new URL(request.url);
  const code = searchParams.get('code');
  const next = searchParams.get('next') ?? '/';

  // Use the deployed app URL as the base origin for redirects
  const appOrigin = process.env.NEXT_PUBLIC_APP_URL || origin;

  if (code) {
    const supabase = await createClient();
    const { data: exchangeData, error } = await supabase.auth.exchangeCodeForSession(code);

    if (!error && exchangeData?.user) {
      const authUser = exchangeData.user;

      // Ensure profile exists with Silver rank and zeroed stats (idempotent upsert)
      const { data: existing } = await supabase
        .from('user_profiles')
        .select('id')
        .eq('id', authUser.id)
        .single();

      if (!existing) {
        await supabase.from('user_profiles').upsert({
          id: authUser.id,
          email: authUser.email ?? '',
          display_name:
            authUser.user_metadata?.full_name ||
            authUser.user_metadata?.name ||
            (authUser.email ? authUser.email.split('@')[0] : 'User'),
          avatar_url:
            authUser.user_metadata?.avatar_url ||
            authUser.user_metadata?.picture ||
            '',
          auth_method: authUser.app_metadata?.provider === 'google' ? 'google' : 'email_otp',
          rank: 'Silver',
          lp: 0,
          total_questions_answered: 0,
          total_correct: 0,
          total_incorrect: 0,
          total_timeout: 0,
          overall_accuracy: 0,
          avg_answer_speed_seconds: 0,
          daily_streak: 0,
          longest_streak: 0,
          total_sessions: 0,
          total_ranked_sessions: 0,
          total_practice_sessions: 0,
        }, { onConflict: 'id', ignoreDuplicates: true });
      }

      return NextResponse.redirect(`${appOrigin}${next}`);
    }
  }

  return NextResponse.redirect(`${appOrigin}/sign-up-login-screen`);
}
