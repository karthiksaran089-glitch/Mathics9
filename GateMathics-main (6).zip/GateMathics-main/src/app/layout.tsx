import React from 'react';
import type { Metadata, Viewport } from 'next';
import { Manrope, IBM_Plex_Mono } from 'next/font/google';
import AdSenseScript from '@/components/AdSenseScript';
import { AuthProvider } from '@/contexts/AuthContext';
import PageTransitionLoader from '@/components/PageTransitionLoader';
import '../styles/tailwind.css';

const manrope = Manrope({
  subsets: ['latin'],
  weight: ['400', '500', '600', '700', '800'],
  variable: '--font-manrope',
  display: 'swap',
  preload: true,
});

const ibmPlexMono = IBM_Plex_Mono({
  subsets: ['latin'],
  weight: ['400', '500', '600'],
  variable: '--font-ibm-plex-mono',
  display: 'swap',
  preload: false,
});

export const viewport: Viewport = {
  width: 'device-width',
  initialScale: 1,
  themeColor: [
    { media: '(prefers-color-scheme: dark)', color: '#0f1117' },
    { media: '(prefers-color-scheme: light)', color: '#ffffff' },
  ],
};

export const metadata: Metadata = {
  title: {
    default: 'GateMathics — GATE CS Brain Training & Rank Progression',
    template: '%s | GateMathics',
  },
  description:
    'GateMathics helps GATE CS aspirants master every syllabus topic through ranked matches, timed practice, and real-time LP rank progression. Free GATE CS mock tests with instant feedback.',
  keywords: [
    'GATE CS 2025 preparation',
    'GATE computer science practice questions',
    'GATE CS mock test online',
    'GATE CS previous year questions',
    'GATE CS ranked quiz',
    'data structures GATE CS',
    'algorithms GATE CS',
    'operating system GATE CS',
    'DBMS GATE CS questions',
    'computer networks GATE CS',
    'theory of computation GATE CS',
  ],
  metadataBase: new URL('https://mathics24882.builtwithmathics.new'),
  openGraph: {
    siteName: 'GateMathics',
    locale: 'en_IN',
    type: 'website',
  },
  robots: {
    index: true,
    follow: true,
    googleBot: { index: true, follow: true, 'max-snippet': -1 },
  },
  icons: {
    icon: [{ url: '/favicon.ico', type: 'image/x-icon' }],
  },
  verification: {
    // Add your Google Search Console verification token here
    // google: 'YOUR_GSC_VERIFICATION_TOKEN',
  },
};

export default function RootLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en" className={`${manrope.variable} ${ibmPlexMono.variable} dark`}>
      <head>
        <AdSenseScript />
        {/* DNS prefetch for performance */}
        <link rel="dns-prefetch" href="//pagead2.googlesyndication.com" />
        <link rel="dns-prefetch" href="//fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />

      </head>
      <body className={manrope.className}>
        <AuthProvider>
          <PageTransitionLoader />
          {children}
        </AuthProvider>
      </body>
    </html>
  );
}