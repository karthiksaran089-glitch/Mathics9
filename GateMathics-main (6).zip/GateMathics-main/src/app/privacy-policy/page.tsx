import React from 'react';
import type { Metadata } from 'next';
import AppLayout from '@/components/AppLayout';
import { PAGE_SEO } from '@/lib/seo/gateSeoConfig';
import PrivacyContent from './PrivacyContent';

export const metadata: Metadata = PAGE_SEO.privacy;

export default function PrivacyPolicyPage() {
  return (
    <AppLayout>
      <PrivacyContent />
    </AppLayout>
  );
}
