'use client';

import React from 'react';
import AdUnit from '@/components/adsense/AdUnit';
import { adsenseConfig } from '@/config/adsense.config';

const LAST_UPDATED = 'June 2, 2025';

const sections = [
  {
    id: 'information-collected',
    title: '1. Information We Collect',
    content: `We collect information you provide directly when you create an account, including your name, email address, and profile preferences. We also collect usage data automatically, such as quiz performance, session history, topic accuracy, and rank progression. This data is used solely to provide and improve the GateMathics service.`,
  },
  {
    id: 'how-we-use',
    title: '2. How We Use Your Information',
    content: `We use your information to: (a) provide and personalize the GateMathics experience; (b) track your GATE CS preparation progress and rank; (c) send service-related communications; (d) improve our question bank and AI engine; and (e) display relevant advertisements through Google AdSense. We do not sell your personal information to third parties.`,
  },
  {
    id: 'google-adsense',
    title: '3. Google AdSense & Advertising',
    content: `GateMathics uses Google AdSense to display advertisements. Google AdSense uses cookies and similar technologies to serve ads based on your prior visits to this website and other websites. Google's use of advertising cookies enables it and its partners to serve ads based on your visit to our site and/or other sites on the Internet. You may opt out of personalized advertising by visiting Google's Ads Settings at https://www.google.com/settings/ads. For more information about how Google uses data, please visit https://policies.google.com/technologies/partner-sites.`,
  },
  {
    id: 'cookies',
    title: '4. Cookies',
    content: `We use cookies and similar tracking technologies to track activity on our service and hold certain information. Cookies are files with a small amount of data which may include an anonymous unique identifier. You can instruct your browser to refuse all cookies or to indicate when a cookie is being sent. However, if you do not accept cookies, some portions of our service may not function properly. We use: (a) Session cookies to operate our service; (b) Preference cookies to remember your settings; (c) Analytics cookies to understand how you use GateMathics; and (d) Advertising cookies served by Google AdSense.`,
  },
  {
    id: 'data-retention',
    title: '5. Data Retention',
    content: `We retain your personal data for as long as your account is active or as needed to provide you services. You may request deletion of your account and associated data at any time by contacting us at support@gatemathics.com. We will respond to deletion requests within 30 days.`,
  },
  {
    id: 'third-party',
    title: '6. Third-Party Services',
    content: `GateMathics uses the following third-party services: (a) Supabase — for authentication and database storage; (b) Google AdSense — for advertising; (c) AI providers — for question generation. Each third-party service has its own Privacy Policy governing the use of your information. We encourage you to review their policies.`,
  },
  {
    id: 'childrens-privacy',
    title: '7. Children\'s Privacy',
    content: `GateMathics is not directed to children under the age of 13. We do not knowingly collect personally identifiable information from children under 13. If you are a parent or guardian and you are aware that your child has provided us with personal data, please contact us so that we can take necessary action.`,
  },
  {
    id: 'your-rights',
    title: '8. Your Rights',
    content: `You have the right to: (a) access the personal data we hold about you; (b) request correction of inaccurate data; (c) request deletion of your data; (d) object to processing of your data; (e) request restriction of processing; and (f) data portability. To exercise any of these rights, contact us at support@gatemathics.com.`,
  },
  {
    id: 'changes',
    title: '9. Changes to This Policy',
    content: `We may update our Privacy Policy from time to time. We will notify you of any changes by posting the new Privacy Policy on this page and updating the "Last Updated" date. You are advised to review this Privacy Policy periodically for any changes.`,
  },
  {
    id: 'contact',
    title: '10. Contact Us',
    content: `If you have any questions about this Privacy Policy, please contact us at: support@gatemathics.com or through our Contact page at https://mathics24882.builtwithmathics.new/contact.`,
  },
];

export default function PrivacyContent() {
  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Header */}
      <div className="border-b border-border px-6 py-8 md:px-10">
        <h1 className="text-3xl md:text-4xl font-extrabold tracking-tight text-foreground">
          Privacy <span className="text-gradient-primary">Policy</span>
        </h1>
        <p className="mt-2 text-sm text-muted-foreground">
          Last updated: {LAST_UPDATED}
        </p>
      </div>
      <div className="px-6 py-8 md:px-10 max-w-3xl mx-auto">

        {/* Intro */}
        <p className="text-muted-foreground leading-relaxed mb-8">
          GateMathics ("we", "our", or "us") is committed to protecting your privacy. This Privacy Policy explains
          how we collect, use, disclose, and safeguard your information when you use our GATE CS preparation platform
          at{' '}
          <a href="https://mathics24882.builtwithrocket.new" className="text-primary hover:underline">
            mathics24882.builtwithrocket.new
          </a>
          . Please read this policy carefully.
        </p>

        {/* Ad — top */}
        <AdUnit
          adClient={adsenseConfig?.client}
          adSlot={adsenseConfig?.slots?.leaderboard}
          adFormat="auto"
          className="mb-8"
        />

        {/* Sections */}
        <div className="space-y-8">
          {sections?.map((section, idx) => (
            <React.Fragment key={section?.id}>
              <section id={section?.id}>
                <h2 className="text-lg font-bold text-foreground mb-2">{section?.title}</h2>
                <p className="text-muted-foreground leading-relaxed text-sm">{section?.content}</p>
              </section>
              {/* Insert ad after section 4 */}
              {idx === 3 && (
                <AdUnit
                  adClient={adsenseConfig?.client}
                  adSlot={adsenseConfig?.slots?.inArticle}
                  adFormat="auto"
                  className="my-4"
                />
              )}
            </React.Fragment>
          ))}
        </div>

        {/* Ad — footer */}
        <AdUnit
          adClient={adsenseConfig?.client}
          adSlot={adsenseConfig?.slots?.footer}
          adFormat="auto"
          className="mt-10 mb-4"
        />
      </div>
    </div>
  );
}
