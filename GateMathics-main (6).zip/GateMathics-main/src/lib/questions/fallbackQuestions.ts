/**
 * Fallback Question Service
 *
 * Queries the ranked_questions and practice_questions Supabase tables
 * when the AI question generation engine fails, times out, or is unavailable.
 *
 * Usage:
 *   const q = await fetchRankedFallbackQuestion(topics, difficulty, usedIds);
 *   const q = await fetchPracticeFallbackQuestion(topics, difficulty, usedIds);
 */

import { createClient } from '@/lib/supabase/client';

export interface FallbackQuestion {
  id: string;
  topic: string;
  difficulty: 'Easy' | 'Medium' | 'Hard';
  timeLimit: number;
  text: string;
  options: [string, string, string, string];
  correct: number;          // 0-indexed
  explanation: string;
  hint?: string;            // practice mode only
}

type RawRow = {
  id: string;
  topic: string;
  difficulty: string;
  time_limit: number;
  question: string;
  option_a: string;
  option_b: string;
  option_c: string;
  option_d: string;
  correct_index: number;
  explanation: string;
  hint?: string;
};

function rowToQuestion(row: RawRow): FallbackQuestion {
  return {
    id: row.id,
    topic: row.topic,
    difficulty: row.difficulty as 'Easy' | 'Medium' | 'Hard',
    timeLimit: row.time_limit,
    text: row.question,
    options: [row.option_a, row.option_b, row.option_c, row.option_d],
    correct: row.correct_index,
    explanation: row.explanation,
    hint: row.hint ?? '',
  };
}

/**
 * Fetch a single fallback question for Ranked Mode.
 * Filters by topics (if provided) and excludes already-used question IDs.
 * Falls back to any active question if no match found for the given topics.
 */
export async function fetchRankedFallbackQuestion(
  topics: string[] = [],
  usedIds: string[] = []
): Promise<FallbackQuestion | null> {
  try {
    const supabase = createClient();
    if (!supabase) return null;

    let query = supabase
      .from('ranked_questions')
      .select('id, topic, difficulty, time_limit, question, option_a, option_b, option_c, option_d, correct_index, explanation')
      .eq('is_active', true);

    if (topics.length > 0) {
      query = query.in('topic', topics);
    }
    
    // Only filter out UUID-format IDs — local bank IDs like "local-p-004" are not valid UUIDs
    // and would cause "invalid input syntax for type uuid" errors
    const uniqueUsedIds = [...new Set(usedIds)].filter((id) =>
      /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(id)
    );

    if (uniqueUsedIds.length > 0) {
      query = query.not('id', 'in', `(${uniqueUsedIds.map((id) => `"${id}"`).join(',')})`);
    }

    const randomSeed = Math.floor(Math.random() * 1_000_000_000);
    query = query.order(`md5(id || '${randomSeed}')`, { ascending: true });

    const { data, error } = await query;

    if (error || !data || data.length === 0) {
      // Return null if no questions match the specific topics, do not drop the topic filter
      return null;
    }

    const row = data[0] as RawRow;
    return rowToQuestion(row);
  } catch {
    return null;
  }
}

export async function fetchRankedQuestionPool(
  topics: string[] = [],
  count = 10,
  excludedIds: string[] = []
): Promise<FallbackQuestion[]> {
  try {
    const supabase = createClient();
    if (!supabase) return [];

    let query = supabase
      .from('ranked_questions')
      .select('id, topic, difficulty, time_limit, question, option_a, option_b, option_c, option_d, correct_index, explanation')
      .eq('is_active', true);

    if (topics.length > 0) {
      query = query.in('topic', topics);
    }

    const uniqueExcludedIds = [...new Set(excludedIds)].filter((id) =>
      /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(id)
    );

    if (uniqueExcludedIds.length > 0) {
      query = query.not('id', 'in', `(${uniqueExcludedIds.map((id) => `"${id}"`).join(',')})`);
    }

    const { data, error } = await query;
    if (error || !data || data.length === 0) return [];

    const shuffled = [...data].sort(() => Math.random() - 0.5);
    return shuffled.slice(0, count).map((row) => rowToQuestion(row as RawRow));
  } catch {
    return [];
  }
}

/**
 * Fetch a single fallback question for Practice Mode.
 * Filters by topics and difficulty (if provided) and excludes already-used question IDs.
 * Falls back progressively: topic+difficulty → topic only → any active question.
 */
export async function fetchPracticeFallbackQuestion(
  topics: string[] = [],
  difficulty: 'Easy' | 'Medium' | 'Hard' | 'Mixed' = 'Mixed',
  usedIds: string[] = []
): Promise<FallbackQuestion | null> {
  try {
    const supabase = createClient();
    if (!supabase) return null;

    let query = supabase
      .from('practice_questions')
      .select('id, topic, difficulty, time_limit, question, option_a, option_b, option_c, option_d, correct_index, explanation, hint')
      .eq('is_active', true)
      .order('id');

    if (topics.length > 0) {
      query = query.in('topic', topics);
    }
    if (difficulty !== 'Mixed') {
      query = query.eq('difficulty', difficulty);
    }
    
    // Only filter out UUID-format IDs — local bank IDs like "local-p-004" are not valid UUIDs
    // and would cause "invalid input syntax for type uuid" errors
    if (usedIds && usedIds.length > 0) {
      for (const id of usedIds) {
        // Skip non-UUID IDs (local bank fallback IDs like "local-p-012")
        if (/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(id)) {
          query = query.neq('id', id);
        }
      }
    }

    const { data, error } = await query;

    if (error || !data || data.length === 0) {
      if (error) {
        console.error('fetchPracticeFallbackQuestion error:', JSON.stringify(error));
        console.error('fetchPracticeFallbackQuestion - table: practice_questions, topics:', JSON.stringify(topics), 'difficulty:', difficulty);
        // If query fails entirely (table doesn't exist, RLS, etc.), bail out immediately
        // Don't attempt progressive fallback since the whole query is broken
        return null;
      }
      // No data returned — progressive fallback: drop difficulty filter first, but NEVER drop the topic filter
      if (data && data.length === 0 && difficulty !== 'Mixed') {
        return fetchPracticeFallbackQuestion(topics, 'Mixed', usedIds);
      }
      return null;
    }

    const row = data[Math.floor(Math.random() * data.length)] as RawRow;
    return rowToQuestion(row);
  } catch (err) {
    console.error('fetchPracticeFallbackQuestion exception:', err);
    return null;
  }
}

/**
 * Fetch multiple fallback questions for Practice Mode (batch).
 * Returns up to `count` unique questions.
 */
export async function fetchPracticeFallbackBatch(
  count: number,
  topics: string[] = [],
  difficulty: 'Easy' | 'Medium' | 'Hard' | 'Mixed' = 'Mixed'
): Promise<FallbackQuestion[]> {
  try {
    const supabase = createClient();
    if (!supabase) return [];

    let query = supabase
      .from('practice_questions')
      .select('id, topic, difficulty, time_limit, question, option_a, option_b, option_c, option_d, correct_index, explanation, hint')
      .eq('is_active', true)
      .order('id')
      .limit(count * 3); // fetch extra to allow random selection

    if (topics.length > 0) {
      query = query.in('topic', topics);
    }
    if (difficulty !== 'Mixed') {
      query = query.eq('difficulty', difficulty);
    }

    const { data, error } = await query;

    if (error || !data || data.length === 0) {
      if (error) console.error('fetchPracticeFallbackBatch error:', error);
      if (difficulty !== 'Mixed') {
        return fetchPracticeFallbackBatch(count, topics, 'Mixed');
      }
      return [];
    }

    // Shuffle and take `count`
    const shuffled = [...data].sort(() => Math.random() - 0.5);
    const result = shuffled.slice(0, count).map((row) => rowToQuestion(row as RawRow));

    // DIAGNOSTIC: Log what we got from Supabase
    if (topics.length > 0) {
      const topicMatchCount = result.filter((q) => topics.includes(q.topic)).length;
      const mismatchedTopics = [...new Set(result.filter((q) => !topics.includes(q.topic)).map((q) => q.topic))];
      if (topicMatchCount < result.length) {
        console.warn(`[PracticeDB] TOPIC MISMATCH: Requested [${topics.join(', ')}], got ${topicMatchCount}/${result.length} matching. Mismatched topics: [${mismatchedTopics.join(', ')}]`);
      } else {
        console.log(`[PracticeDB] OK: ${result.length} questions fetched for topics [${topics.join(', ')}], difficulty: ${difficulty}`);
      }
    } else {
      console.log(`[PracticeDB] OK: ${result.length} questions fetched (all topics), difficulty: ${difficulty}`);
    }

    return result;
  } catch (err) {
    console.error('fetchPracticeFallbackBatch exception:', err);
    return [];
  }
}
