/**
 * GateMathics Gamification Engine
 *
 * XP-based level system (1–50) + 12 achievement badges.
 * All computations are client-side from existing user_profiles stats.
 */

// ─── Types ────────────────────────────────────────────────────────────────────

export interface UserProfileStats {
  total_questions_answered: number;
  total_correct: number;
  total_incorrect: number;
  total_timeout: number;
  total_sessions: number;
  total_ranked_sessions: number;
  total_practice_sessions: number;
  overall_accuracy: number;
  avg_answer_speed_seconds: number;
  daily_streak: number;
  longest_streak: number;
  lp: number;
  rank: string;
}

export interface LevelInfo {
  level: number;
  tier: TierInfo;
  totalXP: number;
  xpInLevel: number;
  xpToNext: number;
  progressPct: number;
}

export interface TierInfo {
  name: string;
  color: string;
  gradient: string;
  emoji: string;
  minLevel: number;
  maxLevel: number;
}

export interface BadgeDefinition {
  id: string;
  name: string;
  emoji: string;
  description: string;
  requirement: string;
  color: string;
  glowColor: string;
}

// ─── Tiers ────────────────────────────────────────────────────────────────────

const TIERS: TierInfo[] = [
  { name: 'Novice',  color: '#A8B8C8', gradient: 'linear-gradient(135deg, #C0C8D8 0%, #8898AA 100%)', emoji: '🔰', minLevel: 1,  maxLevel: 10 },
  { name: 'Scholar', color: '#10B981', gradient: 'linear-gradient(135deg, #6EE7B7 0%, #10B981 100%)', emoji: '📖', minLevel: 11, maxLevel: 20 },
  { name: 'Expert',  color: '#7C3AED', gradient: 'linear-gradient(135deg, #A78BFA 0%, #7C3AED 100%)', emoji: '⚡', minLevel: 21, maxLevel: 30 },
  { name: 'Master',  color: '#F59E0B', gradient: 'linear-gradient(135deg, #FCD34D 0%, #F59E0B 100%)', emoji: '👑', minLevel: 31, maxLevel: 40 },
  { name: 'Legend',  color: '#EC4899', gradient: 'linear-gradient(135deg, #F9A8D4 0%, #EC4899 100%)', emoji: '🌟', minLevel: 41, maxLevel: 50 },
];

export function getTier(level: number): TierInfo {
  for (const tier of TIERS) {
    if (level >= tier.minLevel && level <= tier.maxLevel) return tier;
  }
  return TIERS[TIERS.length - 1];
}

export function getAllTiers(): TierInfo[] {
  return TIERS;
}

// ─── XP & Levels ──────────────────────────────────────────────────────────────

/**
 * Compute total XP from profile stats.
 * Formula: (correct × 10) + (sessions × 25) + (streak × 15)
 */
export function computeTotalXP(stats: UserProfileStats): number {
  return (
    (stats.total_correct ?? 0) * 10 +
    (stats.total_sessions ?? 0) * 25 +
    (stats.longest_streak ?? 0) * 15
  );
}

/**
 * XP required to reach a given level.
 * Uses a smooth curve: level 1 = 0, level 2 = 100, scaling quadratically.
 * cumulative XP for level L = 50 × L × (L - 1)
 */
export function getCumulativeXPForLevel(level: number): number {
  if (level <= 1) return 0;
  return 50 * level * (level - 1);
}

/**
 * XP required to go from level L to level L+1.
 */
export function getXPForLevel(level: number): number {
  return getCumulativeXPForLevel(level + 1) - getCumulativeXPForLevel(level);
}

/**
 * Determine current level from total XP.
 */
export function getLevelFromXP(totalXP: number): number {
  let level = 1;
  while (level < 50 && getCumulativeXPForLevel(level + 1) <= totalXP) {
    level++;
  }
  return level;
}

/**
 * Full level info breakdown from profile stats.
 */
export function getLevelInfo(stats: UserProfileStats): LevelInfo {
  const totalXP = computeTotalXP(stats);
  const level = getLevelFromXP(totalXP);
  const tier = getTier(level);
  const currentLevelXP = getCumulativeXPForLevel(level);
  const nextLevelXP = getCumulativeXPForLevel(Math.min(level + 1, 50));
  const xpInLevel = totalXP - currentLevelXP;
  const xpToNext = nextLevelXP - currentLevelXP;
  const progressPct = xpToNext > 0 ? Math.min(Math.round((xpInLevel / xpToNext) * 100), 100) : 100;

  return { level, tier, totalXP, xpInLevel, xpToNext, progressPct };
}

// ─── Badges ───────────────────────────────────────────────────────────────────

const BADGE_DEFINITIONS: BadgeDefinition[] = [
  {
    id: 'initiate',
    name: 'Initiate',
    emoji: '🔰',
    description: 'Complete your first practice session',
    requirement: '1+ practice session',
    color: '#10B981',
    glowColor: 'rgba(16,185,129,0.4)',
  },
  {
    id: 'first-blood',
    name: 'First Blood',
    emoji: '🏆',
    description: 'Complete your first ranked session',
    requirement: '1+ ranked session',
    color: '#7C3AED',
    glowColor: 'rgba(124,58,237,0.4)',
  },
  {
    id: 'sharpshooter',
    name: 'Sharpshooter',
    emoji: '🎯',
    description: 'Achieve 80%+ overall accuracy',
    requirement: '80%+ accuracy (50+ Qs)',
    color: '#EF4444',
    glowColor: 'rgba(239,68,68,0.4)',
  },
  {
    id: 'streak-lord',
    name: 'Streak Lord',
    emoji: '🔥',
    description: 'Maintain a 7-day practice streak',
    requirement: '7+ day streak',
    color: '#F59E0B',
    glowColor: 'rgba(245,158,11,0.4)',
  },
  {
    id: 'speed-demon',
    name: 'Speed Demon',
    emoji: '⚡',
    description: 'Average answer speed under 20 seconds',
    requirement: '<20s avg speed (30+ Qs)',
    color: '#06B6D4',
    glowColor: 'rgba(6,182,212,0.4)',
  },
  {
    id: 'completionist',
    name: 'Completionist',
    emoji: '📚',
    description: 'Answer 500 or more questions',
    requirement: '500+ questions answered',
    color: '#8B5CF6',
    glowColor: 'rgba(139,92,246,0.4)',
  },
  {
    id: 'grinder',
    name: 'Grinder',
    emoji: '💪',
    description: 'Complete 50 or more sessions',
    requirement: '50+ sessions',
    color: '#D97706',
    glowColor: 'rgba(217,119,6,0.4)',
  },
  {
    id: 'rising-star',
    name: 'Rising Star',
    emoji: '🌟',
    description: 'Reach Gold rank',
    requirement: 'Gold rank',
    color: '#F59E0B',
    glowColor: 'rgba(245,158,11,0.4)',
  },
  {
    id: 'diamond-hands',
    name: 'Diamond Hands',
    emoji: '💎',
    description: 'Reach Diamond rank',
    requirement: 'Diamond rank',
    color: '#818CF8',
    glowColor: 'rgba(129,140,248,0.4)',
  },
  {
    id: 'grandmaster',
    name: 'Grandmaster',
    emoji: '👑',
    description: 'Reach Grandmaster rank',
    requirement: 'Grandmaster rank',
    color: '#EC4899',
    glowColor: 'rgba(236,72,153,0.4)',
  },
  {
    id: 'scholar',
    name: 'Scholar',
    emoji: '🎓',
    description: 'Reach level 20',
    requirement: 'Level 20+',
    color: '#10B981',
    glowColor: 'rgba(16,185,129,0.4)',
  },
  {
    id: 'topic-master',
    name: 'Topic Master',
    emoji: '🧠',
    description: 'Achieve 90%+ in any single topic',
    requirement: '90%+ topic accuracy (10+ Qs)',
    color: '#7C3AED',
    glowColor: 'rgba(124,58,237,0.4)',
  },
];

export function getAllBadges(): BadgeDefinition[] {
  return BADGE_DEFINITIONS;
}

const RANK_TIERS_FOR_CHECK = ['Bronze', 'Silver', 'Gold', 'Platinum', 'Diamond', 'Master', 'Grandmaster'];

function rankAtLeast(current: string, target: string): boolean {
  const ci = RANK_TIERS_FOR_CHECK.indexOf(current);
  const ti = RANK_TIERS_FOR_CHECK.indexOf(target);
  if (ci === -1 || ti === -1) return false;
  return ci >= ti;
}

/**
 * Returns badge IDs that the user has unlocked based on their profile stats.
 */
export function getUnlockedBadgeIds(stats: UserProfileStats): string[] {
  const unlocked: string[] = [];

  if ((stats.total_practice_sessions ?? 0) >= 1) unlocked.push('initiate');
  if ((stats.total_ranked_sessions ?? 0) >= 1) unlocked.push('first-blood');
  if ((stats.overall_accuracy ?? 0) >= 80 && (stats.total_questions_answered ?? 0) >= 50) unlocked.push('sharpshooter');
  if ((stats.longest_streak ?? 0) >= 7) unlocked.push('streak-lord');
  if ((stats.avg_answer_speed_seconds ?? 999) < 20 && (stats.total_questions_answered ?? 0) >= 30) unlocked.push('speed-demon');
  if ((stats.total_questions_answered ?? 0) >= 500) unlocked.push('completionist');
  if ((stats.total_sessions ?? 0) >= 50) unlocked.push('grinder');
  if (rankAtLeast(stats.rank, 'Gold')) unlocked.push('rising-star');
  if (rankAtLeast(stats.rank, 'Diamond')) unlocked.push('diamond-hands');
  if (rankAtLeast(stats.rank, 'Grandmaster')) unlocked.push('grandmaster');

  const levelInfo = getLevelInfo(stats);
  if (levelInfo.level >= 20) unlocked.push('scholar');

  // topic-master is checked externally (requires per-topic data not in profile)
  // Caller can add it manually if available

  return unlocked;
}

/**
 * Get full badge objects with unlocked state.
 */
export function getBadgesWithState(stats: UserProfileStats): (BadgeDefinition & { unlocked: boolean })[] {
  const unlockedIds = getUnlockedBadgeIds(stats);
  return BADGE_DEFINITIONS.map((badge) => ({
    ...badge,
    unlocked: unlockedIds.includes(badge.id),
  }));
}
