import type { Metadata } from 'next';

const BASE_URL = 'https://mathics24882.builtwithmathics.new';
const SITE_NAME = 'GateMathics';
const DEFAULT_OG_IMAGE = `${BASE_URL}/assets/images/app_logo.png`;

// High-paying, low-competition GATE CS keyword clusters
export const GATE_KEYWORD_CLUSTERS = {
  core: [
    'GATE CS 2025 preparation',
    'GATE computer science practice questions',
    'GATE CS mock test online',
    'GATE CS previous year questions',
    'GATE CS syllabus topics',
  ],
  algorithms: [
    'GATE CS algorithms questions',
    'dynamic programming GATE problems',
    'graph algorithms GATE CS',
    'sorting algorithms GATE questions',
    'time complexity GATE CS',
  ],
  dataStructures: [
    'data structures GATE CS',
    'binary tree GATE questions',
    'hashing GATE CS problems',
    'linked list GATE CS',
    'stack queue GATE problems',
  ],
  theory: [
    'theory of computation GATE CS',
    'automata GATE questions',
    'context free grammar GATE',
    'Turing machine GATE CS',
    'regular expression GATE problems',
  ],
  os: [
    'operating system GATE CS',
    'process scheduling GATE questions',
    'memory management GATE CS',
    'deadlock GATE problems',
    'page replacement GATE CS',
  ],
  dbms: [
    'DBMS GATE CS questions',
    'SQL queries GATE problems',
    'normalization GATE CS',
    'relational algebra GATE',
    'transaction management GATE CS',
  ],
  networks: [
    'computer networks GATE CS',
    'TCP IP GATE questions',
    'OSI model GATE CS',
    'routing algorithms GATE',
    'network security GATE CS',
  ],
  ranked: [
    'GATE CS ranked quiz',
    'competitive GATE CS practice',
    'GATE CS rank improvement',
    'GATE CS leaderboard practice',
    'GATE CS LP ranking system',
  ],
};

function buildKeywords(clusters: (keyof typeof GATE_KEYWORD_CLUSTERS)[]): string {
  return clusters
    .flatMap((c) => GATE_KEYWORD_CLUSTERS[c])
    .join(', ');
}

export function buildMetadata(options: {
  title: string;
  description: string;
  path: string;
  keywordClusters?: (keyof typeof GATE_KEYWORD_CLUSTERS)[];
  ogImage?: string;
}): Metadata {
  const {
    title,
    description,
    path,
    keywordClusters = ['core'],
    ogImage = DEFAULT_OG_IMAGE,
  } = options;

  const fullTitle = `${title} | ${SITE_NAME}`;
  const canonical = `${BASE_URL}${path}`;
  const keywords = buildKeywords(keywordClusters);

  return {
    title: fullTitle,
    description,
    keywords,
    metadataBase: new URL(BASE_URL),
    alternates: { canonical },
    openGraph: {
      title: fullTitle,
      description,
      url: canonical,
      siteName: SITE_NAME,
      images: [{ url: ogImage, width: 1200, height: 630, alt: fullTitle }],
      type: 'website',
      locale: 'en_IN',
    },
    twitter: {
      card: 'summary_large_image',
      title: fullTitle,
      description,
      images: [ogImage],
    },
    robots: {
      index: true,
      follow: true,
      googleBot: { index: true, follow: true, 'max-snippet': -1 },
    },
  };
}

// Per-page metadata presets
export const PAGE_SEO = {
  home: buildMetadata({
    title: 'GATE CS Brain Training & Rank Progression',
    description:
      'Master every GATE CS topic through ranked matches, timed practice, and real-time LP rank progression. Free GATE CS mock tests with instant feedback.',
    path: '/',
    keywordClusters: ['core', 'ranked'],
  }),
  ranked: buildMetadata({
    title: 'Ranked Mode — Competitive GATE CS Quiz',
    description:
      'Challenge yourself in ranked GATE CS quizzes. Earn LP, climb the leaderboard, and track your rank across all GATE CS topics.',
    path: '/ranked-mode-screen',
    keywordClusters: ['core', 'ranked', 'algorithms'],
  }),
  practice: buildMetadata({
    title: 'Practice Mode — GATE CS Topic-Wise Questions',
    description:
      'Practice GATE CS questions topic-by-topic with hints, explanations, and performance tracking. Covers algorithms, OS, DBMS, networks, and more.',
    path: '/practice',
    keywordClusters: ['core', 'algorithms', 'dataStructures', 'theory', 'os', 'dbms', 'networks'],
  }),
  analytics: buildMetadata({
    title: 'Analytics — Track Your GATE CS Progress',
    description:
      'Visualize your GATE CS preparation progress. Identify weak topics, track accuracy trends, and optimize your study plan.',
    path: '/analytics',
    keywordClusters: ['core'],
  }),
  about: buildMetadata({
    title: 'About GateMathics — GATE CS Preparation Platform',
    description:
      'GateMathics is a free GATE CS preparation platform with ranked quizzes, practice sessions, and AI-powered question generation to help you crack GATE.',
    path: '/about',
    keywordClusters: ['core', 'ranked'],
  }),
  contact: buildMetadata({
    title: 'Contact Us — GateMathics Support',
    description:
      'Get in touch with the GateMathics team for support, feedback, or partnership inquiries. We are here to help GATE CS aspirants succeed.',
    path: '/contact',
    keywordClusters: ['core'],
  }),
  privacy: buildMetadata({
    title: 'Privacy Policy — GateMathics',
    description:
      'Read the GateMathics Privacy Policy to understand how we collect, use, and protect your data on our GATE CS preparation platform.',
    path: '/privacy-policy',
    keywordClusters: ['core'],
  }),
};
