/**
 * Unit Tests — AuthContext.tsx
 * Tests public auth functions: signInWithGoogle, sendEmailOTP, verifyEmailOTP, signInAsGuest, signOut
 */

/// <reference types="@testing-library/jest-dom" />
import '@testing-library/jest-dom';
import React, { useEffect } from 'react';
import { render, act, waitFor } from '@testing-library/react';
import { AuthProvider, useAuth } from '@/contexts/AuthContext';

// ── Mock Supabase ─────────────────────────────────────────────────────────────
const mockSignInWithOAuth = jest.fn();
const mockSignInWithOtp = jest.fn();
const mockVerifyOtp = jest.fn();
const mockSignOut = jest.fn();
const mockGetSession = jest.fn();
const mockGetUser = jest.fn();
const mockOnAuthStateChange = jest.fn();
const mockFrom = jest.fn();

const mockSupabase = {
  auth: {
    signInWithOAuth: mockSignInWithOAuth,
    signInWithOtp: mockSignInWithOtp,
    verifyOtp: mockVerifyOtp,
    signOut: mockSignOut,
    getSession: mockGetSession,
    getUser: mockGetUser,
    onAuthStateChange: mockOnAuthStateChange,
  },
  from: mockFrom,
};

jest.mock('@/lib/supabase/client', () => ({
  createClient: () => mockSupabase,
}));

// ── Helpers ───────────────────────────────────────────────────────────────────
function TestConsumer({ onMount }: { onMount: (auth: ReturnType<typeof useAuth>) => void }) {
  const auth = useAuth();
  React.useEffect(() => { onMount(auth); }, []);
  return null;
}

function renderWithAuth(onMount: (auth: ReturnType<typeof useAuth>) => void) {
  return render(
    <AuthProvider>
      <TestConsumer onMount={onMount} />
    </AuthProvider>
  );
}

// ── Setup ─────────────────────────────────────────────────────────────────────
beforeEach(() => {
  jest.clearAllMocks();
  if (typeof window !== 'undefined') {
    localStorage.clear();
  }

  mockGetSession.mockResolvedValue({ data: { session: null } });
  mockOnAuthStateChange.mockReturnValue({ data: { subscription: { unsubscribe: jest.fn() } } });

  const mockInsert = jest.fn().mockResolvedValue({ error: null });
  const mockSelect = jest.fn().mockReturnValue({
    eq: jest.fn().mockReturnValue({
      single: jest.fn().mockResolvedValue({ data: null, error: null }),
    }),
  });
  mockFrom.mockReturnValue({ insert: mockInsert, select: mockSelect, upsert: jest.fn().mockResolvedValue({ error: null }) });
});

// ── signInWithGoogle ──────────────────────────────────────────────────────────
describe('signInWithGoogle', () => {
  it('calls supabase signInWithOAuth with google provider', async () => {
    mockSignInWithOAuth.mockResolvedValue({ data: { url: 'https://accounts.google.com' }, error: null });

    let authCtx: any;
    renderWithAuth((auth) => { authCtx = auth; });

    await act(async () => {
      await authCtx.signInWithGoogle();
    });

    expect(mockSignInWithOAuth).toHaveBeenCalledWith(
      expect.objectContaining({ provider: 'google' })
    );
  });

  it('throws when supabase returns error', async () => {
    mockSignInWithOAuth.mockResolvedValue({ data: null, error: { message: 'OAuth failed' } });

    let authCtx: any;
    renderWithAuth((auth) => { authCtx = auth; });

    await expect(act(async () => {
      await authCtx.signInWithGoogle();
    })).rejects.toBeTruthy();
  });

  it('uses NEXT_PUBLIC_APP_URL for redirect when set', async () => {
    process.env.NEXT_PUBLIC_APP_URL = 'https://mathics35409.builtwithmatics.new';
    mockSignInWithOAuth.mockResolvedValue({ data: {}, error: null });

    let authCtx: any;
    renderWithAuth((auth) => { authCtx = auth; });

    await act(async () => { await authCtx.signInWithGoogle(); });

    expect(mockSignInWithOAuth).toHaveBeenCalledWith(
      expect.objectContaining({
        options: expect.objectContaining({
          redirectTo: expect.stringContaining('mathics35409.builtwithmathics.new'),
        }),
      })
    );
    delete process.env.NEXT_PUBLIC_APP_URL;
  });
});

// ── sendEmailOTP ──────────────────────────────────────────────────────────────
describe('sendEmailOTP', () => {
  it('calls signInWithOtp with correct email', async () => {
    mockSignInWithOtp.mockResolvedValue({ data: {}, error: null });

    let authCtx: any;
    renderWithAuth((auth) => { authCtx = auth; });

    await act(async () => {
      await authCtx.sendEmailOTP('test@example.com');
    });

    expect(mockSignInWithOtp).toHaveBeenCalledWith(
      expect.objectContaining({ email: 'test@example.com' })
    );
  });

  it('throws on error', async () => {
    mockSignInWithOtp.mockResolvedValue({ data: null, error: { message: 'OTP failed' } });

    let authCtx: any;
    renderWithAuth((auth) => { authCtx = auth; });

    await expect(act(async () => {
      await authCtx.sendEmailOTP('bad@example.com');
    })).rejects.toBeTruthy();
  });
});

// ── verifyEmailOTP ────────────────────────────────────────────────────────────
describe('verifyEmailOTP', () => {
  it('calls verifyOtp with email and token', async () => {
    mockVerifyOtp.mockResolvedValue({ data: { user: { id: '123' } }, error: null });

    let authCtx: any;
    renderWithAuth((auth) => { authCtx = auth; });

    await act(async () => {
      await authCtx.verifyEmailOTP('test@example.com', '123456');
    });

    expect(mockVerifyOtp).toHaveBeenCalledWith({
      email: 'test@example.com',
      token: '123456',
      type: 'email',
    });
  });

  it('throws on invalid OTP', async () => {
    mockVerifyOtp.mockResolvedValue({ data: null, error: { message: 'Invalid OTP' } });

    let authCtx: any;
    renderWithAuth((auth) => { authCtx = auth; });

    await expect(act(async () => {
      await authCtx.verifyEmailOTP('test@example.com', '000000');
    })).rejects.toBeTruthy();
  });
});

// ── signInAsGuest ─────────────────────────────────────────────────────────────
describe('signInAsGuest', () => {
  it('inserts guest session and stores in localStorage', async () => {
    const mockInsert = jest.fn().mockResolvedValue({ error: null });
    mockFrom.mockReturnValue({ insert: mockInsert });

    let authCtx: any;
    renderWithAuth((auth) => { authCtx = auth; });

    await act(async () => {
      await authCtx.signInAsGuest('TestGuest');
    });

    expect(mockInsert).toHaveBeenCalledWith(
      expect.objectContaining({ guest_name: 'TestGuest' })
    );
    const stored = localStorage.getItem('gm_guest_session');
    expect(stored).not.toBeNull();
    const parsed = JSON.parse(stored!);
    expect(parsed.name).toBe('TestGuest');
    expect(parsed.token).toMatch(/^guest_/);
  });

  it('throws when DB insert fails', async () => {
    const mockInsert = jest.fn().mockResolvedValue({ error: { message: 'Insert failed' } });
    mockFrom.mockReturnValue({ insert: mockInsert });

    let authCtx: any;
    renderWithAuth((auth) => { authCtx = auth; });

    await expect(act(async () => {
      await authCtx.signInAsGuest('BadGuest');
    })).rejects.toBeTruthy();
  });
});

// ── signOut ───────────────────────────────────────────────────────────────────
describe('signOut', () => {
  it('calls supabase signOut and clears guest session', async () => {
    mockSignOut.mockResolvedValue({ error: null });
    localStorage.setItem('gm_guest_session', JSON.stringify({ name: 'Guest', token: 'guest_123' }));

    let authCtx: any;
    renderWithAuth((auth) => { authCtx = auth; });

    await act(async () => {
      await authCtx.signOut();
    });

    expect(mockSignOut).toHaveBeenCalled();
    expect(localStorage.getItem('gm_guest_session')).toBeNull();
  });

  it('throws when supabase signOut fails', async () => {
    mockSignOut.mockResolvedValue({ error: { message: 'Sign out failed' } });

    let authCtx: any;
    renderWithAuth((auth) => { authCtx = auth; });

    await expect(act(async () => {
      await authCtx.signOut();
    })).rejects.toBeTruthy();
  });
});

// ── isGuest / isAuthenticated ─────────────────────────────────────────────────
describe('isGuest and isAuthenticated', () => {
  it('isGuest is false when no guest session', async () => {
    let authCtx: any;
    renderWithAuth((auth) => { authCtx = auth; });
    await waitFor(() => expect(authCtx.isGuest).toBe(false));
  });

  it('isAuthenticated is false when no user and no guest', async () => {
    let authCtx: any;
    renderWithAuth((auth) => { authCtx = auth; });
    await waitFor(() => expect(authCtx.isAuthenticated).toBe(false));
  });
});
