/**
 * Unit Tests — auth/callback/route.ts
 * Tests the GET handler for OAuth code exchange and profile creation
 */

import '@testing-library/jest-dom';
import { GET } from '@/app/auth/callback/route';
import { NextRequest } from 'next/server';

// ── Mock Supabase server client ───────────────────────────────────────────────
const mockExchangeCodeForSession = jest.fn();
const mockSelect = jest.fn();
const mockUpsert = jest.fn();

const mockSupabase = {
  auth: {
    exchangeCodeForSession: mockExchangeCodeForSession,
  },
  from: jest.fn().mockReturnValue({
    select: mockSelect,
    upsert: mockUpsert,
  }),
};

jest.mock('@/lib/supabase/server', () => ({
  createClient: jest.fn().mockResolvedValue(mockSupabase),
}));

// ── Helpers ───────────────────────────────────────────────────────────────────
function makeRequest(url: string) {
  return new NextRequest(url);
}

const BASE_URL = 'https://mathics35409.builtwithmathics.new';

// ── Tests ─────────────────────────────────────────────────────────────────────
describe('auth/callback GET handler', () => {
  beforeEach(() => {
    jest.clearAllMocks();
    mockSelect.mockReturnValue({
      eq: jest.fn().mockReturnValue({
        single: jest.fn().mockResolvedValue({ data: null, error: null }),
      }),
    });
    mockUpsert.mockResolvedValue({ error: null });
  });

  it('redirects to / on successful code exchange for new user', async () => {
    mockExchangeCodeForSession.mockResolvedValue({
      data: {
        user: {
          id: 'user-123',
          email: 'test@example.com',
          user_metadata: { full_name: 'Test User' },
          app_metadata: { provider: 'google' },
        },
      },
      error: null,
    });

    const req = makeRequest(`${BASE_URL}/auth/callback?code=valid-code`);
    const response = await GET(req);

    expect(response.status).toBe(307);
    expect(response.headers.get('location')).toContain('/');
  });

  it('redirects to /sign-up-login-screen when no code provided', async () => {
    const req = makeRequest(`${BASE_URL}/auth/callback`);
    const response = await GET(req);

    expect(response.status).toBe(307);
    expect(response.headers.get('location')).toContain('/sign-up-login-screen');
  });

  it('redirects to /sign-up-login-screen on exchange error', async () => {
    mockExchangeCodeForSession.mockResolvedValue({
      data: null,
      error: { message: 'Invalid code' },
    });

    const req = makeRequest(`${BASE_URL}/auth/callback?code=bad-code`);
    const response = await GET(req);

    expect(response.status).toBe(307);
    expect(response.headers.get('location')).toContain('/sign-up-login-screen');
  });

  it('respects the next query param for redirect', async () => {
    mockExchangeCodeForSession.mockResolvedValue({
      data: {
        user: {
          id: 'user-456',
          email: 'user@example.com',
          user_metadata: {},
          app_metadata: { provider: 'email' },
        },
      },
      error: null,
    });

    const req = makeRequest(`${BASE_URL}/auth/callback?code=valid-code&next=/home-dashboard`);
    const response = await GET(req);

    expect(response.headers.get('location')).toContain('/home-dashboard');
  });

  it('does not create profile if user already exists', async () => {
    mockExchangeCodeForSession.mockResolvedValue({
      data: {
        user: {
          id: 'existing-user',
          email: 'existing@example.com',
          user_metadata: {},
          app_metadata: { provider: 'google' },
        },
      },
      error: null,
    });

    // Simulate existing user
    mockSelect.mockReturnValue({
      eq: jest.fn().mockReturnValue({
        single: jest.fn().mockResolvedValue({ data: { id: 'existing-user' }, error: null }),
      }),
    });

    const req = makeRequest(`${BASE_URL}/auth/callback?code=valid-code`);
    await GET(req);

    expect(mockUpsert).not.toHaveBeenCalled();
  });

  it('creates profile with Silver rank for new user', async () => {
    mockExchangeCodeForSession.mockResolvedValue({
      data: {
        user: {
          id: 'new-user-789',
          email: 'new@example.com',
          user_metadata: { full_name: 'New User' },
          app_metadata: { provider: 'google' },
        },
      },
      error: null,
    });

    const req = makeRequest(`${BASE_URL}/auth/callback?code=valid-code`);
    await GET(req);

    expect(mockUpsert).toHaveBeenCalledWith(
      expect.objectContaining({ rank: 'Silver', lp: 0 }),
      expect.any(Object)
    );
  });
});
