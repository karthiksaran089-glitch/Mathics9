/**
 * Unit Tests — PracticeConfig.tsx (PracticeConfigPhase)
 * Tests topic selection, difficulty selection, question count, and start handler
 */

import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import { jest, describe, beforeEach, it, expect } from '@jest/globals';
import PracticeConfigPhase from '@/app/practice/components/PracticeConfig';
import type { PracticeConfig } from '@/app/practice/components/PracticeMode';

// Mock AppIcon
jest.mock('@/components/ui/AppIcon', () => ({
  __esModule: true,
  default: () => null,
}));

describe('PracticeConfigPhase', () => {
  const mockOnStart = jest.fn();

  beforeEach(() => {
    mockOnStart.mockClear();
  });

  it('renders the start button', () => {
    render(<PracticeConfigPhase onStart={mockOnStart} />);
    expect(screen.getByText('Start Practice Session')).toBeInTheDocument();
  });

  it('renders all 12 topics', () => {
    render(<PracticeConfigPhase onStart={mockOnStart} />);
    expect(screen.getByText('Operating Systems')).toBeInTheDocument();
    expect(screen.getByText('DBMS')).toBeInTheDocument();
    expect(screen.getByText('Algorithms')).toBeInTheDocument();
    expect(screen.getByText('Artificial Intelligence')).toBeInTheDocument();
  });

  it('renders all 4 difficulty options', () => {
    render(<PracticeConfigPhase onStart={mockOnStart} />);
    expect(screen.getByText('Easy')).toBeInTheDocument();
    expect(screen.getByText('Medium')).toBeInTheDocument();
    expect(screen.getByText('Hard')).toBeInTheDocument();
    expect(screen.getByText('Mixed')).toBeInTheDocument();
  });

  it('renders question count options', () => {
    render(<PracticeConfigPhase onStart={mockOnStart} />);
    expect(screen.getByText('5')).toBeInTheDocument();
    expect(screen.getByText('10')).toBeInTheDocument();
    expect(screen.getByText('15')).toBeInTheDocument();
    expect(screen.getByText('20')).toBeInTheDocument();
  });

  it('calls onStart with default config when no selections made', () => {
    render(<PracticeConfigPhase onStart={mockOnStart} />);
    fireEvent.click(screen.getByText('Start Practice Session'));
    expect(mockOnStart).toHaveBeenCalledWith({
      selectedTopics: [],
      difficulty: 'Mixed',
      questionCount: 10,
    });
  });

  it('toggles topic selection on click', () => {
    render(<PracticeConfigPhase onStart={mockOnStart} />);
    const osButton = screen.getByText('Operating Systems').closest('button')!;
    fireEvent.click(osButton);
    // After click, "1 topic selected" should appear
    expect(screen.getByText('1 topic selected')).toBeInTheDocument();
  });

  it('deselects topic on second click', () => {
    render(<PracticeConfigPhase onStart={mockOnStart} />);
    const osButton = screen.getByText('Operating Systems').closest('button')!;
    fireEvent.click(osButton);
    fireEvent.click(osButton);
    expect(screen.getByText('All 12 topics in pool')).toBeInTheDocument();
  });

  it('clears all topics when "Clear all" is clicked', () => {
    render(<PracticeConfigPhase onStart={mockOnStart} />);
    fireEvent.click(screen.getByText('Operating Systems').closest('button')!);
    fireEvent.click(screen.getByText('DBMS').closest('button')!);
    fireEvent.click(screen.getByText('Clear all'));
    expect(screen.getByText('All 12 topics in pool')).toBeInTheDocument();
  });

  it('changes difficulty on click', () => {
    render(<PracticeConfigPhase onStart={mockOnStart} />);
    fireEvent.click(screen.getByText('Hard').closest('button')!);
    fireEvent.click(screen.getByText('Start Practice Session'));
    expect(mockOnStart).toHaveBeenCalledWith(
      expect.objectContaining({ difficulty: 'Hard' })
    );
  });

  it('changes question count on click', () => {
    render(<PracticeConfigPhase onStart={mockOnStart} />);
    fireEvent.click(screen.getByText('20'));
    fireEvent.click(screen.getByText('Start Practice Session'));
    expect(mockOnStart).toHaveBeenCalledWith(
      expect.objectContaining({ questionCount: 20 })
    );
  });

  it('passes selected topics to onStart', () => {
    render(<PracticeConfigPhase onStart={mockOnStart} />);
    fireEvent.click(screen.getByText('Algorithms').closest('button')!);
    fireEvent.click(screen.getByText('DBMS').closest('button')!);
    fireEvent.click(screen.getByText('Start Practice Session'));
    const call = mockOnStart.mock.calls[0][0] as PracticeConfig;
    expect(call.selectedTopics).toContain('topic-algo');
    expect(call.selectedTopics).toContain('topic-dbms');
  });
});
