/**
 * Unit Tests — fallbackQuestions.ts
 * Tests the public functions: fetchRankedFallbackQuestion, fetchPracticeFallbackQuestion, fetchPracticeFallbackBatch
 */

/// <reference types="@types/jest" />
import '@testing-library/jest-dom';

import {
  fetchRankedFallbackQuestion,
  fetchRankedQuestionPool,
  fetchPracticeFallbackQuestion,
  fetchPracticeFallbackBatch,
  type FallbackQuestion,
} from '@/lib/questions/fallbackQuestions';

// ── Mock Supabase client ──────────────────────────────────────────────────────
const mockSelect = jest.fn();
const mockEq = jest.fn();
const mockIn = jest.fn();
const mockNot = jest.fn();
const mockLimit = jest.fn();

const mockQuery = {
  select: mockSelect,
  eq: mockEq,
  in: mockIn,
  not: mockNot,
  limit: mockLimit,
};

// Chain all query methods back to mockQuery for fluent API
[mockSelect, mockEq, mockIn, mockNot, mockLimit].forEach((fn) => {
  fn.mockReturnValue(mockQuery);
});

const mockFrom = jest.fn().mockReturnValue(mockQuery);
const mockSupabase = { from: mockFrom };

jest.mock('@/lib/supabase/client', () => ({
  createClient: () => mockSupabase,
}));

// ── Sample data ───────────────────────────────────────────────────────────────
const sampleRow = {
  id: 'test-001',
  topic: 'Algorithms',
  difficulty: 'Medium',
  time_limit: 60,
  question: 'What is O(n log n)?',
  option_a: 'Linear',
  option_b: 'Linearithmic',
  option_c: 'Quadratic',
  option_d: 'Constant',
  correct_index: 1,
  explanation: 'O(n log n) is linearithmic.',
  hint: 'Think merge sort.',
};

const expectedQuestion: FallbackQuestion = {
  id: 'test-001',
  topic: 'Algorithms',
  difficulty: 'Medium',
  timeLimit: 60,
  text: 'What is O(n log n)?',
  options: ['Linear', 'Linearithmic', 'Quadratic', 'Constant'],
  correct: 1,
  explanation: 'O(n log n) is linearithmic.',
  hint: 'Think merge sort.',
};

// ── fetchRankedFallbackQuestion ───────────────────────────────────────────────
describe('fetchRankedFallbackQuestion', () => {
  beforeEach(() => jest.clearAllMocks());

  it('returns a mapped question on success', async () => {
    mockNot.mockResolvedValueOnce({ data: [sampleRow], error: null });
    const result = await fetchRankedFallbackQuestion(['Algorithms'], []);
    expect(result).toMatchObject({ id: 'test-001', topic: 'Algorithms', difficulty: 'Medium' });
  });

  it('returns null when supabase returns error', async () => {
    mockNot.mockResolvedValueOnce({ data: null, error: { message: 'DB error' } });
    // Retry without topics also fails
    mockEq.mockResolvedValueOnce({ data: null, error: { message: 'DB error' } });
    const result = await fetchRankedFallbackQuestion(['Algorithms'], []);
    expect(result).toBeNull();
  });

  it('returns null when data is empty array', async () => {
    mockNot.mockResolvedValueOnce({ data: [], error: null });
    mockEq.mockResolvedValueOnce({ data: [], error: null });
    const result = await fetchRankedFallbackQuestion(['Algorithms'], []);
    expect(result).toBeNull();
  });

  it('retries without topics when topic-filtered query returns empty', async () => {
    mockNot
      .mockResolvedValueOnce({ data: [], error: null })   // first call with topics
      .mockResolvedValueOnce({ data: [sampleRow], error: null }); // retry without topics
    const result = await fetchRankedFallbackQuestion(['Algorithms'], []);
    expect(result).not.toBeNull();
  });

  it('returns null when supabase client is null', async () => {
    jest.resetModules();
    jest.doMock('@/lib/supabase/client', () => ({ createClient: () => null }));
    const { fetchRankedFallbackQuestion: fn } = await import('@/lib/questions/fallbackQuestions');
    const result = await fn(['Algorithms'], []);
    expect(result).toBeNull();
    jest.resetModules();
  });

  it('maps row fields correctly', async () => {
    mockNot.mockResolvedValueOnce({ data: [sampleRow], error: null });
    const result = await fetchRankedFallbackQuestion([], []);
    expect(result).toEqual(expectedQuestion);
  });

  it('excludes used IDs from ranked results', async () => {
    mockNot.mockResolvedValueOnce({ data: [sampleRow], error: null });
    await fetchRankedFallbackQuestion([], ['test-001']);
    expect(mockNot).toHaveBeenCalled();
  });
});

describe('fetchRankedQuestionPool', () => {
  beforeEach(() => jest.clearAllMocks());

  it('returns a unique shuffled pool', async () => {
    const rows = [
      { ...sampleRow, id: 'test-001' },
      { ...sampleRow, id: 'test-002' },
      { ...sampleRow, id: 'test-003' },
    ];
    mockEq.mockResolvedValueOnce({ data: rows, error: null });

    const result = await fetchRankedQuestionPool([], 2);

    expect(result).toHaveLength(2);
    expect(new Set(result.map((q) => q.id)).size).toBe(2);
  });
});

// ── fetchPracticeFallbackQuestion ─────────────────────────────────────────────
describe('fetchPracticeFallbackQuestion', () => {
  beforeEach(() => jest.clearAllMocks());

  it('returns a question for Mixed difficulty', async () => {
    mockNot.mockResolvedValueOnce({ data: [sampleRow], error: null });
    const result = await fetchPracticeFallbackQuestion([], 'Mixed', []);
    expect(result).not.toBeNull();
    expect(result?.topic).toBe('Algorithms');
  });

  it('returns a question for specific difficulty', async () => {
    mockNot.mockResolvedValueOnce({ data: [sampleRow], error: null });
    const result = await fetchPracticeFallbackQuestion([], 'Medium', []);
    expect(result?.difficulty).toBe('Medium');
  });

  it('falls back to Mixed when specific difficulty returns empty', async () => {
    mockNot
      .mockResolvedValueOnce({ data: [], error: null })   // Hard difficulty, no results
      .mockResolvedValueOnce({ data: [sampleRow], error: null }); // Mixed fallback
    const result = await fetchPracticeFallbackQuestion([], 'Hard', []);
    expect(result).not.toBeNull();
  });

  it('falls back to no-topic when topic filter returns empty', async () => {
    mockNot
      .mockResolvedValueOnce({ data: [], error: null })   // with topics
      .mockResolvedValueOnce({ data: [sampleRow], error: null }); // without topics
    const result = await fetchPracticeFallbackQuestion(['DBMS'], 'Mixed', []);
    expect(result).not.toBeNull();
  });

  it('returns null when all fallbacks exhausted', async () => {
    mockNot.mockResolvedValue({ data: [], error: null });
    const result = await fetchPracticeFallbackQuestion([], 'Mixed', []);
    expect(result).toBeNull();
  });

  it('excludes used IDs from results', async () => {
    mockNot.mockResolvedValueOnce({ data: [sampleRow], error: null });
    await fetchPracticeFallbackQuestion([], 'Mixed', ['test-001']);
    // Verify .not() was called (used IDs exclusion)
    expect(mockNot).toHaveBeenCalled();
  });
});

// ── fetchPracticeFallbackBatch ────────────────────────────────────────────────
describe('fetchPracticeFallbackBatch', () => {
  beforeEach(() => jest.clearAllMocks());

  it('returns up to count questions', async () => {
    const rows = Array.from({ length: 5 }, (_, i) => ({ ...sampleRow, id: `test-00${i + 1}` }));
    mockLimit.mockResolvedValueOnce({ data: rows, error: null });
    const result = await fetchPracticeFallbackBatch(3, [], 'Mixed');
    expect(result.length).toBeLessThanOrEqual(3);
  });

  it('returns empty array on error', async () => {
    mockLimit.mockResolvedValueOnce({ data: null, error: { message: 'error' } });
    mockLimit.mockResolvedValueOnce({ data: null, error: { message: 'error' } });
    mockLimit.mockResolvedValueOnce({ data: null, error: { message: 'error' } });
    const result = await fetchPracticeFallbackBatch(5, [], 'Mixed');
    expect(result).toEqual([]);
  });

  it('returns empty array when supabase client is null', async () => {
    jest.resetModules();
    jest.doMock('@/lib/supabase/client', () => ({ createClient: () => null }));
    const { fetchPracticeFallbackBatch: fn } = await import('@/lib/questions/fallbackQuestions');
    const result = await fn(5, [], 'Mixed');
    expect(result).toEqual([]);
    jest.resetModules();
  });

  it('maps all returned rows correctly', async () => {
    mockLimit.mockResolvedValueOnce({ data: [sampleRow], error: null });
    const result = await fetchPracticeFallbackBatch(1, [], 'Mixed');
    expect(result[0]).toMatchObject({ id: 'test-001', topic: 'Algorithms' });
  });
});
