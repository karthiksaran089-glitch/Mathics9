/**
 * Unit Tests — PracticeMode.tsx
 * Tests session state transitions and core logic
 */

import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import PracticeMode from '@/app/practice/components/PracticeMode';
import type { PracticeConfig } from '@/app/practice/components/PracticeMode';
import { jest, describe, it, expect } from '@jest/globals';

// ── Mocks ─────────────────────────────────────────────────────────────────────
jest.mock('@/app/practice/components/PracticeConfigPhase', () => ({
  __esModule: true,
  default: ({ onStart }: { onStart: (cfg: PracticeConfig) => void }) => (
    <button
      data-testid="start-btn"
      onClick={() => onStart({ selectedTopics: [], difficulty: 'Mixed', questionCount: 5 })}
    >
      Start
    </button>
  ),
}));

jest.mock('@/app/practice/components/PracticeQuestionPhase', () => ({
  __esModule: true,
  default: ({ onSubmit, onNext, session }: any) => (
    <div>
      <span data-testid="question-num">{session.currentQuestion}</span>
      <button
        data-testid="submit-btn"
        onClick={() =>
          onSubmit(0, 0, true, 'Q text', ['A', 'B', 'C', 'D'], 'Explanation', 'Algorithms', 'Medium', 30, false)
        }
      >
        Submit
      </button>
      <button data-testid="next-btn" onClick={onNext}>Next</button>
    </div>
  ),
}));

jest.mock('@/app/practice/components/PracticeSummaryPhase', () => ({
  __esModule: true,
  default: ({ onPlayAgain, onTryNew }: any) => (
    <div>
      <span data-testid="summary">Summary</span>
      <button data-testid="play-again" onClick={onPlayAgain}>Play Again</button>
      <button data-testid="try-new" onClick={onTryNew}>Try New</button>
    </div>
  ),
}));

jest.mock('@/components/ui/Toast', () => ({ __esModule: true, default: () => null }));

// ── Tests ─────────────────────────────────────────────────────────────────────
describe('PracticeMode', () => {
  it('renders config phase initially', () => {
    render(<PracticeMode />);
    expect(screen.getByTestId('start-btn')).toBeInTheDocument();
  });

  it('transitions to question phase after start', () => {
    render(<PracticeMode />);
    fireEvent.click(screen.getByTestId('start-btn'));
    expect(screen.getByTestId('question-num')).toBeInTheDocument();
    expect(screen.getByTestId('question-num').textContent).toBe('1');
  });

  it('advances question number after next', () => {
    render(<PracticeMode />);
    fireEvent.click(screen.getByTestId('start-btn'));
    fireEvent.click(screen.getByTestId('submit-btn'));
    fireEvent.click(screen.getByTestId('next-btn'));
    expect(screen.getByTestId('question-num').textContent).toBe('2');
  });

  it('shows summary after all questions answered', () => {
    render(<PracticeMode />);
    fireEvent.click(screen.getByTestId('start-btn'));

    // Answer all 5 questions
    for (let i = 0; i < 5; i++) {
      fireEvent.click(screen.getByTestId('submit-btn'));
      fireEvent.click(screen.getByTestId('next-btn'));
    }

    expect(screen.getByTestId('summary')).toBeInTheDocument();
  });

  it('resets to question 1 on play again', () => {
    render(<PracticeMode />);
    fireEvent.click(screen.getByTestId('start-btn'));

    for (let i = 0; i < 5; i++) {
      fireEvent.click(screen.getByTestId('submit-btn'));
      fireEvent.click(screen.getByTestId('next-btn'));
    }

    fireEvent.click(screen.getByTestId('play-again'));
    expect(screen.getByTestId('question-num').textContent).toBe('1');
  });

  it('resets to config phase on try new', () => {
    render(<PracticeMode />);
    fireEvent.click(screen.getByTestId('start-btn'));

    for (let i = 0; i < 5; i++) {
      fireEvent.click(screen.getByTestId('submit-btn'));
      fireEvent.click(screen.getByTestId('next-btn'));
    }

    fireEvent.click(screen.getByTestId('try-new'));
    expect(screen.getByTestId('start-btn')).toBeInTheDocument();
  });

  it('shows progress bar during question phase', () => {
    render(<PracticeMode />);
    fireEvent.click(screen.getByTestId('start-btn'));
    // Progress bar should be visible
    const progressBar = document.querySelector('.bg-primary.rounded-full');
    expect(progressBar).toBeInTheDocument();
  });

  it('shows "Practice Mode" header text', () => {
    render(<PracticeMode />);
    expect(screen.getByText('Practice Mode')).toBeInTheDocument();
  });
});
