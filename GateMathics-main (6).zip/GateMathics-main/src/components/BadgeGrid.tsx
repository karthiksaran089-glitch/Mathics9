'use client';
import React from 'react';
import { Lock } from 'lucide-react';
import { getAllBadges, getUnlockedBadgeIds } from '@/lib/gamification';
import type { UserProfileStats } from '@/lib/gamification';

interface BadgeGridProps {
  stats: UserProfileStats;
  /** Optional extra badge IDs to mark as unlocked (e.g. topic-master from external check) */
  extraUnlocked?: string[];
}

export default function BadgeGrid({ stats, extraUnlocked = [] }: BadgeGridProps) {
  const badges = getAllBadges();
  const unlockedIds = [...getUnlockedBadgeIds(stats), ...extraUnlocked];

  return (
    <div className="grid grid-cols-3 sm:grid-cols-4 lg:grid-cols-6 gap-3">
      {badges.map((badge) => {
        const isUnlocked = unlockedIds.includes(badge.id);

        return (
          <div
            key={badge.id}
            className={`relative flex flex-col items-center gap-2 p-4 rounded-xl border text-center transition-all duration-200 group ${
              isUnlocked
                ? 'border-border/60 bg-card hover:scale-[1.03]'
                : 'border-border/30 bg-muted/20 opacity-50'
            }`}
            style={
              isUnlocked
                ? { boxShadow: `0 0 16px ${badge.glowColor}` }
                : undefined
            }
            title={isUnlocked ? `${badge.name}: ${badge.description}` : `Locked — ${badge.requirement}`}
          >
            {/* Badge icon */}
            <div
              className={`w-12 h-12 rounded-xl flex items-center justify-center text-2xl transition-transform ${
                isUnlocked ? 'group-hover:scale-110' : 'grayscale'
              }`}
              style={
                isUnlocked
                  ? { background: `${badge.color}20`, boxShadow: `0 0 12px ${badge.glowColor}` }
                  : { background: 'var(--muted)' }
              }
            >
              {isUnlocked ? (
                badge.emoji
              ) : (
                <Lock size={18} className="text-muted-foreground" />
              )}
            </div>

            {/* Badge name */}
            <p
              className={`text-[11px] font-bold leading-tight ${
                isUnlocked ? '' : 'text-muted-foreground'
              }`}
              style={isUnlocked ? { color: badge.color } : undefined}
            >
              {badge.name}
            </p>

            {/* Requirement (locked) or description (unlocked) */}
            <p className="text-[9px] text-muted-foreground leading-snug">
              {isUnlocked ? badge.description : badge.requirement}
            </p>
          </div>
        );
      })}
    </div>
  );
}
