'use client';
import React, { useState, useEffect, useMemo } from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import AppLogo from '@/components/ui/AppLogo';
import Badge from '@/components/ui/Badge';
import {
  Trophy,
  BookOpen,
  BarChart3,
  User,
  HelpCircle,
  Sun,
  Moon,
  ChevronLeft,
  ChevronRight,
  Flame,
  Star,
  LogOut,
  Info,
  Mail,
  Shield,
} from 'lucide-react';
import { createClient } from '@/lib/supabase/client';
import Icon from '@/components/ui/AppIcon';
import { useAuth } from '@/contexts/AuthContext';
import { useRouter } from 'next/navigation';
import { getLevelInfo, computeTotalXP, getLevelFromXP, getTier, type UserProfileStats } from '@/lib/gamification';


interface SidebarProps {
  collapsed: boolean;
  onToggle: () => void;
  theme: 'dark' | 'light';
  onThemeToggle: () => void;
}

interface SidebarUserData {
  display_name: string;
  rank: string;
  lp: number;
  daily_streak: number;
  total_correct: number;
  total_sessions: number;
  longest_streak: number;
}

const DEFAULT_USER: SidebarUserData = {
  display_name: 'User',
  rank: 'Silver',
  lp: 0,
  daily_streak: 0,
  total_correct: 0,
  total_sessions: 0,
  longest_streak: 0,
};

const navItems = [
  {
    key: 'nav-ranked',
    href: '/ranked-mode-screen',
    icon: Trophy,
    label: 'Ranked Mode',
    badge: null,
    badgeVariant: null as 'warning' | 'danger' | null,
    description: 'Compete for LP',
  },
  {
    key: 'nav-practice',
    href: '/practice',
    icon: BookOpen,
    label: 'Practice Mode',
    badge: null,
    badgeVariant: null as 'warning' | 'danger' | null,
    description: 'Structured study',
  },
  {
    key: 'nav-analytics',
    href: '/analytics',
    icon: BarChart3,
    label: 'Analytics',
    badge: null,
    badgeVariant: null as 'warning' | 'danger' | null,
    description: 'Performance insights',
  },
];

const bottomItems = [
  { key: 'nav-profile', href: '/profile', icon: User, label: 'Profile' },
  { key: 'nav-help', href: '/help', icon: HelpCircle, label: 'Help Center' },
  { key: 'nav-about', href: '/about', icon: Info, label: 'About' },
  { key: 'nav-contact', href: '/contact', icon: Mail, label: 'Contact' },
  { key: 'nav-privacy', href: '/privacy-policy', icon: Shield, label: 'Privacy Policy' },
];

function getRankBadgeVariant(rank: string): 'silver' | 'warning' | 'danger' | 'success' | 'info' {
  switch (rank) {
    case 'Gold': return 'warning';
    case 'Silver': return 'silver';
    case 'Bronze': return 'warning';
    case 'Grandmaster': return 'danger';
    case 'Diamond': return 'info';
    case 'Platinum': return 'info';
    default: return 'silver';
  }
}

export default function AppSidebar({ collapsed, onToggle, theme, onThemeToggle }: SidebarProps) {
  const pathname = usePathname();
  const [userData, setUserData] = useState<SidebarUserData>(DEFAULT_USER);
  const [mounted, setMounted] = useState(false);
  const { guestSession, isGuest, signOut, signOutGuest } = useAuth();
  const router = useRouter();

  useEffect(() => {
    setMounted(true);

    // If guest session, show guest name immediately
    if (isGuest && guestSession) {
      setUserData({
        display_name: guestSession.name,
        rank: 'Guest',
        lp: 0,
        daily_streak: 0,
        total_correct: 0,
        total_sessions: 0,
        longest_streak: 0,
      });
      return;
    }

    const loadUser = async () => {
      const supabase = createClient();
      if (!supabase) return;
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;
      const { data } = await supabase
        .from('user_profiles')
        .select('display_name, rank, lp, daily_streak, total_correct, total_sessions, longest_streak')
        .eq('id', user.id)
        .single();
      if (data) {
        setUserData({
          display_name: data.display_name || user.email?.split('@')[0] || 'User',
          rank: data.rank || 'Silver',
          lp: data.lp ?? 0,
          daily_streak: data.daily_streak ?? 0,
          total_correct: data.total_correct ?? 0,
          total_sessions: data.total_sessions ?? 0,
          longest_streak: data.longest_streak ?? 0,
        });
      }

      // Realtime Sync
      const channel = supabase.channel('sidebar_profile_sync')
        .on('postgres_changes', {
          event: '*',
          schema: 'public',
          table: 'user_profiles',
          filter: `id=eq.${user.id}`
        }, (payload: any) => {
          const newData = payload.new;
          if (newData) {
            setUserData(prev => ({
              ...prev,
              display_name: newData.display_name || prev.display_name,
              rank: newData.rank || prev.rank,
              lp: newData.lp ?? prev.lp,
              daily_streak: newData.daily_streak ?? prev.daily_streak,
              total_correct: newData.total_correct ?? prev.total_correct,
              total_sessions: newData.total_sessions ?? prev.total_sessions,
              longest_streak: newData.longest_streak ?? prev.longest_streak,
            }));
          }
        })
        .subscribe();

      return () => {
        supabase.removeChannel(channel);
      };
    };

    let cleanupFn: (() => void) | undefined;
    loadUser().then(cleanup => {
      cleanupFn = cleanup;
    });

    return () => {
      if (cleanupFn) cleanupFn();
    };
  }, [isGuest, guestSession]);

  const handleSignOut = async () => {
    try {
      if (isGuest) {
        signOutGuest();
      } else {
        await signOut();
      }
    } catch {
      // fallback: clear local storage and redirect
      localStorage.removeItem('gm_guest_session');
    }
    router.push('/sign-up-login-screen');
  };

  const displayInitial = mounted ? userData.display_name.charAt(0).toUpperCase() : 'U';
  const rankVariant = getRankBadgeVariant(userData.rank);

  const levelInfo = useMemo(() => {
    if (!mounted) return null;
    const fakeStats: UserProfileStats = {
      total_questions_answered: 0,
      total_correct: userData.total_correct,
      total_incorrect: 0,
      total_timeout: 0,
      total_sessions: userData.total_sessions,
      total_ranked_sessions: 0,
      total_practice_sessions: 0,
      overall_accuracy: 0,
      avg_answer_speed_seconds: 0,
      daily_streak: userData.daily_streak,
      longest_streak: userData.longest_streak,
      lp: userData.lp,
      rank: userData.rank,
    };
    return getLevelInfo(fakeStats);
  }, [mounted, userData]);

  return (
    <aside
      className={`flex flex-col h-screen bg-card border-r border-border transition-all duration-300 ease-in-out relative z-20 ${
        collapsed ? 'w-16' : 'w-64'
      }`}
    >
      {/* Toggle Button */}
      <button
        onClick={onToggle}
        className="absolute -right-3 top-20 w-6 h-6 rounded-full bg-card border border-border flex items-center justify-center text-muted-foreground hover:text-foreground transition-colors z-30"
        aria-label={collapsed ? 'Expand sidebar' : 'Collapse sidebar'}
      >
        {collapsed ? <ChevronRight size={12} /> : <ChevronLeft size={12} />}
      </button>

      {/* Logo */}
      <div className={`flex items-center gap-2.5 px-4 py-5 border-b border-border ${collapsed ? 'justify-center' : ''}`}>
        <AppLogo size={32} />
        {!collapsed && (
          <span className="font-extrabold text-lg tracking-tight text-gradient-primary">
            GateMathics
          </span>
        )}
      </div>

      {/* User Profile Section */}
      <div className={`px-3 py-4 border-b border-border ${collapsed ? 'flex flex-col items-center' : ''}`}>
        {collapsed ? (
          <div className="relative">
            <div className="w-9 h-9 rounded-full bg-gradient-to-br from-primary to-info flex items-center justify-center text-sm font-bold text-white">
              {displayInitial}
            </div>
            <div className="absolute -bottom-1 -right-1 w-4 h-4 rounded-full rank-badge-silver flex items-center justify-center">
              <Star size={8} />
            </div>
          </div>
        ) : (
          <div className="flex items-start gap-3">
            <div className="relative flex-shrink-0">
              <div className="w-11 h-11 rounded-full bg-gradient-to-br from-primary to-info flex items-center justify-center text-base font-bold text-white">
                {displayInitial}
              </div>
              <div className="absolute -bottom-1 -right-1 w-5 h-5 rounded-full rank-badge-silver flex items-center justify-center">
                <Star size={9} />
              </div>
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-semibold text-foreground truncate">
                {mounted ? userData.display_name : '—'}
              </p>
              <div className="flex items-center gap-1.5 mt-0.5 flex-wrap">
                <Badge variant={rankVariant} size="sm">{mounted ? userData.rank : 'Silver'}</Badge>
                {levelInfo && (
                  <span
                    className="text-[10px] font-bold px-1.5 py-0.5 rounded-full"
                    style={{ background: `${levelInfo.tier.color}22`, color: levelInfo.tier.color }}
                  >
                    Lv.{levelInfo.level}
                  </span>
                )}
                <span className="font-mono-data text-xs text-accent font-semibold">
                  {mounted ? `${userData.lp} LP` : '—'}
                </span>
              </div>
            </div>
          </div>
        )}

        {/* Streak */}
        {!collapsed && (
          <>
            <div className="mt-3 flex items-center gap-2 px-2.5 py-2 rounded-lg bg-muted">
              <Flame size={16} className="text-accent streak-flame animate-streak-bounce" />
              <span className="text-xs font-semibold text-foreground">
                {mounted ? `${userData.daily_streak}-day streak` : '—'}
              </span>
              <span className="ml-auto text-[10px] text-muted-foreground">🔥 Keep it up!</span>
            </div>
            {levelInfo && (
              <div className="mt-2 px-2.5">
                <div className="flex items-center justify-between mb-1">
                  <span className="text-[10px] text-muted-foreground">Level {levelInfo.level}</span>
                  <span className="text-[10px] font-mono-data" style={{ color: levelInfo.tier.color }}>
                    {levelInfo.xpInLevel}/{levelInfo.xpToNext} XP
                  </span>
                </div>
                <div className="w-full h-1.5 rounded-full overflow-hidden" style={{ background: 'var(--muted)' }}>
                  <div
                    className="h-full rounded-full transition-all duration-500"
                    style={{ width: `${levelInfo.progressPct}%`, background: levelInfo.tier.gradient }}
                  />
                </div>
              </div>
            )}
          </>
        )}
        {collapsed && (
          <div className="mt-2 flex flex-col items-center gap-0.5">
            <Flame size={14} className="text-accent streak-flame" />
            <span className="font-mono-data text-[10px] text-accent font-bold">
              {mounted ? userData.daily_streak : '—'}
            </span>
          </div>
        )}
      </div>

      {/* Navigation */}
      <nav className="flex-1 px-2 py-3 overflow-y-auto scrollbar-thin">
        {!collapsed && (
          <p className="text-[10px] font-semibold uppercase tracking-widest text-muted-foreground px-2 mb-2">
            Play
          </p>
        )}
        <ul className="flex flex-col gap-1">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = pathname === item.href || (item.href === '/' && pathname === '/home-dashboard');
            return (
              <li key={item.key}>
                <Link
                  href={item.href}
                  className={`flex items-center gap-3 px-3 py-2.5 rounded-lg transition-all duration-150 group relative ${
                    isActive
                      ? 'sidebar-item-active' :'text-muted-foreground hover:text-foreground hover:bg-muted'
                  } ${collapsed ? 'justify-center' : ''}`}
                  title={collapsed ? item.label : undefined}
                >
                  <Icon size={18} className={isActive ? 'text-primary' : 'group-hover:text-foreground'} />
                  {!collapsed && (
                    <>
                      <span className="text-sm font-medium flex-1">{item.label}</span>
                      {item.badge && item.badgeVariant && (
                        <Badge variant={item.badgeVariant} size="sm">{item.badge}</Badge>
                      )}
                    </>
                  )}
                  {collapsed && isActive && (
                    <div className="absolute left-0 top-1/2 -translate-y-1/2 w-1 h-6 bg-primary rounded-r-full" />
                  )}
                </Link>
              </li>
            );
          })}
        </ul>

        {!collapsed && (
          <p className="text-[10px] font-semibold uppercase tracking-widest text-muted-foreground px-2 mb-2 mt-5">
            Account
          </p>
        )}
        {!collapsed && <div className="h-px bg-border mb-3 mt-1" />}
        <ul className="flex flex-col gap-1">
          {bottomItems.map((item) => {
            const Icon = item.icon;
            const isActive = pathname === item.href;
            return (
              <li key={item.key}>
                <Link
                  href={item.href}
                  className={`flex items-center gap-3 px-3 py-2.5 rounded-lg transition-all duration-150 group ${
                    isActive
                      ? 'sidebar-item-active' :'text-muted-foreground hover:text-foreground hover:bg-muted'
                  } ${collapsed ? 'justify-center' : ''}`}
                  title={collapsed ? item.label : undefined}
                >
                  <Icon size={18} />
                  {!collapsed && <span className="text-sm font-medium">{item.label}</span>}
                </Link>
              </li>
            );
          })}
        </ul>
      </nav>

      {/* Bottom Actions */}
      <div className={`px-2 py-3 border-t border-border flex flex-col gap-1`}>
        {/* Theme Toggle */}
        <button
          onClick={onThemeToggle}
          className={`flex items-center gap-3 px-3 py-2.5 rounded-lg text-muted-foreground hover:text-foreground hover:bg-muted transition-all duration-150 w-full ${
            collapsed ? 'justify-center' : ''
          }`}
          title={collapsed ? (theme === 'dark' ? 'Switch to Light' : 'Switch to Dark') : undefined}
        >
          {theme === 'dark' ? <Sun size={18} /> : <Moon size={18} />}
          {!collapsed && (
            <span className="text-sm font-medium">
              {theme === 'dark' ? 'Light Mode' : 'Dark Mode'}
            </span>
          )}
        </button>

        {/* Sign Out */}
        <button
          onClick={handleSignOut}
          className={`flex items-center gap-3 px-3 py-2.5 rounded-lg text-muted-foreground hover:text-danger hover:bg-danger/10 transition-all duration-150 w-full ${
            collapsed ? 'justify-center' : ''
          }`}
          title={collapsed ? 'Sign Out' : undefined}
        >
          <LogOut size={18} />
          {!collapsed && <span className="text-sm font-medium">Sign Out</span>}
        </button>
      </div>
    </aside>
  );
}