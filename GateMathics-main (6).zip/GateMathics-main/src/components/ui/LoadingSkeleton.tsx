import React from 'react';

interface SkeletonProps {
  className?: string;
}

export function Skeleton({ className = '' }: SkeletonProps) {
  return (
    <div className={`animate-pulse bg-muted rounded-md ${className}`} />
  );
}

export function SidebarSkeleton() {
  return (
    <div className="w-64 h-screen bg-card border-r border-border p-4 flex flex-col gap-4">
      <div className="flex items-center gap-3 mb-6">
        <Skeleton className="w-10 h-10 rounded-xl" />
        <Skeleton className="h-5 w-28" />
      </div>
      <div className="flex flex-col items-center gap-2 mb-6">
        <Skeleton className="w-16 h-16 rounded-full" />
        <Skeleton className="h-4 w-24" />
        <Skeleton className="h-3 w-16" />
      </div>
      {Array.from({ length: 4 }).map((_, i) => (
        <Skeleton key={`sidebar-sk-${i}`} className="h-10 w-full rounded-lg" />
      ))}
    </div>
  );
}

export function CardSkeleton() {
  return (
    <div className="card-elevated p-5">
      <Skeleton className="h-4 w-24 mb-3" />
      <Skeleton className="h-8 w-32 mb-2" />
      <Skeleton className="h-3 w-20" />
    </div>
  );
}