import React from 'react';

type BadgeVariant = 'default' | 'primary' | 'success' | 'danger' | 'warning' | 'info' | 'silver' | 'bronze' | 'gold' | 'platinum' | 'diamond' | 'grandmaster';

interface BadgeProps {
  children: React.ReactNode;
  variant?: BadgeVariant;
  className?: string;
  size?: 'sm' | 'md';
}

const variantClasses: Record<BadgeVariant, string> = {
  default: 'bg-muted text-muted-foreground border border-border',
  primary: 'bg-primary/20 text-primary border border-primary/30',
  success: 'bg-[rgba(16,185,129,0.15)] text-success border border-[rgba(16,185,129,0.3)]',
  danger: 'bg-[rgba(239,68,68,0.15)] text-danger border border-[rgba(239,68,68,0.3)]',
  warning: 'bg-[rgba(245,158,11,0.15)] text-warning border border-[rgba(245,158,11,0.3)]',
  info: 'bg-[rgba(6,182,212,0.15)] text-info border border-[rgba(6,182,212,0.3)]',
  silver: 'rank-badge-silver',
  bronze: 'rank-badge-bronze',
  gold: 'rank-badge-gold',
  platinum: 'rank-badge-platinum',
  diamond: 'rank-badge-diamond',
  grandmaster: 'rank-badge-grandmaster',
};

export default function Badge({ children, variant = 'default', className = '', size = 'sm' }: BadgeProps) {
  const sizeClasses = size === 'sm' ? 'text-[11px] px-2 py-0.5' : 'text-xs px-2.5 py-1';
  return (
    <span
      className={`inline-flex items-center gap-1 font-semibold rounded-full ${sizeClasses} ${variantClasses[variant]} ${className}`}
    >
      {children}
    </span>
  );
}