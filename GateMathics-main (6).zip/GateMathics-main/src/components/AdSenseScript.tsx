import Script from 'next/script';
import React from 'react';

const AdSenseScript: React.FC = () => {
  const clientId = process.env.NEXT_PUBLIC_ADSENSE_CLIENT;
  if (!clientId) return null;
  return (
    <Script
      async
      src={`https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=${clientId}`}
      crossOrigin="anonymous"
      strategy="afterInteractive"
    />
  );
};

export default AdSenseScript;
