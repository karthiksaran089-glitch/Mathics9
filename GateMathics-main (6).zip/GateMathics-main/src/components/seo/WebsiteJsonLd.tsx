export default function WebsiteJsonLd() {
  const schema = {
    '@context': 'https://schema.org',
    '@graph': [
      {
        '@type': 'WebSite',
        '@id': 'https://mathics24882.builtwithmathics.new/#website',
        url: 'https://mathics24882.builtwithmathics.new',
        name: 'GateMathics',
        description:
          'Free GATE CS preparation platform with ranked quizzes, practice sessions, and AI-powered question generation.',
        inLanguage: 'en-IN',
        potentialAction: {
          '@type': 'SearchAction',
          target: {
            '@type': 'EntryPoint',
            urlTemplate: 'https://mathics24882.builtwithmathics.new/practice?q={search_term_string}',
          },
          'query-input': 'required name=search_term_string',
        },
      },
      {
        '@type': 'EducationalOrganization',
        '@id': 'https://mathics24882.builtwithmathics.new/#org',
        name: 'GateMathics',
        url: 'https://mathics24882.builtwithmathics.new',
        description:
          'GateMathics is a free GATE CS preparation platform offering ranked quizzes, topic-wise practice, and performance analytics for GATE Computer Science aspirants.',
        sameAs: [],
        contactPoint: {
          '@type': 'ContactPoint',
          contactType: 'customer support',
          email: 'support@gatemathics.com',
          availableLanguage: 'English',
        },
      },
      {
        '@type': 'FAQPage',
        mainEntity: [
          {
            '@type': 'Question',
            name: 'Is GateMathics free to use?',
            acceptedAnswer: {
              '@type': 'Answer',
              text: 'Yes, GateMathics is completely free. The platform is supported by non-intrusive Google AdSense advertisements.',
            },
          },
          {
            '@type': 'Question',
            name: 'Which GATE CS topics does GateMathics cover?',
            acceptedAnswer: {
              '@type': 'Answer',
              text: 'GateMathics covers the complete GATE CS syllabus including Data Structures, Algorithms, Operating Systems, DBMS, Computer Networks, Theory of Computation, Compiler Design, Digital Logic, Computer Organization, and Engineering Mathematics.',
            },
          },
          {
            '@type': 'Question',
            name: 'How does the ranked mode work?',
            acceptedAnswer: {
              '@type': 'Answer',
              text: 'In Ranked Mode, you answer GATE CS questions to earn or lose LP (League Points). Your LP determines your rank tier — from Bronze to Grandmaster. Each correct answer earns LP and each wrong answer deducts LP.',
            },
          },
        ],
      },
    ],
  };

  return (
    <script
      type="application/ld+json"
      dangerouslySetInnerHTML={{ __html: JSON.stringify(schema) }}
    />
  );
}
