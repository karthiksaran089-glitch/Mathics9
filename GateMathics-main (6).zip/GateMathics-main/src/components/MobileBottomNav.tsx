'use client';
import React from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { Home, Trophy, BookOpen, BarChart3, User } from 'lucide-react';

const mobileNavItems = [
  { key: 'mob-home', href: '/home-dashboard', icon: Home, label: 'Home' },
  { key: 'mob-ranked', href: '/ranked-mode-screen', icon: Trophy, label: 'Ranked' },
  { key: 'mob-practice', href: '/practice', icon: BookOpen, label: 'Practice' },
  { key: 'mob-analytics', href: '/analytics', icon: BarChart3, label: 'Analytics' },
  { key: 'mob-profile', href: '/profile', icon: User, label: 'Profile' },
];

export default function MobileBottomNav() {
  const pathname = usePathname();

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-30 bg-card/95 backdrop-blur-sm border-t border-border md:hidden" style={{ paddingBottom: 'env(safe-area-inset-bottom, 0px)' }}>
      <div className="flex items-center justify-around h-14 px-1">
        {mobileNavItems.map((item) => {
          const NavIcon = item.icon;
          const isActive =
            pathname === item.href ||
            (item.href === '/home-dashboard' && pathname === '/') ||
            (item.href !== '/home-dashboard' && pathname?.startsWith(item.href));
          return (
            <Link
              key={item.key}
              href={item.href}
              className={`flex flex-col items-center justify-center gap-0.5 flex-1 py-1.5 transition-colors ${
                isActive ? 'text-primary' : 'text-muted-foreground hover:text-foreground'
              }`}
            >
              <NavIcon size={19} strokeWidth={isActive ? 2.5 : 1.8} />
              <span className={`text-[9px] font-semibold ${isActive ? 'text-primary' : ''}`}>
                {item.label}
              </span>
            </Link>
          );
        })}
      </div>
    </nav>
  );
}
