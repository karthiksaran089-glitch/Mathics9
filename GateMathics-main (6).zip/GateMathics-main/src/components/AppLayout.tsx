'use client';
import React, { useState, useEffect } from 'react';
import AppSidebar from './AppSidebar';
import MobileBottomNav from './MobileBottomNav';
import Toast from '@/components/ui/Toast';

interface AppLayoutProps {
  children: React.ReactNode;
}

export default function AppLayout({ children }: AppLayoutProps) {
  const [collapsed, setCollapsed] = useState(false);
  const [theme, setTheme] = useState<'dark' | 'light'>('dark');

  // Sync theme state with the actual DOM class on mount
  useEffect(() => {
    const saved = localStorage.getItem('theme') as 'dark' | 'light' | null;
    const initial = saved ?? 'dark';
    setTheme(initial);
    if (initial === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, []);

  const handleThemeToggle = () => {
    const newTheme = theme === 'dark' ? 'light' : 'dark';
    setTheme(newTheme);
    localStorage.setItem('theme', newTheme);
    if (newTheme === 'light') {
      document.documentElement.classList.remove('dark');
    } else {
      document.documentElement.classList.add('dark');
    }
  };

  return (
    <div className="flex h-screen overflow-hidden bg-background">
      {/* Sidebar: hidden on mobile, visible on md+ */}
      <div className="hidden md:flex">
        <AppSidebar
          collapsed={collapsed}
          onToggle={() => setCollapsed(!collapsed)}
          theme={theme}
          onThemeToggle={handleThemeToggle}
        />
      </div>
      {/* Main content: add pb-16 on mobile to account for bottom nav */}
      <main className="flex-1 overflow-y-auto scrollbar-thin pb-16 md:pb-0">
        {children}
      </main>
      {/* Mobile bottom nav */}
      <MobileBottomNav />
      <Toast />
    </div>
  );
}