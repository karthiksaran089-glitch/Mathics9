'use client';
import React, { useEffect, useState, useRef, useCallback } from 'react';
import type { LevelInfo, TierInfo } from '@/lib/gamification';
import type { BadgeDefinition } from '@/lib/gamification';

// ─── Confetti Particle ────────────────────────────────────────────────────────

interface Particle {
  id: number;
  x: number;
  y: number;
  rotation: number;
  color: string;
  size: number;
  speedX: number;
  speedY: number;
  rotationSpeed: number;
  opacity: number;
}

function ConfettiCanvas() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const particlesRef = useRef<Particle[]>([]);
  const rafRef = useRef<number>(0);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;

    const colors = ['#7C3AED', '#A78BFA', '#F59E0B', '#FCD34D', '#10B981', '#06B6D4', '#EC4899', '#F9A8D4'];
    const particles: Particle[] = [];

    for (let i = 0; i < 80; i++) {
      particles.push({
        id: i,
        x: Math.random() * canvas.width,
        y: -20 - Math.random() * 200,
        rotation: Math.random() * 360,
        color: colors[Math.floor(Math.random() * colors.length)],
        size: 4 + Math.random() * 8,
        speedX: (Math.random() - 0.5) * 4,
        speedY: 2 + Math.random() * 4,
        rotationSpeed: (Math.random() - 0.5) * 8,
        opacity: 1,
      });
    }
    particlesRef.current = particles;

    const animate = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      let alive = false;

      for (const p of particlesRef.current) {
        p.x += p.speedX;
        p.y += p.speedY;
        p.rotation += p.rotationSpeed;
        p.speedY += 0.08; // gravity
        if (p.y > canvas.height * 0.7) {
          p.opacity -= 0.02;
        }
        if (p.opacity <= 0) continue;
        alive = true;

        ctx.save();
        ctx.translate(p.x, p.y);
        ctx.rotate((p.rotation * Math.PI) / 180);
        ctx.globalAlpha = Math.max(0, p.opacity);
        ctx.fillStyle = p.color;
        ctx.fillRect(-p.size / 2, -p.size / 4, p.size, p.size / 2);
        ctx.restore();
      }

      if (alive) {
        rafRef.current = requestAnimationFrame(animate);
      }
    };

    rafRef.current = requestAnimationFrame(animate);

    return () => cancelAnimationFrame(rafRef.current);
  }, []);

  return (
    <canvas
      ref={canvasRef}
      className="absolute inset-0 pointer-events-none z-10"
      style={{ width: '100%', height: '100%' }}
    />
  );
}

// ─── Level Up Modal ───────────────────────────────────────────────────────────

interface LevelUpModalProps {
  previousLevel: number;
  newLevelInfo: LevelInfo;
  newBadges?: BadgeDefinition[];
  onClose: () => void;
}

export default function LevelUpModal({ previousLevel, newLevelInfo, newBadges = [], onClose }: LevelUpModalProps) {
  const [stage, setStage] = useState(0); // 0=enter, 1=show, 2=exit
  const timerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    // Animate in
    requestAnimationFrame(() => setStage(1));

    // Auto-dismiss after 5 seconds
    timerRef.current = setTimeout(() => {
      setStage(2);
      setTimeout(onClose, 400);
    }, 5000);

    return () => {
      if (timerRef.current) clearTimeout(timerRef.current);
    };
  }, [onClose]);

  const handleClick = useCallback(() => {
    if (timerRef.current) clearTimeout(timerRef.current);
    setStage(2);
    setTimeout(onClose, 400);
  }, [onClose]);

  const { level, tier, progressPct, xpInLevel, xpToNext } = newLevelInfo;

  return (
    <div
      className={`fixed inset-0 z-[9998] flex items-center justify-center transition-all duration-400 cursor-pointer ${
        stage === 1 ? 'opacity-100' : 'opacity-0'
      }`}
      onClick={handleClick}
    >
      {/* Backdrop */}
      <div className="absolute inset-0 bg-black/80 backdrop-blur-md" />

      {/* Confetti */}
      {stage === 1 && <ConfettiCanvas />}

      {/* Content */}
      <div
        className={`relative z-20 flex flex-col items-center text-center px-6 transition-all duration-500 ${
          stage === 1 ? 'scale-100 translate-y-0' : 'scale-90 translate-y-8'
        }`}
      >
        {/* Level badge */}
        <div
          className="w-28 h-28 rounded-3xl flex items-center justify-center mb-6"
          style={{
            background: tier.gradient,
            boxShadow: `0 0 60px ${tier.color}66, 0 0 120px ${tier.color}33`,
            animation: stage === 1 ? 'levelPulse 2s ease-in-out infinite' : 'none',
          }}
        >
          <span className="text-5xl font-extrabold text-white drop-shadow-lg font-mono-data">
            {level}
          </span>
        </div>

        {/* Title */}
        <p className="text-sm font-semibold text-muted-foreground mb-1 tracking-widest uppercase">
          Level Up!
        </p>
        <h1
          className="text-4xl font-extrabold mb-2"
          style={{
            background: tier.gradient,
            WebkitBackgroundClip: 'text',
            WebkitTextFillColor: 'transparent',
            backgroundClip: 'text',
          }}
        >
          {tier.emoji} {tier.name} {level}
        </h1>
        <p className="text-sm text-muted-foreground mb-6">
          Level {previousLevel} → Level {level}
        </p>

        {/* XP Progress bar */}
        <div className="w-72 mb-6">
          <div className="flex items-center justify-between mb-1.5">
            <span className="text-[11px] text-muted-foreground font-mono-data">XP Progress</span>
            <span className="text-[11px] text-muted-foreground font-mono-data">
              {xpInLevel} / {xpToNext}
            </span>
          </div>
          <div className="w-full h-2.5 rounded-full overflow-hidden" style={{ background: 'rgba(255,255,255,0.1)' }}>
            <div
              className="h-full rounded-full transition-all duration-1000 ease-out"
              style={{
                width: `${progressPct}%`,
                background: tier.gradient,
                boxShadow: `0 0 12px ${tier.color}66`,
              }}
            />
          </div>
        </div>

        {/* New badges */}
        {newBadges.length > 0 && (
          <div className="mb-6">
            <p className="text-xs font-semibold text-muted-foreground uppercase tracking-widest mb-3">
              🏅 New Badges Unlocked
            </p>
            <div className="flex items-center gap-3 justify-center">
              {newBadges.map((badge) => (
                <div
                  key={badge.id}
                  className="flex flex-col items-center gap-1.5 px-4 py-3 rounded-xl border"
                  style={{
                    borderColor: `${badge.color}40`,
                    background: `${badge.color}15`,
                    boxShadow: `0 0 20px ${badge.glowColor}`,
                  }}
                >
                  <span className="text-2xl">{badge.emoji}</span>
                  <span className="text-[11px] font-bold" style={{ color: badge.color }}>
                    {badge.name}
                  </span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Dismiss hint */}
        <p className="text-xs text-muted-foreground/60">Tap anywhere to continue</p>
      </div>
    </div>
  );
}
