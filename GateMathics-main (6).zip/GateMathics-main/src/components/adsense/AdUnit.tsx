'use client';

import { useEffect, useRef, useState, useCallback } from 'react';
import type { AdSenseProps } from '@/types/adsense';

interface AdUnitProps extends AdSenseProps {
  label?: string;
}

const AdUnit: React.FC<AdUnitProps> = ({
  adClient,
  adSlot,
  adFormat = 'auto',
  adLayout,
  adStyle = {},
  className = '',
  label = 'Advertisement',
}) => {
  const adRef = useRef<HTMLModElement>(null);
  const [initialized, setInitialized] = useState(false);
  const [hasError, setHasError] = useState(false);
  const observerRef = useRef<IntersectionObserver | null>(null);

  const initAd = useCallback(() => {
    if (initialized || hasError || !adRef.current) return;
    if (typeof window === 'undefined' || !window.adsbygoogle) return;

    const el = adRef.current;
    if (el.getAttribute('data-adsbygoogle-status')) {
      setInitialized(true);
      return;
    }

    try {
      (window.adsbygoogle = window.adsbygoogle || []).push({});
      setInitialized(true);
    } catch {
      setHasError(true);
    }
  }, [initialized, hasError]);

  useEffect(() => {
    if (typeof window === 'undefined') return;

    observerRef.current = new IntersectionObserver(
      (entries) => {
        if (entries[0]?.isIntersecting) {
          observerRef.current?.disconnect();
          initAd();
        }
      },
      { rootMargin: '200px', threshold: 0.01 }
    );

    if (adRef.current) {
      observerRef.current.observe(adRef.current);
    }

    return () => observerRef.current?.disconnect();
  }, [initAd]);

  if (hasError) return null;

  return (
    <div className={`w-full overflow-hidden ${className}`} aria-label={label}>
      <p className="text-[10px] text-muted-foreground text-center mb-1 uppercase tracking-widest select-none">
        {label}
      </p>
      <ins
        ref={adRef as React.RefObject<HTMLModElement>}
        className="adsbygoogle block"
        style={{ display: 'block', minHeight: '90px', ...adStyle }}
        data-ad-client={adClient}
        data-ad-slot={adSlot}
        data-ad-format={adFormat}
        data-ad-layout={adLayout}
        data-full-width-responsive="true"
      />
    </div>
  );
};

export default AdUnit;
