'use client';
import { useEffect, useState, useRef, useCallback } from 'react';
import { usePathname, useRouter } from 'next/navigation';

export default function PageTransitionLoader() {
  const pathname = usePathname();
  const router = useRouter();
  const [visible, setVisible] = useState(false);
  const [progress, setProgress] = useState(0);
  const prevPathname = useRef(pathname);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const hideTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  // Track whether a navigation is in-flight to avoid ghost bars
  const navigatingRef = useRef(false);

  const startProgress = useCallback(() => {
    if (hideTimerRef.current) clearTimeout(hideTimerRef.current);
    if (timerRef.current) clearInterval(timerRef.current);
    navigatingRef.current = true;
    setProgress(10);
    setVisible(true);
    let p = 10;
    // Use a slightly faster tick (150ms) for snappier feel
    timerRef.current = setInterval(() => {
      // Ease-out: large jumps early, tiny increments near 85
      const remaining = 85 - p;
      const step = Math.max(1, Math.random() * remaining * 0.25);
      p = Math.min(85, p + step);
      setProgress(Math.round(p));
      if (p >= 85 && timerRef.current) {
        clearInterval(timerRef.current);
        timerRef.current = null;
      }
    }, 150);
  }, []);

  const completeProgress = useCallback(() => {
    if (!navigatingRef.current) return;
    navigatingRef.current = false;
    if (timerRef.current) { clearInterval(timerRef.current); timerRef.current = null; }
    setProgress(100);
    hideTimerRef.current = setTimeout(() => {
      setVisible(false);
      setProgress(0);
    }, 300);
  }, []);

  // Detect pathname change → complete the bar
  useEffect(() => {
    if (prevPathname.current !== pathname) {
      completeProgress();
      prevPathname.current = pathname;
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [pathname]);

  // Intercept all anchor/Link clicks to start the bar
  useEffect(() => {
    const handleClick = (e: MouseEvent) => {
      const target = (e.target as HTMLElement).closest('a');
      if (!target) return;
      const href = target.getAttribute('href');
      if (!href) return;
      // Only internal same-origin links (not anchors, not external)
      if (href.startsWith('/') && !href.startsWith('//')) {
        // Don't trigger if same page
        if (href.split('?')[0] !== pathname) {
          startProgress();
        }
      }
    };
    document.addEventListener('click', handleClick, true);
    return () => {
      document.removeEventListener('click', handleClick, true);
      if (timerRef.current) clearInterval(timerRef.current);
      if (hideTimerRef.current) clearTimeout(hideTimerRef.current);
    };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [pathname, startProgress]);

  // Intercept programmatic router.push / router.replace calls
  useEffect(() => {
    const origPush = router.push;
    const origReplace = router.replace;

    router.push = (...args: Parameters<typeof origPush>) => {
      const target = typeof args[0] === 'string' ? args[0] : '';
      if (target.startsWith('/') && target.split('?')[0] !== pathname) {
        startProgress();
      }
      return origPush.apply(router, args);
    };

    router.replace = (...args: Parameters<typeof origReplace>) => {
      const target = typeof args[0] === 'string' ? args[0] : '';
      if (target.startsWith('/') && target.split('?')[0] !== pathname) {
        startProgress();
      }
      return origReplace.apply(router, args);
    };

    return () => {
      router.push = origPush;
      router.replace = origReplace;
    };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [pathname, startProgress]);

  if (!visible) return null;

  return (
    <div className="fixed top-0 left-0 right-0 z-[9999] h-[4px] pointer-events-none">
      <div
        className="h-full rounded-r-full relative"
        style={{
          width: `${progress}%`,
          background: 'linear-gradient(90deg, rgba(124,58,237,0.6) 0%, #7C3AED 50%, #A78BFA 100%)',
          boxShadow: '0 0 12px rgba(124,58,237,0.9), 0 0 4px rgba(167,139,250,0.6)',
          transition: progress === 100
            ? 'width 0.22s ease-out' : 'width 0.15s ease-in',
          willChange: 'width',
        }}
      >
        {/* Shimmer overlay */}
        <div
          className="absolute inset-0 rounded-r-full overflow-hidden"
          style={{
            background: 'linear-gradient(90deg, transparent 0%, rgba(255,255,255,0.3) 50%, transparent 100%)',
            backgroundSize: '200% 100%',
            animation: 'progressShimmer 1.5s linear infinite',
          }}
        />
        {/* Leading edge dot */}
        <div
          className="absolute right-0 top-1/2 -translate-y-1/2 w-3 h-3 rounded-full"
          style={{
            background: '#A78BFA',
            boxShadow: '0 0 8px rgba(167,139,250,0.9), 0 0 16px rgba(124,58,237,0.6)',
            animation: 'leadingDotPulse 1s ease-in-out infinite',
          }}
        />
      </div>
    </div>
  );
}
