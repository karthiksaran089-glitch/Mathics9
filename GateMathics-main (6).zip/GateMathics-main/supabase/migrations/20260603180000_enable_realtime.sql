-- Enable Supabase Realtime for specific tables
begin;
  -- Remove the supabase_realtime publication if it exists to recreate it
  drop publication if exists supabase_realtime;
  
  -- Create the publication
  create publication supabase_realtime;
commit;

-- Add tables to the publication
alter publication supabase_realtime add table public.user_profiles;
alter publication supabase_realtime add table public.ranked_sessions;
alter publication supabase_realtime add table public.practice_sessions;

-- Ensure replica identity is set to DEFAULT or FULL so updates send changes
alter table public.user_profiles replica identity full;
alter table public.ranked_sessions replica identity default;
alter table public.practice_sessions replica identity default;
