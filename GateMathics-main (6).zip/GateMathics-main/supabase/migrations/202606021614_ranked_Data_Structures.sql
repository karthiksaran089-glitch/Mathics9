-- ==========================================
-- Ranked Questions: Data Structures
-- ==========================================

INSERT INTO public.ranked_questions
  (topic, difficulty, time_limit, question, option_a, option_b, option_c, option_d, correct_index, explanation)
VALUES
(
    'Data Structures', 'Easy', 45,
    'In a singly linked list, inserting a node at the beginning (head) has time complexity:',
    'O(n)', 'O(log n)', 'O(1)', 'O(n log n)',
    2,
    'Inserting at the head of a singly linked list is O(1) because it only requires creating the new node, setting its next pointer to the current head, and updating the head pointer — a constant number of operations regardless of list size.'
  ),
(
    'Data Structures', 'Easy', 45,
    'Which data structure follows the Last-In-First-Out (LIFO) principle?',
    'Queue', 'Stack', 'Deque', 'Priority Queue',
    1,
    'A stack follows LIFO — the last element pushed onto the stack is the first one to be popped. Stacks are used in function call management, expression evaluation, and backtracking algorithms.'
  ),
(
    'Data Structures', 'Medium', 60,
    'In a Binary Search Tree (BST), the inorder traversal yields elements in:',
    'Random order', 'Descending sorted order', 'Ascending sorted order', 'Level-by-level order',
    2,
    'Inorder traversal of a BST visits the left subtree, then the root, then the right subtree. Since BST maintains the property that left < root < right, inorder traversal always produces elements in ascending sorted order.'
  ),
(
    'Data Structures', 'Hard', 90,
    'A B-Tree of order m has the property that every non-root internal node has at least:',
    'm children', '⌈m/2⌉ children', 'm-1 children', '2 children',
    1,
    'In a B-Tree of order m, every non-root internal node must have at least ⌈m/2⌉ children (and at most m children). This ensures the tree remains balanced and guarantees O(log n) search time.'
  ),
(
    'Data Structures', 'Medium', 60,
    'What is the time complexity of searching for an element in a balanced BST with n nodes?',
    'O(n)', 'O(log n)', 'O(1)', 'O(n log n)',
    1,
    'In a balanced BST (like AVL or Red-Black tree), the height is O(log n). Each search step eliminates half the remaining nodes, so searching takes O(log n) comparisons in the worst case.'
  ),
(
    'Data Structures', 'Hard', 90,
    'In a hash table using chaining with n elements and m buckets, what is the expected time for a successful search assuming uniform hashing?',
    'O(1 + n/m)', 'O(n/m)', 'O(log(n/m))', 'O(n)',
    0,
    'With uniform hashing (load factor α = n/m), a successful search examines 1 + α/2 elements on average (half the chain plus the target). This is Θ(1 + n/m). When n = O(m), this is O(1) amortized.'
  ),
(
    'Data Structures', 'Easy', 45,
    'Which traversal of a binary tree visits the root first, then left subtree, then right subtree?',
    'Inorder', 'Postorder', 'Preorder', 'Level-order',
    2,
    'Preorder traversal visits: Root → Left subtree → Right subtree. It is used in tree copying and expression tree prefix notation. Inorder is Left→Root→Right, Postorder is Left→Right→Root.'
  ),
(
    'Data Structures', 'Medium', 75,
    'A circular queue of size n can hold at most how many elements to distinguish between full and empty states (without extra variable)?',
    'n', 'n-1', 'n+1', 'n/2',
    1,
    'In a circular queue implemented with an array of size n using only front and rear pointers, at most n-1 elements can be stored. One slot is kept empty to differentiate between full state (rear+1 = front) and empty state (rear = front).'
  ),
(
    'Data Structures', 'Hard', 90,
    'A Fibonacci heap supports decrease-key in amortized O(1) time. This makes it superior to binary heaps for which algorithm?',
    'Merge Sort', 'Dijkstra''s Shortest Path', 'Binary Search', 'Depth-First Search',
    1,
    'Dijkstra''s algorithm calls decrease-key frequently. With a binary heap, decrease-key is O(log n). A Fibonacci heap''s amortized O(1) decrease-key reduces Dijkstra''s total complexity from O((V+E) log V) to O(V log V + E).'
  ),
(
    'Data Structures', 'Medium', 60,
    'What is the height of a complete binary tree with n nodes?',
    '⌊log₂ n⌋', '⌈log₂ n⌉', 'n-1', 'n/2',
    0,
    'A complete binary tree with n nodes has height ⌊log₂ n⌋. At each level i (from root), there are 2^i nodes. With n nodes total, the height is the floor of log base 2 of n.'
  ),
(
    'Data Structures', 'Easy', 45,
    'In a max-heap, the maximum element is always located at:',
    'A leaf node', 'The root', 'The last node', 'The second level',
    1,
    'In a max-heap, the heap property ensures every parent is greater than or equal to its children. Therefore, the maximum element is always at the root (index 0 in array representation), accessible in O(1) time.'
  ),
(
    'Data Structures', 'Hard', 90,
    'A Skip List provides expected O(log n) search time by:',
    'Using a balanced tree structure internally', 'Maintaining multiple linked lists at different levels, with each level skipping over more elements',
    'Using binary search on a sorted array', 'Hashing elements to sorted buckets',
    1,
    'A Skip List is a probabilistic data structure with multiple layers of linked lists. Higher layers have fewer nodes (each node appears in the next level with probability p, typically 0.5). Searching starts at the top (most sparse) layer and drops down, achieving expected O(log n) search, insertion, and deletion.'
  ),
(
    'Data Structures', 'Medium', 60,
    'In a graph represented as an adjacency list, the space complexity is:',
    'O(V²)', 'O(V + E)', 'O(E²)', 'O(V × E)',
    1,
    'Adjacency list representation stores one list per vertex (V lists total) where each list contains the adjacent vertices. Total space = O(V) for the array + O(E) for all edges across all lists = O(V + E). For sparse graphs, this is much more efficient than the O(V²) adjacency matrix.'
  ),
(
    'Data Structures', 'Hard', 90,
    'In an open addressing hash table with quadratic probing, a primary disadvantage is:',
    'Higher space usage than chaining', 'Deletion is impossible', 'Primary clustering around frequently-used hash locations',
    'Secondary clustering where keys with the same hash follow the same probe sequence',
    3,
    'Quadratic probing (h(k) + i², h(k) + 2i², ...) eliminates primary clustering (consecutive slots) seen in linear probing. However, it suffers from secondary clustering: all keys hashing to the same initial slot follow the identical probe sequence, regardless of their actual key values.'
  ),
(
    'Data Structures', 'Medium', 60,
    'Which of the following operations is most efficient with a doubly-linked list compared to a singly-linked list?',
    'Sequential traversal from head', 'Deletion of a node given a pointer to that node (O(1) vs O(n))',
    'Random access to the k-th element', 'Searching for a specific value',
    1,
    'With a doubly-linked list, given a pointer to a node, you can delete it in O(1) by updating both its predecessor''s next and successor''s prev pointers. In a singly-linked list, you must traverse from the head to find the predecessor, taking O(n) time.'
  ),
(
    'Data Structures', 'Easy', 45,
    'What is the time complexity of inserting an element into a sorted array of n elements while maintaining sorted order?',
    'O(1)', 'O(log n)', 'O(n)', 'O(n log n)',
    2,
    'Inserting into a sorted array requires: finding the correct position (O(log n) with binary search), then shifting all larger elements one position right (O(n)). The dominant term is O(n) for the shifting operation, making overall complexity O(n).'
  ),
(
    'Data Structures', 'Hard', 90,
    'The Union-Find (Disjoint Set Union) data structure with path compression and union by rank has amortized time complexity per operation of:',
    'O(log n)', 'O(1)', 'O(α(n)) — inverse Ackermann function, effectively constant', 'O(n)',
    2,
    'With both path compression (flattening tree during find) and union by rank (attaching smaller tree under larger), Union-Find achieves amortized O(α(n)) per operation, where α is the inverse Ackermann function. For all practical values of n, α(n) ≤ 4, making it essentially O(1) amortized.'
  );
