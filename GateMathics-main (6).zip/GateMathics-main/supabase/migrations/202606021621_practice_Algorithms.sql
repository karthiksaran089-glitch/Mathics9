-- ==========================================
-- Practice Questions: Algorithms
-- ==========================================

INSERT INTO public.practice_questions
  (topic, difficulty, time_limit, question, option_a, option_b, option_c, option_d, correct_index, explanation, hint)
VALUES
(
    'Algorithms', 'Medium', 60,
    'What is the time complexity of building a max-heap from an unsorted array of n elements using the standard bottom-up heapify algorithm?',
    'O(n log n)', 'O(n)', 'O(log n)', 'O(n²)',
    1,
    'Building a heap from an unsorted array using bottom-up heapify runs in O(n) time. Although each individual sift-down is O(log n), most elements are near the leaves and require only O(1) work.',
    'Think about how many nodes are at each level of the heap and how much work each sift-down requires at that level.'
  ),
(
    'Algorithms', 'Easy', 45,
    'What is the time complexity of binary search on a sorted array of n elements?',
    'O(n)', 'O(log n)', 'O(n log n)', 'O(1)',
    1,
    'Binary search repeatedly divides the search space in half. With n elements, it takes at most ⌊log₂ n⌋ + 1 comparisons, giving O(log n) time complexity.',
    'How many times can you divide n by 2 before reaching 1? That is your answer in terms of logarithms.'
  ),
(
    'Algorithms', 'Medium', 60,
    'Which of the following sorting algorithms has the best worst-case time complexity?',
    'Quick Sort', 'Merge Sort', 'Insertion Sort', 'Selection Sort',
    1,
    'Merge Sort has a worst-case time complexity of O(n log n) for all inputs. Quick Sort degrades to O(n²) in the worst case (e.g., always picking smallest element as pivot). Insertion and Selection Sort are O(n²) worst case.',
    'Think about which algorithm always divides the problem into equal halves regardless of input.'
  ),
(
    'Algorithms', 'Hard', 90,
    'In Dijkstra''s algorithm using a binary min-heap, what is the time complexity for a graph with V vertices and E edges?',
    'O(V²)', 'O(E log V)', 'O((V + E) log V)', 'O(VE)',
    2,
    'With a binary min-heap, Dijkstra performs V extract-min operations (O(V log V)) and E decrease-key operations (O(E log V)), giving total O((V + E) log V). With a Fibonacci heap, decrease-key is O(1) amortized, giving O(V log V + E).',
    'Count the total number of extract-min and decrease-key operations separately, then multiply by the cost of each heap operation.'
  ),
(
    'Algorithms', 'Medium', 60,
    'What is the key difference between Greedy algorithms and Dynamic Programming?',
    'Greedy always gives optimal solutions; DP does not',
    'Greedy makes locally optimal choices without reconsidering; DP solves overlapping subproblems and uses memoization',
    'DP is always faster than Greedy', 'Greedy requires more memory than DP',
    1,
    'Greedy algorithms make the locally optimal choice at each step and never reconsider, which may not always yield the global optimum. DP solves overlapping subproblems optimally by storing results (memoization/tabulation) and guarantees global optimality through the principle of optimal substructure.',
    'Ask yourself: does making the best local choice at each step guarantee the best overall solution?'
  ),
(
    'Algorithms', 'Hard', 90,
    'The Floyd-Warshall algorithm for all-pairs shortest paths uses which algorithmic technique?',
    'Greedy with priority queue', 'Divide and conquer', 'Dynamic programming with intermediate vertex relaxation', 'Breadth-first search from each vertex',
    2,
    'Floyd-Warshall uses DP: dp[i][j][k] = shortest path from i to j using only vertices {1,...,k} as intermediates. For each k, we check if going through vertex k improves the path. The recurrence is dp[i][j][k] = min(dp[i][j][k-1], dp[i][k][k-1] + dp[k][j][k-1]).',
    'Think about what changes as you increase the set of allowed intermediate vertices from 0 to V.'
  ),
(
    'Algorithms', 'Easy', 45,
    'Which data structure is used in Breadth-First Search (BFS) to track nodes to visit?',
    'Stack', 'Queue', 'Priority Queue', 'Hash Table',
    1,
    'BFS uses a Queue (FIFO) to ensure nodes are visited level by level. When a node is dequeued, its unvisited neighbors are enqueued. DFS uses a Stack (LIFO) or recursion.',
    'BFS explores level by level. Which data structure processes items in the order they were added?'
  ),
(
    'Algorithms', 'Hard', 90,
    'In the 0/1 Knapsack problem with n items and knapsack capacity W, what is the time complexity of the standard DP solution?',
    'O(n + W)', 'O(n × W)', 'O(n² × W)', 'O(2ⁿ)',
    1,
    'The standard DP solution creates an (n+1) × (W+1) table. Each cell dp[i][w] takes O(1) to compute. Total cells = (n+1)(W+1), giving O(n × W) time and space. Note: this is pseudo-polynomial (W can be exponential in the number of bits used to represent it).',
    'Think about the size of the DP table — it has one row per item and one column per capacity value from 0 to W.'
  ),
(
    'Algorithms', 'Medium', 75,
    'In Kruskal''s algorithm for Minimum Spanning Tree, edges are processed in which order?',
    'In decreasing order of weight', 'In increasing order of weight', 'In random order', 'In order of vertex degree',
    1,
    'Kruskal''s algorithm sorts all edges by weight in increasing (non-decreasing) order and greedily adds each edge to the MST if it does not create a cycle. Cycle detection is done efficiently using Union-Find (DSU) data structure.',
    'Kruskal is greedy — it always picks the cheapest available edge that does not create a cycle.'
  ),
(
    'Algorithms', 'Hard', 90,
    'What does the Master Theorem Case 1 state for T(n) = aT(n/b) + f(n)?',
    'If f(n) = O(n^(log_b a - ε)), then T(n) = Θ(n^log_b a)',
    'If f(n) = Θ(n^log_b a), then T(n) = Θ(n^log_b a × log n)',
    'If f(n) = Ω(n^(log_b a + ε)), then T(n) = Θ(f(n))',
    'If f(n) = Θ(1), then T(n) = Θ(log n)',
    0,
    'Master Theorem Case 1: if f(n) = O(n^(log_b(a) - ε)) for some ε > 0 (f(n) grows slower than n^log_b(a)), then T(n) = Θ(n^log_b(a)). The recursive work dominates. Case 2: equal growth → Θ(n^log_b(a) log n). Case 3: f(n) dominates → Θ(f(n)).',
    'The Master Theorem compares f(n) with n^(log_b a). Which term dominates determines the case.'
  ),
(
    'Algorithms', 'Medium', 60,
    'What is the amortized time complexity of push and pop operations on a dynamic array (that doubles when full)?',
    'O(n) per operation', 'O(log n) per operation', 'O(1) amortized per operation', 'O(n log n) total',
    2,
    'Using the aggregate method: n operations cost at most 3n total (n pushes + doubling costs: 1+2+4+...+n ≈ 2n). Amortized cost = 3n/n = O(1) per operation. The occasional O(n) doubling cost is spread across all operations.',
    'The expensive doubling happens rarely. When you average the cost over all operations, each one is effectively O(1).'
  );
