-- ============================================================
-- GateMathics: Ranked Mode Question Bank
-- Fallback question table for Ranked Mode.
-- Used when the AI question generation engine fails, times out,
-- or is unavailable. Questions can be manually added, modified,
-- or deleted directly in this table.
-- ============================================================

-- 1. TABLE

CREATE TABLE IF NOT EXISTS public.ranked_questions (
  id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  topic        TEXT NOT NULL,
  difficulty   TEXT NOT NULL CHECK (difficulty IN ('Easy', 'Medium', 'Hard')),
  time_limit   INTEGER NOT NULL DEFAULT 60,   -- seconds
  question     TEXT NOT NULL,
  option_a     TEXT NOT NULL,
  option_b     TEXT NOT NULL,
  option_c     TEXT NOT NULL,
  option_d     TEXT NOT NULL,
  correct_index INTEGER NOT NULL CHECK (correct_index BETWEEN 0 AND 3),  -- 0=A,1=B,2=C,3=D
  explanation  TEXT NOT NULL DEFAULT '',
  is_active    BOOLEAN NOT NULL DEFAULT TRUE,
  created_at   TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
  updated_at   TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- 2. INDEXES
CREATE INDEX IF NOT EXISTS idx_ranked_questions_topic      ON public.ranked_questions(topic);
CREATE INDEX IF NOT EXISTS idx_ranked_questions_difficulty ON public.ranked_questions(difficulty);
CREATE INDEX IF NOT EXISTS idx_ranked_questions_is_active  ON public.ranked_questions(is_active);

-- 3. UPDATED_AT TRIGGER
CREATE OR REPLACE FUNCTION public.update_ranked_questions_updated_at()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_ranked_questions_updated_at ON public.ranked_questions;
CREATE TRIGGER trg_ranked_questions_updated_at
  BEFORE UPDATE ON public.ranked_questions
  FOR EACH ROW EXECUTE FUNCTION public.update_ranked_questions_updated_at();

-- 4. ENABLE RLS
ALTER TABLE public.ranked_questions ENABLE ROW LEVEL SECURITY;

-- Authenticated users can read active questions
DROP POLICY IF EXISTS "ranked_questions_select_active" ON public.ranked_questions;
CREATE POLICY "ranked_questions_select_active"
ON public.ranked_questions
FOR SELECT
TO authenticated
USING (is_active = TRUE);

-- Anon (guests) can also read active questions
DROP POLICY IF EXISTS "ranked_questions_select_active_anon" ON public.ranked_questions;
CREATE POLICY "ranked_questions_select_active_anon"
ON public.ranked_questions
FOR SELECT
TO anon
USING (is_active = TRUE);

-- 5. SEED DATA — 10 GATE CS questions for Ranked Mode
-- You can manually INSERT / UPDATE / DELETE rows here at any time.

