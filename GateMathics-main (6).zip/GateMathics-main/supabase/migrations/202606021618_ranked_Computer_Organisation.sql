-- ==========================================
-- Ranked Questions: Computer Organisation
-- ==========================================

INSERT INTO public.ranked_questions
  (topic, difficulty, time_limit, question, option_a, option_b, option_c, option_d, correct_index, explanation)
VALUES
(
    'Computer Organisation', 'Hard', 75,
    'In a direct-mapped cache with 16 cache lines and block size of 4 words, what is the cache line number for memory address 0x2C (decimal 44)?',
    '3', '11', '2', '7',
    1,
    'For address 44 (binary: 101100): block offset = lower 2 bits = 00. Cache index = next 4 bits = 1011 = 11 in decimal. So the cache line number is 11.'
  ),
(
    'Computer Organisation', 'Easy', 45,
    'What is the function of the Memory Address Register (MAR) in a CPU?',
    'Stores the data to be written to or read from memory', 'Holds the address of the memory location to be accessed', 'Stores the current instruction being executed', 'Holds the result of arithmetic operations',
    1,
    'The MAR (Memory Address Register) holds the address of the memory location that the CPU wants to read from or write to. It is connected directly to the address bus. The MDR (Memory Data Register) holds the actual data being transferred.'
  ),
(
    'Computer Organisation', 'Medium', 60,
    'In a 2-level page table system with a 32-bit address space, 4KB pages, and 10-bit page table indices, what is the size of a page table entry if the second-level page table has 2^10 entries?',
    '1 byte', '2 bytes', '4 bytes', '8 bytes',
    2,
    'With 32-bit address space and 4KB (2^12) pages, there are 2^20 pages total. With 10-bit first-level index and 10-bit second-level index, second-level tables have 2^10 = 1024 entries. Standard 32-bit systems use 4-byte PTE (storing 20-bit frame number + permission bits).'
  ),
(
    'Computer Organisation', 'Hard', 90,
    'In a processor with a 5-stage pipeline, if a data hazard requires a 2-cycle stall, what is the effective CPI assuming no other hazards and a base CPI of 1?',
    '1.5', '2', '3', '2.5',
    2,
    'Each stall cycle adds 1 to the CPI. A 2-cycle stall means the pipeline inserts 2 "bubble" (NOP) cycles for the affected instruction. Effective CPI = base CPI + stall cycles = 1 + 2 = 3. This assumes every instruction experiences the stall.'
  ),
(
    'Computer Organisation', 'Medium', 75,
    'What is the advantage of a write-through cache policy over write-back?',
    'Better performance due to fewer memory accesses', 'Simpler design and always consistent data between cache and main memory',
    'Uses less memory bandwidth', 'Requires no cache invalidation on multiprocessor systems',
    1,
    'Write-through immediately writes every cache update to main memory, keeping cache and main memory always consistent. This simplifies cache management and avoids data loss on power failure. Disadvantage: uses more memory bandwidth than write-back.'
  ),
(
    'Computer Organisation', 'Easy', 45,
    'What does RISC stand for, and what is its key architectural philosophy?',
    'Rapid Instruction Set Computing; maximize instruction complexity', 'Reduced Instruction Set Computing; simple instructions that execute in one clock cycle',
    'Registered Instruction Set Computing; use registers for all operations', 'Reliable Instruction Set Computing; error-correcting instructions',
    1,
    'RISC (Reduced Instruction Set Computing) uses a small set of simple, fixed-length instructions designed to execute in a single clock cycle. Key features: load-store architecture, large register files, hardwired control, and deep pipelining for high throughput.'
  ),
(
    'Computer Organisation', 'Hard', 90,
    'In cache memory, the "miss penalty" refers to:',
    'The number of cache misses per 1000 instructions', 'The additional time required to fetch data from the next level of memory hierarchy on a cache miss',
    'The performance penalty for using a direct-mapped cache', 'The energy cost of cache accesses',
    1,
    'Miss penalty is the extra time (cycles or nanoseconds) needed to service a cache miss by fetching the data from the next memory level (L2 cache, L3 cache, or main memory). AMAT = hit time + miss rate × miss penalty.'
  ),
(
    'Computer Organisation', 'Medium', 60,
    'Which bus arbitration scheme gives each device a fixed priority and grants bus access to the highest-priority device requesting it?',
    'Round-robin arbitration', 'Daisy-chain arbitration', 'Fixed-priority arbitration', 'FIFO arbitration',
    2,
    'Fixed-priority (static priority) arbitration always grants bus access to the highest-priority requesting device. Simple to implement but can cause starvation of low-priority devices if high-priority devices continuously request the bus.'
  ),
(
    'Computer Organisation', 'Hard', 90,
    'In a processor using Tomasulo''s algorithm, "register renaming" solves which type of data hazard?',
    'True data dependence (RAW hazard)', 'WAW (Write After Write) and WAR (Write After Read) hazards',
    'Structural hazards', 'Control hazards',
    1,
    'Tomasulo''s algorithm uses reservation stations to rename registers dynamically, eliminating false dependencies: WAR (Write After Read) and WAW (Write After Write) hazards. True dependencies (RAW) still require waiting for data to be computed.'
  ),
(
    'Computer Organisation', 'Medium', 75,
    'Pipelining improves CPU throughput by:',
    'Reducing the number of instructions executed', 'Overlapping execution of multiple instructions in different pipeline stages simultaneously',
    'Increasing the clock speed of the processor', 'Reducing the number of pipeline stages',
    1,
    'Pipelining overlaps the execution of multiple instructions: while instruction N is in the Execute stage, instruction N+1 is in the Decode stage, and N+2 is being Fetched. This parallelism improves throughput (instructions per second) without increasing clock speed.'
  ),
(
    'Computer Organisation', 'Hard', 90,
    'In VLIW (Very Long Instruction Word) architecture, instruction-level parallelism is achieved by:',
    'Hardware dynamically scheduling multiple operations at runtime', 'The compiler statically packing multiple independent operations into one long instruction word',
    'Using multiple CPUs executing the same instruction', 'Speculatively executing both branches of a conditional',
    1,
    'VLIW architecture uses very wide instruction words (e.g., 128 or 256 bits) containing multiple operation slots. The compiler (not hardware) is responsible for finding independent operations and packing them into a single VLIW instruction. The hardware executes all slots in parallel every cycle, requiring no dynamic scheduling logic.'
  ),
(
    'Computer Organisation', 'Medium', 60,
    'In a processor, the "fetch-decode-execute" cycle describes:',
    'The process of loading programs from disk to memory', 'The basic sequence of operations a CPU performs to execute each instruction: fetch instruction from memory, decode it, execute the operation',
    'The pipeline stages in a superscalar processor', 'The process of handling interrupts and exceptions',
    1,
    'The basic instruction cycle: (1) Fetch: load instruction from address in PC into IR, increment PC. (2) Decode: interpret the opcode and identify operands. (3) Execute: perform the operation (ALU computation, memory access, branch). This cycle repeats for each instruction.'
  ),
(
    'Computer Organisation', 'Hard', 90,
    'Out-of-order execution in modern CPUs allows instructions to execute before their program-order predecessors. This is enabled by the:',
    'Branch Predictor', 'Reorder Buffer (ROB) and Reservation Stations', 'TLB (Translation Lookaside Buffer)', 'Prefetch Unit',
    1,
    'Out-of-order execution uses: Reservation Stations to hold instructions until their operands are ready (allowing later instructions to execute first), and a Reorder Buffer (ROB) to track in-flight instructions and commit results in original program order, maintaining precise exceptions.'
  ),
(
    'Computer Organisation', 'Easy', 45,
    'In IEEE 754 double-precision floating point, the number of bits allocated for the exponent is:',
    '8 bits', '11 bits', '23 bits', '52 bits',
    1,
    'IEEE 754 double-precision format uses 64 bits total: 1 sign bit, 11 exponent bits (bias of 1023), and 52 mantissa bits (with implicit leading 1). Single precision uses 1+8+23=32 bits with exponent bias of 127.'
  );
