-- ==========================================
-- Practice Questions: Computer Networks
-- ==========================================

INSERT INTO public.practice_questions
  (topic, difficulty, time_limit, question, option_a, option_b, option_c, option_d, correct_index, explanation, hint)
VALUES
(
    'Computer Networks', 'Medium', 60,
    'In TCP, the purpose of the 3-way handshake is to:',
    'Encrypt the data before transmission',
    'Establish a reliable connection by synchronizing sequence numbers',
    'Determine the maximum segment size',
    'Authenticate the client and server',
    1,
    'The TCP 3-way handshake (SYN → SYN-ACK → ACK) establishes a reliable, full-duplex connection by synchronizing initial sequence numbers (ISNs) between client and server.',
    'The key word is "synchronize" — both sides need to agree on starting sequence numbers before data transfer begins.'
  ),
(
    'Computer Networks', 'Easy', 45,
    'What does the acronym TCP/IP stand for?',
    'Transfer Control Protocol / Internet Protocol', 'Transmission Control Protocol / Internet Protocol',
    'Transmission Control Protocol / Interconnect Protocol', 'Transfer Communication Protocol / Internet Protocol',
    1,
    'TCP/IP stands for Transmission Control Protocol / Internet Protocol. TCP provides reliable, ordered, error-checked delivery of data streams between applications. IP handles addressing and routing of packets across networks. Together they form the foundational protocol suite of the Internet.',
    'TCP ensures reliability. IP handles addressing. Together they are the foundation of the internet.'
  ),
(
    'Computer Networks', 'Medium', 60,
    'In the OSI model, which layer is responsible for encryption and data format translation?',
    'Session Layer (Layer 5)', 'Presentation Layer (Layer 6)', 'Application Layer (Layer 7)', 'Transport Layer (Layer 4)',
    1,
    'The Presentation Layer (Layer 6) handles data representation, encoding, encryption/decryption, and compression. It ensures data from the application layer is in a format the receiving system can interpret. Examples: SSL/TLS (encryption), JPEG/MPEG (format), ASCII/EBCDIC (encoding).',
    'Think about which layer "presents" data in the right format — it handles encoding, encryption, and compression.'
  ),
(
    'Computer Networks', 'Hard', 90,
    'In TCP, what is the purpose of the Nagle algorithm?',
    'To detect and recover from packet loss', 'To reduce the number of small packets by buffering data until a full-sized segment can be sent or all outstanding data is acknowledged',
    'To control congestion in the network', 'To implement flow control using the receiver window',
    1,
    'The Nagle algorithm buffers small amounts of data and waits before sending, combining them into larger segments to reduce network overhead (small packet problem). A packet is sent when: (1) enough data for a full MSS segment, or (2) all previously sent data has been acknowledged. It reduces bandwidth waste but adds latency (disabled with TCP_NODELAY for real-time apps).',
    'Sending many tiny packets wastes network capacity. The Nagle algorithm is about buffering — when should a small packet be sent?'
  ),
(
    'Computer Networks', 'Medium', 60,
    'What is the purpose of the TTL (Time-To-Live) field in an IP packet?',
    'Specifies how long the packet can be cached by routers', 'Limits the number of hops a packet can travel, preventing it from circulating indefinitely',
    'Sets the packet priority for QoS', 'Specifies the packet''s expiration time in seconds',
    1,
    'TTL is a counter decremented by each router (by 1). When TTL reaches 0, the packet is discarded and an ICMP "Time Exceeded" message is sent to the source. This prevents packets from looping infinitely in routing loops. The traceroute utility exploits TTL to discover network paths.',
    'TTL is decremented at each router hop. What problem does it prevent when routing tables have loops?'
  ),
(
    'Computer Networks', 'Easy', 45,
    'Which protocol is responsible for converting IP addresses to MAC addresses on a local network?',
    'RARP', 'DNS', 'ARP', 'DHCP',
    2,
    'ARP (Address Resolution Protocol) resolves IPv4 addresses to MAC (hardware) addresses on a local network segment. When a host wants to send to IP address X, it broadcasts an ARP request. The host with IP X responds with its MAC address. ARP replies are cached in the ARP table.',
    'You know the IP but need the MAC address to actually send the frame. Which protocol finds the MAC from the IP?'
  ),
(
    'Computer Networks', 'Hard', 90,
    'In OSPF (Open Shortest Path First), what is the purpose of the Link State Advertisement (LSA)?',
    'To assign IP addresses to OSPF interfaces', 'To flood topology information (router ID, link states, costs) to all routers in the OSPF area so each can build its own topology database',
    'To elect the designated router on multi-access networks', 'To authenticate OSPF neighbors',
    1,
    'LSAs are the fundamental units of OSPF topology exchange. Each router generates LSAs describing its directly connected links (neighbor IDs, interface costs). LSAs are flooded throughout the OSPF area and stored in the Link State Database (LSDB). Each router runs Dijkstra''s algorithm on its LSDB to compute shortest paths.',
    'OSPF is a link-state protocol. Each router needs to know the entire topology. How does it learn about distant links?'
  ),
(
    'Computer Networks', 'Medium', 75,
    'What is the key difference between a stateful and stateless firewall?',
    'Stateful firewalls are faster; stateless are more secure', 'Stateful firewalls track connection state and context; stateless firewalls filter each packet independently based on rules',
    'Stateless firewalls maintain session tables; stateful do not', 'They differ only in how they handle UDP traffic',
    1,
    'A stateless firewall (packet filter) evaluates each packet independently against ACL rules (IP, port, protocol). A stateful firewall tracks TCP/UDP connection state (SYN, established, FIN) and allows return traffic for established connections automatically. Stateful firewalls are more secure but consume more resources.',
    'The word "stateful" means it remembers past packets. How does knowing connection history help with security decisions?'
  ),
(
    'Computer Networks', 'Easy', 45,
    'What is the maximum size of a UDP datagram payload?',
    '1500 bytes', '65,535 bytes', '65,507 bytes', '32,768 bytes',
    2,
    'The UDP header has a 16-bit length field covering header + data, giving max 65,535 bytes total. Subtracting 8 bytes UDP header = 65,527 bytes. With IP header (20 bytes): max payload = 65,535 - 8 - 20 = 65,507 bytes. In practice, datagrams over 1500 bytes (MTU) are fragmented by IP.',
    'UDP uses a 16-bit length field. What is the maximum value of a 16-bit number? Then subtract header sizes.'
  );
