-- ==========================================
-- Practice Questions: Artificial Intelligence
-- ==========================================

INSERT INTO public.practice_questions
  (topic, difficulty, time_limit, question, option_a, option_b, option_c, option_d, correct_index, explanation, hint)
VALUES
(
    'Artificial Intelligence', 'Medium', 60,
    'In the A* search algorithm, which heuristic property guarantees that the algorithm will always find the optimal path?',
    'Consistency (monotonicity)', 'Admissibility (never overestimates)', 'Completeness', 'Optimality',
    1,
    'An admissible heuristic never overestimates the true cost to reach the goal. This property guarantees that A* will always find the optimal (shortest) path when one exists.',
    'Think about what happens if the heuristic overestimates — it might cause A* to skip the true optimal path.'
  ),
(
    'Artificial Intelligence', 'Easy', 45,
    'In AI, what is the difference between supervised and unsupervised learning?',
    'Supervised uses more data than unsupervised', 'Supervised learning trains on labeled data (input-output pairs); unsupervised learning finds patterns in unlabeled data',
    'Unsupervised learning requires a teacher; supervised does not', 'They are the same with different names',
    1,
    'Supervised learning trains a model on examples with known labels (e.g., image classification, regression). Unsupervised learning discovers hidden structure in unlabeled data (e.g., clustering, dimensionality reduction, association rules). Reinforcement learning uses rewards/penalties from an environment.',
    'The word "supervised" implies a teacher providing correct answers. What does "unsupervised" imply?'
  ),
(
    'Artificial Intelligence', 'Medium', 60,
    'What is the role of a heuristic function h(n) in informed search algorithms?',
    'It calculates the exact cost from node n to the goal', 'It estimates the cost from node n to the goal, guiding the search toward promising areas',
    'It determines the branching factor of the search tree', 'It generates successor nodes from node n',
    1,
    'A heuristic h(n) is an estimated cost from node n to the nearest goal. It provides domain-specific knowledge to guide search. An admissible heuristic never overestimates (h(n) ≤ h*(n), true cost), ensuring A* finds optimal solutions. Better heuristics (closer to h*) reduce nodes explored.',
    'A heuristic is an estimate, not exact. What property must it have to guarantee A* finds the optimal solution?'
  ),
(
    'Artificial Intelligence', 'Hard', 90,
    'In a minimax game tree, alpha-beta pruning prunes a branch when:',
    'The branch depth exceeds a threshold', 'A minimizer node finds a value ≤ the current alpha (best maximizer value), or a maximizer node finds a value ≥ current beta (best minimizer value)',
    'The heuristic evaluation is below a threshold', 'The remaining time for computation is insufficient',
    1,
    'Alpha-beta pruning: alpha = best value MAX can guarantee (starts at -∞), beta = best value MIN can guarantee (starts at +∞). At a MIN node: if current value ≤ alpha, prune (MAX won''t choose this). At a MAX node: if current value ≥ beta, prune (MIN won''t choose this). Worst case same as minimax; best case O(b^(d/2)) instead of O(b^d).',
    'Alpha-beta prunes branches that cannot affect the final decision. When is a minimizer''s subtree irrelevant to the maximizer?'
  ),
(
    'Artificial Intelligence', 'Medium', 75,
    'What is the difference between DFS and BFS in terms of completeness and optimality for graph search?',
    'Both DFS and BFS are complete and optimal', 'BFS is complete and optimal (for uniform costs); DFS is complete in finite graphs but not optimal',
    'DFS is complete and optimal; BFS is neither', 'Neither BFS nor DFS is complete or optimal',
    1,
    'BFS is complete (finds solution if one exists, for finite branching) and optimal for unit-cost actions (finds shallowest solution). DFS is complete in finite graphs but NOT complete for infinite graphs (may go infinitely deep). DFS is NOT optimal (may find a deep suboptimal solution before the optimal one).',
    'BFS explores layer by layer. DFS goes deep first. Which one is guaranteed to find the shortest path?'
  ),
(
    'Artificial Intelligence', 'Easy', 45,
    'In machine learning, what is "overfitting"?',
    'When the model is too simple to capture the data patterns', 'When the model learns training data too well, including noise, and performs poorly on new unseen data',
    'When the training process takes too long', 'When the model has too few parameters',
    1,
    'Overfitting occurs when a model learns the training data (including its noise and irrelevant details) too precisely, resulting in very low training error but high test/validation error. The model fails to generalize. Solutions: more data, regularization (L1/L2), dropout, early stopping, simpler model.',
    'A model that memorizes training examples rather than learning general patterns will fail on new data. What do we call this?'
  ),
(
    'Artificial Intelligence', 'Hard', 90,
    'What is the "credit assignment problem" in reinforcement learning?',
    'Determining the correct reward function for an agent', 'Determining which actions in a long sequence of actions are responsible for a delayed reward',
    'Assigning tasks to multiple agents in a multi-agent system', 'Computing the optimal policy for a given MDP',
    1,
    'The credit assignment problem: in RL, rewards are often received long after the actions that caused them. Which of the many prior actions "deserve credit" for the reward? Temporal Difference (TD) learning and algorithms like Q-learning, REINFORCE, and Actor-Critic methods address this by propagating reward signals backward through time.',
    'If an agent gets a reward after 100 steps, which of those 100 actions actually mattered? How do you figure that out?'
  ),
(
    'Artificial Intelligence', 'Medium', 60,
    'In a Bayesian network, conditional independence means:',
    'Two variables always have the same probability', 'Given the value of a variable''s parents, the variable is independent of all non-descendants',
    'All variables in the network are independent', 'Variables are dependent only if directly connected',
    1,
    'In a Bayesian network (DAG), each node is conditionally independent of its non-descendants given its parents (Markov condition). This property enables efficient representation of joint distributions: P(X1,...,Xn) = ∏ P(Xi | Parents(Xi)), factoring the joint distribution into local conditional probability tables.',
    'In a Bayesian network, knowing a node''s parents "blocks" information flow from ancestors. What does this mean for non-descendants?'
  );
