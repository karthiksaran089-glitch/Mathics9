-- ==========================================
-- Ranked Questions: Algorithms
-- ==========================================

INSERT INTO public.ranked_questions
  (topic, difficulty, time_limit, question, option_a, option_b, option_c, option_d, correct_index, explanation)
VALUES
(
    'Algorithms', 'Medium', 60,
    'What is the time complexity of building a max-heap from an unsorted array of n elements using the standard bottom-up heapify algorithm?',
    'O(n log n)', 'O(n)', 'O(log n)', 'O(n²)',
    1,
    'Building a heap from an unsorted array using bottom-up heapify runs in O(n) time. Although each individual sift-down is O(log n), most elements are near the leaves and require only O(1) work. The total work sums to O(n) by analysis of the geometric series.'
  ),
(
    'Algorithms', 'Easy', 45,
    'What is the time complexity of binary search on a sorted array of n elements?',
    'O(n)', 'O(log n)', 'O(n log n)', 'O(1)',
    1,
    'Binary search repeatedly halves the search space by comparing the target with the middle element. This halving process results in O(log n) comparisons in the worst case, making it highly efficient for sorted arrays.'
  ),
(
    'Algorithms', 'Medium', 60,
    'Which algorithm finds the shortest path from a single source to all other vertices in a weighted graph with non-negative edge weights?',
    'Bellman-Ford', 'Floyd-Warshall', 'Dijkstra''s Algorithm', 'Prim''s Algorithm',
    2,
    'Dijkstra''s algorithm finds the shortest path from a single source to all vertices in a graph with non-negative weights using a greedy approach with a priority queue, running in O((V+E) log V) with a min-heap.'
  ),
(
    'Algorithms', 'Hard', 90,
    'Given the recurrence T(n) = 3T(n/4) + n log n, what is the time complexity by the Master Theorem?',
    'O(n log n)', 'O(n^(log₄3))', 'O(n log² n)', 'O(n²)',
    0,
    'By Master Theorem, a=3, b=4, f(n)=n log n. log_b(a) = log₄(3) ≈ 0.79. Since f(n) = n log n = Ω(n^(0.79+ε)), and 3·f(n/4) = 3·(n/4)log(n/4) ≤ c·n log n for c=3/4 < 1, Case 3 applies. T(n) = Θ(n log n).'
  ),
(
    'Algorithms', 'Medium', 60,
    'Which data structure is used in Prim''s algorithm to efficiently select the minimum weight edge at each step?',
    'Stack', 'Queue', 'Min-Heap (Priority Queue)', 'Hash Table',
    2,
    'Prim''s algorithm uses a min-heap (priority queue) to efficiently extract the minimum weight edge connecting the growing MST to a new vertex. This gives a time complexity of O((V+E) log V) with a binary heap.'
  ),
(
    'Algorithms', 'Hard', 90,
    'In dynamic programming, the Longest Common Subsequence (LCS) of two strings of lengths m and n has time complexity:',
    'O(m+n)', 'O(m·n)', 'O(m·n·log(mn))', 'O(2^(m+n))',
    1,
    'The LCS DP solution fills an (m+1)×(n+1) table where each cell takes O(1) time. Total time is O(m·n) and space is O(m·n), reduceable to O(min(m,n)) with space optimization.'
  ),
(
    'Algorithms', 'Easy', 45,
    'What is the worst-case time complexity of QuickSort?',
    'O(n log n)', 'O(n)', 'O(n²)', 'O(log n)',
    2,
    'QuickSort''s worst case O(n²) occurs when the pivot is always the smallest or largest element (e.g., sorted array with last element as pivot), creating maximally unbalanced partitions of size 0 and n-1 each time.'
  ),
(
    'Algorithms', 'Medium', 75,
    'Which of the following is a correct property of a Red-Black Tree?',
    'Every leaf node is red', 'The root is always red', 'Both children of a red node must be black', 'All paths from root to leaves have equal black nodes ± 1',
    2,
    'A key Red-Black Tree property is that both children of every red node must be black (no two consecutive red nodes). Other properties: root is black, leaves (NIL) are black, and all paths from root to NIL leaves have the same number of black nodes.'
  ),
(
    'Algorithms', 'Hard', 90,
    'The activity selection problem asks for the maximum number of non-overlapping activities. The optimal greedy strategy is to:',
    'Select the activity with the earliest start time first', 'Select the activity with the shortest duration first', 'Select the activity with the earliest finish time first', 'Select the activity with the latest start time first',
    2,
    'Greedily selecting the activity with the earliest finish time first is optimal for the activity selection problem. This leaves the maximum remaining time for subsequent activities, proven correct by an exchange argument.'
  ),
(
    'Algorithms', 'Medium', 60,
    'What is the space complexity of the recursive implementation of Merge Sort?',
    'O(1)', 'O(log n)', 'O(n)', 'O(n log n)',
    2,
    'Recursive Merge Sort requires O(n) auxiliary space for the temporary arrays used during merging, plus O(log n) space for the recursion call stack. The dominant term is O(n) for the merge buffers.'
  ),
(
    'Algorithms', 'Hard', 90,
    'In the coin change problem (minimum coins), if coins = {1, 3, 4} and target = 6, what is the minimum number of coins needed?',
    '3', '2', '4', '6',
    1,
    'Using DP: dp[6] = min(dp[5]+1, dp[3]+1, dp[2]+1) = min(3+1, 1+1, 2+1) = 2 (using coins 3+3). Greedy fails here (4+1+1=3 coins) but DP correctly finds 3+3=2 coins.'
  ),
(
    'Algorithms', 'Hard', 90,
    'In a weighted graph with both positive and negative edges but no negative cycles, which algorithm correctly finds all-pairs shortest paths in O(V³) time?',
    'Running Dijkstra from each vertex', 'Bellman-Ford from each vertex', 'Floyd-Warshall algorithm', 'Johnson''s algorithm',
    2,
    'Floyd-Warshall correctly handles negative edges (but not negative cycles) and runs in O(V³) time and O(V²) space. It uses dynamic programming: dp[i][j][k] = shortest path from i to j using only vertices 1..k as intermediates.'
  ),
(
    'Algorithms', 'Medium', 60,
    'Which algorithm can detect a cycle in a directed graph in O(V+E) time?',
    'Dijkstra''s Algorithm', 'Prim''s Algorithm', 'Depth-First Search (DFS) with back edge detection', 'Breadth-First Search (BFS)',
    2,
    'DFS detects cycles in directed graphs by tracking "gray" (currently being processed) nodes. A back edge from a node to a gray ancestor indicates a cycle. DFS runs in O(V+E) time. For undirected graphs, any edge to a visited (non-parent) node indicates a cycle.'
  ),
(
    'Algorithms', 'Hard', 90,
    'In approximation algorithms, a "2-approximation algorithm" for the Vertex Cover problem works by:',
    'Randomly selecting vertices until the cover is complete', 'Repeatedly finding any uncovered edge, adding both endpoints to the cover, and removing all covered edges',
    'Greedily selecting the highest-degree vertex at each step', 'Using linear programming relaxation and rounding',
    1,
    'The 2-approximation for Vertex Cover: repeatedly pick any uncovered edge (u,v), add both u and v to the cover, remove all edges incident to u or v. The algorithm terminates with a cover ≤ 2×OPT because the selected edges form a matching, and any cover must include at least one endpoint of each edge in this matching.'
  ),
(
    'Algorithms', 'Medium', 60,
    'Topological sort is only applicable to which type of graph?',
    'Undirected graphs', 'Weighted graphs', 'Directed Acyclic Graphs (DAGs)', 'Complete graphs',
    2,
    'Topological sort produces a linear ordering of vertices such that for every directed edge u→v, u appears before v. This is only possible for Directed Acyclic Graphs (DAGs) — if cycles exist, no valid topological ordering can be defined.'
  ),
(
    'Algorithms', 'Hard', 90,
    'In the context of online algorithms, the competitive ratio measures:',
    'The ratio of algorithm runtime to optimal runtime', 'The worst-case ratio of cost incurred by the online algorithm to the cost of the optimal offline algorithm',
    'The ratio of memory used to optimal memory', 'The ratio of correct decisions to total decisions',
    1,
    'An online algorithm makes decisions without future knowledge. Its competitive ratio c means: online cost ≤ c × OPT + b for all input sequences, where OPT is the optimal offline cost. A c-competitive algorithm guarantees its cost is at most c times the offline optimum.'
  ),
(
    'Algorithms', 'Easy', 45,
    'Which of the following sorting algorithms is stable (preserves the relative order of equal elements)?',
    'Heap Sort', 'Quick Sort (standard partition)', 'Merge Sort', 'Selection Sort',
    2,
    'Merge Sort is stable: when merging two subarrays, equal elements from the left subarray are placed before equal elements from the right subarray, preserving their original relative order. Heap Sort and standard Quick Sort are not stable.'
  );
