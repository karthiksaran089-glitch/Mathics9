-- GateMathics: Practice Sessions table
-- Adds: practice_sessions (per-session history for practice mode)

-- 1. TABLE

CREATE TABLE IF NOT EXISTS public.practice_sessions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES public.user_profiles(id) ON DELETE CASCADE,
  session_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
  questions_total INTEGER DEFAULT 0,
  questions_correct INTEGER DEFAULT 0,
  questions_incorrect INTEGER DEFAULT 0,
  questions_timeout INTEGER DEFAULT 0,
  accuracy NUMERIC(5,2) DEFAULT 0.00,
  avg_speed_seconds NUMERIC(6,2) DEFAULT 0.00,
  hints_used INTEGER DEFAULT 0,
  topics_practiced TEXT[] DEFAULT ARRAY[]::TEXT[],
  difficulty TEXT DEFAULT 'Mixed',
  created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- 2. INDEXES
CREATE INDEX IF NOT EXISTS idx_practice_sessions_user_id ON public.practice_sessions(user_id);
CREATE INDEX IF NOT EXISTS idx_practice_sessions_session_date ON public.practice_sessions(session_date);

-- 3. ENABLE RLS
ALTER TABLE public.practice_sessions ENABLE ROW LEVEL SECURITY;

-- 4. RLS POLICIES

DROP POLICY IF EXISTS "users_manage_own_practice_sessions" ON public.practice_sessions;
CREATE POLICY "users_manage_own_practice_sessions"
ON public.practice_sessions
FOR ALL
TO authenticated
USING (user_id = auth.uid())
WITH CHECK (user_id = auth.uid());
