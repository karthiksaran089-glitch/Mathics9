-- ============================================================
-- GateMathics: Profile Raw Data Layer
-- ============================================================
-- Dedicated SQL views and functions for the User Profile page.
-- Provides identity details, progression data, session activity
-- breakdown (practice vs ranked), and account status for each user.
-- ============================================================
-- NOTE: This migration adds to (does not replace) the views
-- in 20260604120000_profile_account.sql
-- ============================================================

-- 1. USER IDENTITY VIEW
-- Core identity details: name, email, avatar, auth method, account status
DROP VIEW IF EXISTS public.user_identity CASCADE;
CREATE VIEW public.user_identity WITH (security_invoker = true) AS
SELECT
  up.id AS user_id,
  up.display_name,
  up.email,
  up.avatar_url,
  up.auth_method::TEXT,
  -- Account type label
  CASE
    WHEN up.auth_method = 'guest' THEN 'Guest'
    WHEN up.auth_method = 'google' THEN 'Google OAuth'
    WHEN up.auth_method = 'email_otp' THEN 'Email OTP'
    ELSE 'Unknown'
  END AS account_type,
  -- Account status
  CASE
    WHEN up.last_active_date = CURRENT_DATE THEN 'active_today'
    WHEN up.last_active_date >= CURRENT_DATE - INTERVAL '1 day' THEN 'active_yesterday'
    WHEN up.last_active_date >= CURRENT_DATE - INTERVAL '7 days' THEN 'active_this_week'
    WHEN up.last_active_date IS NOT NULL THEN 'inactive'
    ELSE 'never_active'
  END AS account_status,
  -- Account age
  COALESCE(
    EXTRACT(DAY FROM (CURRENT_TIMESTAMP - up.created_at))::INTEGER,
    0
  ) AS account_age_days,
  -- Timestamps
  up.created_at AS account_created_at,
  up.last_active_date,
  up.updated_at
FROM public.user_profiles up;

-- 2. USER PROGRESSION VIEW
-- Rank, LP, level, XP, streaks, and progression metrics
DROP VIEW IF EXISTS public.user_progression CASCADE;
CREATE VIEW public.user_progression WITH (security_invoker = true) AS
SELECT
  up.id AS user_id,
  up.rank::TEXT AS current_rank,
  up.lp,
  -- Next rank info
  CASE
    WHEN up.rank::TEXT = 'Bronze' THEN 'Silver'
    WHEN up.rank::TEXT = 'Silver' THEN 'Gold'
    WHEN up.rank::TEXT = 'Gold' THEN 'Platinum'
    WHEN up.rank::TEXT = 'Platinum' THEN 'Diamond'
    WHEN up.rank::TEXT = 'Diamond' THEN 'Grandmaster'
    WHEN up.rank::TEXT = 'Grandmaster' THEN 'Grandmaster'
    ELSE 'Silver'
  END AS next_rank_name,
  CASE
    WHEN up.rank::TEXT = 'Bronze' THEN 500
    WHEN up.rank::TEXT = 'Silver' THEN 1000
    WHEN up.rank::TEXT = 'Gold' THEN 1500
    WHEN up.rank::TEXT = 'Platinum' THEN 2000
    WHEN up.rank::TEXT = 'Diamond' THEN 2500
    WHEN up.rank::TEXT = 'Grandmaster' THEN 2500
    ELSE 1000
  END AS next_rank_lp_threshold,
  -- LP progress percent
  CASE
    WHEN up.rank::TEXT = 'Grandmaster' THEN 100
    WHEN up.rank::TEXT = 'Bronze' THEN ROUND((up.lp::NUMERIC / 500) * 100, 1)
    WHEN up.rank::TEXT = 'Silver' THEN ROUND((up.lp::NUMERIC / 1000) * 100, 1)
    WHEN up.rank::TEXT = 'Gold' THEN ROUND((up.lp::NUMERIC / 1500) * 100, 1)
    WHEN up.rank::TEXT = 'Platinum' THEN ROUND((up.lp::NUMERIC / 2000) * 100, 1)
    WHEN up.rank::TEXT = 'Diamond' THEN ROUND((up.lp::NUMERIC / 2500) * 100, 1)
    ELSE 100
  END AS lp_progress_percent,
  -- XP (10 per correct answer, 5 per session)
  (COALESCE(up.total_correct, 0) * 10 + COALESCE(up.total_sessions, 0) * 5) AS total_xp,
  -- Streaks
  up.daily_streak,
  up.longest_streak,
  -- Level tier (computed from XP)
  CASE
    WHEN (COALESCE(up.total_correct, 0) * 10 + COALESCE(up.total_sessions, 0) * 5) >= 10000 THEN 'Legendary'
    WHEN (COALESCE(up.total_correct, 0) * 10 + COALESCE(up.total_sessions, 0) * 5) >= 5000 THEN 'Expert'
    WHEN (COALESCE(up.total_correct, 0) * 10 + COALESCE(up.total_sessions, 0) * 5) >= 2000 THEN 'Advanced'
    WHEN (COALESCE(up.total_correct, 0) * 10 + COALESCE(up.total_sessions, 0) * 5) >= 500 THEN 'Intermediate'
    WHEN (COALESCE(up.total_correct, 0) * 10 + COALESCE(up.total_sessions, 0) * 5) >= 100 THEN 'Beginner'
    ELSE 'Newcomer'
  END AS level_tier
FROM public.user_profiles up;

-- 3. USER SESSION BREAKDOWN VIEW
-- Practice vs Ranked activity breakdown for the profile page
DROP VIEW IF EXISTS public.user_session_breakdown CASCADE;
CREATE VIEW public.user_session_breakdown WITH (security_invoker = true) AS
SELECT
  up.id AS user_id,
  -- Total counts
  COALESCE(up.total_sessions, 0) AS total_sessions,
  COALESCE(up.total_ranked_sessions, 0) AS ranked_sessions,
  COALESCE(up.total_practice_sessions, 0) AS practice_sessions,
  -- Questions breakdown
  COALESCE(up.total_questions_answered, 0) AS total_questions,
  COALESCE(up.total_correct, 0) AS total_correct,
  COALESCE(up.total_incorrect, 0) AS total_incorrect,
  COALESCE(up.total_timeout, 0) AS total_timeout,
  -- Session split percentages
  CASE
    WHEN COALESCE(up.total_sessions, 0) > 0
    THEN ROUND((COALESCE(up.total_ranked_sessions, 0)::NUMERIC / up.total_sessions) * 100, 1)
    ELSE 0
  END AS ranked_session_pct,
  CASE
    WHEN COALESCE(up.total_sessions, 0) > 0
    THEN ROUND((COALESCE(up.total_practice_sessions, 0)::NUMERIC / up.total_sessions) * 100, 1)
    ELSE 0
  END AS practice_session_pct,
  -- Performance metrics
  up.overall_accuracy,
  up.avg_answer_speed_seconds,
  -- Accuracy tier
  CASE
    WHEN COALESCE(up.overall_accuracy, 0) >= 80 THEN 'excellent'
    WHEN COALESCE(up.overall_accuracy, 0) >= 60 THEN 'good'
    WHEN COALESCE(up.overall_accuracy, 0) >= 40 THEN 'average'
    WHEN COALESCE(up.overall_accuracy, 0) > 0 THEN 'needs_improvement'
    ELSE 'no_data'
  END AS accuracy_tier,
  -- Hints used in practice
  COALESCE((
    SELECT SUM(ps.hints_used) FROM public.practice_sessions ps WHERE ps.user_id = up.id
  ), 0) AS practice_hints_used,
  -- Ranked win/loss stats
  COALESCE((
    SELECT COUNT(*) FROM public.ranked_sessions rs WHERE rs.user_id = up.id AND rs.lp_change > 0
  ), 0) AS ranked_wins,
  COALESCE((
    SELECT COUNT(*) FROM public.ranked_sessions rs WHERE rs.user_id = up.id AND rs.lp_change < 0
  ), 0) AS ranked_losses,
  COALESCE((
    SELECT COUNT(*) FROM public.ranked_sessions rs WHERE rs.user_id = up.id AND rs.lp_change = 0
  ), 0) AS ranked_draws,
  -- Ranked win rate
  CASE
    WHEN COALESCE(up.total_ranked_sessions, 0) > 0
    THEN ROUND((
      (SELECT COUNT(*)::NUMERIC FROM public.ranked_sessions rs WHERE rs.user_id = up.id AND rs.lp_change > 0)
      / up.total_ranked_sessions
    ) * 100, 1)
    ELSE 0
  END AS ranked_win_rate,
  -- Net LP from ranked
  COALESCE((
    SELECT SUM(rs.lp_change) FROM public.ranked_sessions rs WHERE rs.user_id = up.id
  ), 0) AS ranked_net_lp_change
FROM public.user_profiles up;

-- 4. USER RECENT ACTIVITY VIEW
-- Last 5 sessions (combined practice + ranked) for the profile page
DROP VIEW IF EXISTS public.user_recent_activity CASCADE;
CREATE VIEW public.user_recent_activity WITH (security_invoker = true) AS
SELECT
  sh.session_id,
  sh.user_id,
  sh.session_date,
  sh.mode,
  sh.questions_total,
  sh.questions_correct,
  sh.accuracy,
  sh.avg_speed_seconds,
  sh.lp_change,
  sh.topics,
  sh.difficulty,
  sh.hints_used
FROM public.analytics_session_history sh
ORDER BY sh.session_date DESC
LIMIT 5;

-- 5. FUNCTION: Get full profile raw data
-- Returns all profile data needed for the profile page in a single call
DROP FUNCTION IF EXISTS public.get_profile_raw_data;
CREATE FUNCTION public.get_profile_raw_data(p_user_id UUID)
RETURNS JSONB
LANGUAGE plpgsql SECURITY DEFINER
AS $$
DECLARE
  v_result JSONB;
BEGIN
  SELECT jsonb_build_object(
    'identity', jsonb_build_object(
      'user_id', ui.user_id,
      'display_name', ui.display_name,
      'email', ui.email,
      'avatar_url', ui.avatar_url,
      'auth_method', ui.auth_method,
      'account_type', ui.account_type,
      'account_status', ui.account_status,
      'account_age_days', ui.account_age_days,
      'account_created_at', ui.account_created_at,
      'last_active_date', ui.last_active_date
    ),
    'progression', jsonb_build_object(
      'current_rank', up2.current_rank,
      'lp', up2.lp,
      'next_rank_name', up2.next_rank_name,
      'next_rank_lp_threshold', up2.next_rank_lp_threshold,
      'lp_progress_percent', up2.lp_progress_percent,
      'total_xp', up2.total_xp,
      'daily_streak', up2.daily_streak,
      'longest_streak', up2.longest_streak,
      'level_tier', up2.level_tier
    ),
    'sessions', jsonb_build_object(
      'total_sessions', us.total_sessions,
      'ranked_sessions', us.ranked_sessions,
      'practice_sessions', us.practice_sessions,
      'total_questions', us.total_questions,
      'total_correct', us.total_correct,
      'total_incorrect', us.total_incorrect,
      'total_timeout', us.total_timeout,
      'ranked_session_pct', us.ranked_session_pct,
      'practice_session_pct', us.practice_session_pct,
      'overall_accuracy', us.overall_accuracy,
      'avg_answer_speed_seconds', us.avg_answer_speed_seconds,
      'accuracy_tier', us.accuracy_tier,
      'practice_hints_used', us.practice_hints_used,
      'ranked_wins', us.ranked_wins,
      'ranked_losses', us.ranked_losses,
      'ranked_draws', us.ranked_draws,
      'ranked_win_rate', us.ranked_win_rate,
      'ranked_net_lp_change', us.ranked_net_lp_change
    )
  ) INTO v_result
  FROM public.user_identity ui
  JOIN public.user_progression up2 ON ui.user_id = up2.user_id
  JOIN public.user_session_breakdown us ON ui.user_id = us.user_id
  WHERE ui.user_id = p_user_id;

  IF v_result IS NULL THEN
    RETURN jsonb_build_object('error', 'User profile not found');
  END IF;

  RETURN v_result;
END;
$$;

-- 6. INDEXES for profile queries
CREATE INDEX IF NOT EXISTS idx_user_profiles_last_active
  ON public.user_profiles(last_active_date DESC);
CREATE INDEX IF NOT EXISTS idx_user_profiles_auth_method
  ON public.user_profiles(auth_method);