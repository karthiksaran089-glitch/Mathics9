-- GateMathics: Support Messages + Ranked Sessions tables
-- Adds: support_messages (help center), ranked_sessions (per-session history)

-- 1. TABLES

-- Support messages from Help Center "Still Need Help" form
CREATE TABLE IF NOT EXISTS public.support_messages (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES public.user_profiles(id) ON DELETE SET NULL,
  email TEXT,
  message TEXT NOT NULL,
  status TEXT DEFAULT 'open',
  created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- Ranked session history (one row per completed ranked match)
CREATE TABLE IF NOT EXISTS public.ranked_sessions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES public.user_profiles(id) ON DELETE CASCADE,
  session_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
  questions_total INTEGER DEFAULT 0,
  questions_correct INTEGER DEFAULT 0,
  questions_incorrect INTEGER DEFAULT 0,
  questions_timeout INTEGER DEFAULT 0,
  accuracy NUMERIC(5,2) DEFAULT 0.00,
  avg_speed_seconds NUMERIC(6,2) DEFAULT 0.00,
  lp_before INTEGER DEFAULT 0,
  lp_after INTEGER DEFAULT 0,
  lp_change INTEGER DEFAULT 0,
  rank_before TEXT DEFAULT 'Silver',
  rank_after TEXT DEFAULT 'Silver',
  topics_played TEXT[] DEFAULT ARRAY[]::TEXT[],
  topics_banned TEXT[] DEFAULT ARRAY[]::TEXT[],
  created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- 2. INDEXES
CREATE INDEX IF NOT EXISTS idx_support_messages_user_id ON public.support_messages(user_id);
CREATE INDEX IF NOT EXISTS idx_support_messages_created_at ON public.support_messages(created_at);
CREATE INDEX IF NOT EXISTS idx_ranked_sessions_user_id ON public.ranked_sessions(user_id);
CREATE INDEX IF NOT EXISTS idx_ranked_sessions_session_date ON public.ranked_sessions(session_date);

-- 3. ENABLE RLS
ALTER TABLE public.support_messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.ranked_sessions ENABLE ROW LEVEL SECURITY;

-- 4. RLS POLICIES

-- support_messages: authenticated users can insert their own; anon can also submit
DROP POLICY IF EXISTS "users_insert_support_messages" ON public.support_messages;
CREATE POLICY "users_insert_support_messages"
ON public.support_messages
FOR INSERT
TO public
WITH CHECK (true);

DROP POLICY IF EXISTS "users_select_own_support_messages" ON public.support_messages;
CREATE POLICY "users_select_own_support_messages"
ON public.support_messages
FOR SELECT
TO authenticated
USING (user_id = auth.uid());

-- ranked_sessions: users manage their own sessions
DROP POLICY IF EXISTS "users_manage_own_ranked_sessions" ON public.ranked_sessions;
CREATE POLICY "users_manage_own_ranked_sessions"
ON public.ranked_sessions
FOR ALL
TO authenticated
USING (user_id = auth.uid())
WITH CHECK (user_id = auth.uid());
