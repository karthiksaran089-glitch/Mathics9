-- ============================================================
-- GateMathics: Points Raw Data Layer
-- ============================================================
-- Dedicated views for tracking earned points from Ranked Mode
-- and Practice Mode. This file documents how each user's
-- progression points flow through the database.
--
-- DATA FLOW:
-- ──────────
-- Ranked Mode earn points:
--   1. User answers question correctly → +lpWager LP
--   2. User answers incorrectly → -lpWager LP
--   3. User times out → -floor(lpWager * 0.5) LP
--   4. At session end → saveRankedSession() inserts into ranked_sessions
--   5. saveRankedSession() updates user_profiles:
--      - lp (new total LP)
--      - rank (recomputed from LP)
--      - total_sessions += 1
--      - total_ranked_sessions += 1
--      - total_questions_answered += questions_total
--      - total_correct += questions_correct
--      - total_incorrect += questions_incorrect
--      - total_timeout += questions_timeout
--      - overall_accuracy = recomputed
--      - avg_answer_speed_seconds = averaged
--      - daily_streak / longest_streak updated
--
-- Practice Mode earn points:
--   1. User answers question correctly → +10 XP
--   2. User completes session → +5 XP per session
--   3. At session end → savePracticeSession() inserts into practice_sessions
--   4. savePracticeSession() updates user_profiles:
--      - total_sessions += 1
--      - total_practice_sessions += 1
--      - total_questions_answered += questions_total
--      - total_correct += questions_correct
--      - total_incorrect += questions_incorrect
--      - total_timeout += questions_timeout
--      - overall_accuracy = recomputed
--      - avg_answer_speed_seconds = averaged
--      - daily_streak / longest_streak updated
--
-- Analytics Dashboard reads:
--   - analytics_user_summary → from user_profiles
--   - analytics_session_history → from ranked_sessions UNION practice_sessions
--   - analytics_session_stats → from analytics_session_history
--   - analytics_topic_mastery → from ranked_sessions + practice_sessions
--   - analytics_lp_trend → from ranked_sessions
--   - analytics_accuracy_trend → from analytics_session_history
--   - analytics_activity → from ranked_sessions + practice_sessions
--   - analytics_mode_breakdown → from analytics_session_history
--   - analytics_weak_topics → from analytics_topic_mastery
-- ============================================================

-- 1. USER POINTS LEDGER VIEW
-- Comprehensive view of each user's earned/lost points across both modes
DROP VIEW IF EXISTS public.user_points_ledger CASCADE;
CREATE VIEW public.user_points_ledger WITH (security_invoker = true) AS
WITH ranked_points AS (
  SELECT
    user_id,
    SUM(CASE WHEN lp_change > 0 THEN lp_change ELSE 0 END) AS ranked_lp_gained,
    SUM(CASE WHEN lp_change < 0 THEN ABS(lp_change) ELSE 0 END) AS ranked_lp_lost,
    SUM(lp_change) AS ranked_net_lp,
    COUNT(*) AS ranked_sessions_played,
    ROUND(AVG(accuracy), 1) AS ranked_avg_accuracy,
    ROUND(AVG(avg_speed_seconds), 1) AS ranked_avg_speed
  FROM public.ranked_sessions
  GROUP BY user_id
),
practice_points AS (
  SELECT
    user_id,
    -- XP: 10 per correct answer + 5 per session
    SUM(questions_correct) * 10 AS practice_xp_from_correct,
    COUNT(*) * 5 AS practice_xp_from_sessions,
    SUM(questions_correct) * 10 + COUNT(*) * 5 AS practice_total_xp,
    COUNT(*) AS practice_sessions_played,
    ROUND(AVG(accuracy), 1) AS practice_avg_accuracy,
    ROUND(AVG(avg_speed_seconds), 1) AS practice_avg_speed,
    SUM(hints_used) AS practice_hints_used
  FROM public.practice_sessions
  GROUP BY user_id
)
SELECT
  up.id AS user_id,
  up.display_name,
  -- Current standings
  up.lp AS current_lp,
  up.rank::TEXT AS current_rank,
  -- Ranked points breakdown
  COALESCE(rp.ranked_lp_gained, 0) AS ranked_lp_gained,
  COALESCE(rp.ranked_lp_lost, 0) AS ranked_lp_lost,
  COALESCE(rp.ranked_net_lp, 0) AS ranked_net_lp,
  COALESCE(rp.ranked_sessions_played, 0) AS ranked_sessions_played,
  COALESCE(rp.ranked_avg_accuracy, 0) AS ranked_avg_accuracy,
  COALESCE(rp.ranked_avg_speed, 0) AS ranked_avg_speed,
  -- Practice points breakdown
  COALESCE(pp.practice_xp_from_correct, 0) AS practice_xp_from_correct,
  COALESCE(pp.practice_xp_from_sessions, 0) AS practice_xp_from_sessions,
  COALESCE(pp.practice_total_xp, 0) AS practice_total_xp,
  COALESCE(pp.practice_sessions_played, 0) AS practice_sessions_played,
  COALESCE(pp.practice_avg_accuracy, 0) AS practice_avg_accuracy,
  COALESCE(pp.practice_avg_speed, 0) AS practice_avg_speed,
  COALESCE(pp.practice_hints_used, 0) AS practice_hints_used,
  -- Combined totals
  COALESCE(rp.ranked_sessions_played, 0) + COALESCE(pp.practice_sessions_played, 0) AS total_sessions,
  up.total_questions_answered,
  up.total_correct,
  up.total_incorrect,
  up.total_timeout,
  up.overall_accuracy,
  up.daily_streak,
  up.longest_streak
FROM public.user_profiles up
LEFT JOIN ranked_points rp ON up.id = rp.user_id
LEFT JOIN practice_points pp ON up.id = pp.user_id;

-- 2. RECENT EARNINGS VIEW
-- Shows the last 10 sessions with points earned for each user
DROP VIEW IF EXISTS public.recent_earnings CASCADE;
CREATE VIEW public.recent_earnings WITH (security_invoker = true) AS
SELECT
  sh.session_id,
  sh.user_id,
  sh.session_date,
  sh.mode,
  sh.questions_total,
  sh.questions_correct,
  sh.questions_incorrect,
  sh.questions_timeout,
  sh.accuracy,
  sh.avg_speed_seconds,
  sh.lp_change,
  sh.topics,
  sh.difficulty,
  sh.hints_used,
  -- XP earned (practice mode: 10 per correct + 5 per session)
  CASE
    WHEN sh.mode = 'Practice' THEN (COALESCE(sh.questions_correct, 0) * 10 + 5)
    ELSE 0
  END AS xp_earned,
  -- LP earned (ranked mode only)
  CASE
    WHEN sh.mode = 'Ranked' THEN COALESCE(sh.lp_change, 0)
    ELSE 0
  END AS lp_earned
FROM public.analytics_session_history sh
ORDER BY sh.session_date DESC
LIMIT 10;

-- 3. POINTS SUMMARY FUNCTION
-- Returns a JSON summary of all points earned by a user
DROP FUNCTION IF EXISTS public.get_user_points_summary;
CREATE FUNCTION public.get_user_points_summary(p_user_id UUID)
RETURNS JSONB
LANGUAGE plpgsql SECURITY DEFINER
AS $$
DECLARE
  v_result JSONB;
BEGIN
  SELECT jsonb_build_object(
    'user_id', upl.user_id,
    'display_name', upl.display_name,
    'current_lp', upl.current_lp,
    'current_rank', upl.current_rank,
    'ranked', jsonb_build_object(
      'sessions_played', upl.ranked_sessions_played,
      'lp_gained', upl.ranked_lp_gained,
      'lp_lost', upl.ranked_lp_lost,
      'net_lp', upl.ranked_net_lp,
      'avg_accuracy', upl.ranked_avg_accuracy,
      'avg_speed', upl.ranked_avg_speed
    ),
    'practice', jsonb_build_object(
      'sessions_played', upl.practice_sessions_played,
      'xp_from_correct', upl.practice_xp_from_correct,
      'xp_from_sessions', upl.practice_xp_from_sessions,
      'total_xp', upl.practice_total_xp,
      'avg_accuracy', upl.practice_avg_accuracy,
      'avg_speed', upl.practice_avg_speed,
      'hints_used', upl.practice_hints_used
    ),
    'combined', jsonb_build_object(
      'total_sessions', upl.total_sessions,
      'total_questions', upl.total_questions_answered,
      'total_correct', upl.total_correct,
      'total_incorrect', upl.total_incorrect,
      'total_timeout', upl.total_timeout,
      'overall_accuracy', upl.overall_accuracy,
      'daily_streak', upl.daily_streak,
      'longest_streak', upl.longest_streak
    )
  ) INTO v_result
  FROM public.user_points_ledger upl
  WHERE upl.user_id = p_user_id;

  IF v_result IS NULL THEN
    RETURN jsonb_build_object('error', 'User not found');
  END IF;

  RETURN v_result;
END;
$$;

-- 4. INDEXES for points queries
CREATE INDEX IF NOT EXISTS idx_ranked_sessions_lp_change_user
  ON public.ranked_sessions(user_id, lp_change);
CREATE INDEX IF NOT EXISTS idx_practice_sessions_correct_user
  ON public.practice_sessions(user_id, questions_correct);