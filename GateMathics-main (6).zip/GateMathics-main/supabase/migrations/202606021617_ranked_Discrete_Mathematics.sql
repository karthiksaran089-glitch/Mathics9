-- ==========================================
-- Ranked Questions: Discrete Mathematics
-- ==========================================

INSERT INTO public.ranked_questions
  (topic, difficulty, time_limit, question, option_a, option_b, option_c, option_d, correct_index, explanation)
VALUES
(
    'Discrete Mathematics', 'Medium', 60,
    'How many edges does a complete graph Kₙ have?',
    'n(n-1)', 'n(n-1)/2', 'n²', 'n(n+1)/2',
    1,
    'A complete graph Kₙ has n(n-1)/2 edges. Each of the n vertices connects to every other vertex, giving n(n-1) directed pairs. Since each undirected edge is counted twice, we divide by 2.'
  ),
(
    'Discrete Mathematics', 'Easy', 45,
    'What is the power set of {1, 2, 3}?',
    '{{}, {1}, {2}, {3}, {1,2}, {1,3}, {2,3}, {1,2,3}}', '{{1}, {2}, {3}}',
    '{{1,2}, {1,3}, {2,3}}', '{{}, {1,2,3}}',
    0,
    'The power set P(S) of a set S contains all subsets of S, including the empty set and S itself. For |S|=3, |P(S)| = 2³ = 8. P({1,2,3}) = {∅, {1}, {2}, {3}, {1,2}, {1,3}, {2,3}, {1,2,3}}.'
  ),
(
    'Discrete Mathematics', 'Medium', 60,
    'In graph theory, Euler''s formula for a connected planar graph states V - E + F = 2. For a planar graph with 10 vertices and 15 edges, how many faces does it have?',
    '5', '7', '9', '11',
    1,
    'Euler''s formula: V - E + F = 2. With V=10 and E=15: 10 - 15 + F = 2, so F = 2 + 15 - 10 = 7. This includes the outer (unbounded) face. Valid since the graph must be connected and planar.'
  ),
(
    'Discrete Mathematics', 'Hard', 90,
    'The number of ways to distribute 10 identical balls into 4 distinct boxes with no box empty is:',
    '84', '120', '252', '36',
    0,
    'This is stars and bars with restriction: distributing n identical items into k distinct bins with each bin ≥ 1 = C(n-1, k-1) = C(10-1, 4-1) = C(9,3) = 9!/(3!6!) = 84. Substitute each bin with at least 1 ball first (10-4=6 remaining, C(6+3,3)=C(9,3)=84).'
  ),
(
    'Discrete Mathematics', 'Medium', 60,
    'What is the principle of inclusion-exclusion for three sets |A ∪ B ∪ C|?',
    '|A| + |B| + |C|', '|A| + |B| + |C| - |A∩B| - |A∩C| - |B∩C|',
    '|A| + |B| + |C| - |A∩B| - |A∩C| - |B∩C| + |A∩B∩C|', '|A| × |B| × |C|',
    2,
    'Inclusion-exclusion for three sets: |A∪B∪C| = |A|+|B|+|C| - |A∩B| - |A∩C| - |B∩C| + |A∩B∩C|. We add singletons, subtract pairwise intersections (overcounted), and add back the triple intersection (overcorrected).'
  ),
(
    'Discrete Mathematics', 'Easy', 45,
    'A function f: A → B is bijective (one-to-one correspondence) if it is:',
    'Only injective (one-to-one)', 'Only surjective (onto)', 'Both injective and surjective', 'Neither injective nor surjective',
    2,
    'A bijective function is both injective (one-to-one: distinct inputs map to distinct outputs) and surjective (onto: every element in B is the image of some element in A). Bijections imply |A| = |B| and the function has an inverse.'
  ),
(
    'Discrete Mathematics', 'Hard', 90,
    'Using Bayes'' theorem, if P(Disease) = 0.01, P(Positive | Disease) = 0.95, P(Positive | No Disease) = 0.05, what is P(Disease | Positive)?',
    '~16%', '~95%', '~50%', '~1%',
    0,
    'P(Disease|Positive) = P(Positive|Disease)×P(Disease) / P(Positive). P(Positive) = 0.95×0.01 + 0.05×0.99 = 0.0095 + 0.0495 = 0.059. P(Disease|Positive) = 0.0095/0.059 ≈ 0.161 ≈ 16.1%. Despite 95% sensitivity, low prevalence makes positive predictive value only ~16%.'
  ),
(
    'Discrete Mathematics', 'Medium', 75,
    'What is the generating function for the sequence 1, 1, 1, 1, ... (constant sequence)?',
    '1/(1-x)', 'e^x', '1/(1+x)', 'x/(1-x)',
    0,
    'The ordinary generating function for the sequence {1, 1, 1, 1, ...} is Σ(n=0 to ∞) xⁿ = 1/(1-x) for |x| < 1. This is the geometric series. Generating functions are powerful tools for solving recurrences and counting problems.'
  ),
(
    'Discrete Mathematics', 'Hard', 90,
    'In a group (G, *), if every element is its own inverse (a*a = e for all a ∈ G), then the group is:',
    'Cyclic', 'Abelian (commutative)', 'Simple', 'Non-abelian',
    1,
    'If every element is its own inverse, then for any a,b ∈ G: (a*b)*(a*b) = e, and a*(a*b)*b = a*e*b = a*b. But (a*b)*(a*b)=e implies a*b = (a*b)^(-1) = b^(-1)*a^(-1) = b*a. Thus a*b = b*a, making G abelian.'
  ),
(
    'Discrete Mathematics', 'Medium', 60,
    'In a bipartite graph G = (X ∪ Y, E) where |X| = |Y| = n, a perfect matching exists if and only if (Hall''s theorem):',
    'Every vertex in X has degree at least 1', 'For every subset S ⊆ X, the neighborhood |N(S)| ≥ |S|',
    'The graph is connected', 'Every vertex has the same degree',
    1,
    'Hall''s Marriage Theorem states that a bipartite graph G=(X∪Y, E) has a perfect matching (|X|=|Y|=n) if and only if for every subset S⊆X, |N(S)| ≥ |S|. This condition ensures no subset of X is "bottlenecked" by too few neighbors in Y.'
  ),
(
    'Discrete Mathematics', 'Medium', 75,
    'Dijkstra''s algorithm on a graph requires edges with:',
    'Integer weights only', 'Non-negative weights', 'Weights in range [0, 1]', 'Any real number weights including negative',
    1,
    'Dijkstra''s algorithm requires non-negative edge weights. Its correctness relies on the greedy property: once a vertex is extracted from the min-heap (marked as visited), its shortest distance is finalized. Negative edges violate this — a later path through a negative edge might give a shorter path.'
  ),
(
    'Discrete Mathematics', 'Hard', 90,
    'Using the Master Theorem, solve T(n) = 4T(n/2) + n². What is the time complexity?',
    'O(n²)', 'O(n² log n)', 'O(n^2.5)', 'O(n³)',
    1,
    'Master Theorem: a=4, b=2, f(n)=n². log_b(a) = log₂(4) = 2. Since f(n) = n² = Θ(n^log_b(a)) = Θ(n²), Case 2 applies: T(n) = Θ(n^log_b(a) × log n) = Θ(n² log n).'
  ),
(
    'Discrete Mathematics', 'Medium', 60,
    'Which of the following statements about trees is FALSE?',
    'A tree with n vertices has exactly n-1 edges', 'Every tree is a bipartite graph', 'A tree has exactly one path between any two vertices', 'A tree may contain exactly one cycle',
    3,
    'A tree is defined as a connected, acyclic graph. By definition, a tree cannot contain any cycle — that is the defining property. The other statements are all true: n vertices → n-1 edges, trees are bipartite (2-colorable), and exactly one path exists between any two vertices.'
  )
ON CONFLICT DO NOTHING;
