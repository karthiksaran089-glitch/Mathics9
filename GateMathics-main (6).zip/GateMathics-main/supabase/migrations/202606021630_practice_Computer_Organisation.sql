-- ==========================================
-- Practice Questions: Computer Organisation
-- ==========================================

INSERT INTO public.practice_questions
  (topic, difficulty, time_limit, question, option_a, option_b, option_c, option_d, correct_index, explanation, hint)
VALUES
(
    'Computer Organisation', 'Hard', 75,
    'Which addressing mode uses the content of a register as the memory address of the operand?',
    'Immediate addressing', 'Direct addressing', 'Register indirect addressing', 'Indexed addressing',
    2,
    'Register indirect addressing uses the value stored in a register as the memory address where the actual operand is located. The register holds a pointer to the data, not the data itself.',
    'The word "indirect" is the key — the register does not hold the data, it holds the address of the data.'
  ),
(
    'Computer Organisation', 'Easy', 45,
    'What is the purpose of a hardware interrupt?',
    'To pause and restart the clock signal', 'To signal the CPU that an external event requires immediate attention, causing it to suspend the current task and execute an interrupt handler',
    'To reset all CPU registers to zero', 'To flush the instruction pipeline',
    1,
    'A hardware interrupt is an asynchronous signal from a hardware device (keyboard, disk, timer, NIC) notifying the CPU of an event requiring service. The CPU saves its current state, jumps to the Interrupt Service Routine (ISR), handles the event, then resumes the interrupted program.',
    'How does a keyboard tell the CPU you pressed a key while the CPU is busy running another program?'
  ),
(
    'Computer Organisation', 'Medium', 75,
    'What is the purpose of forwarding (bypassing) in a pipelined CPU?',
    'To forward packets in a network', 'To pass computation results directly to subsequent pipeline stages without waiting for the result to be written back to a register',
    'To predict branch outcomes', 'To increase the clock frequency',
    1,
    'Data forwarding (bypassing) resolves data hazards (RAW) without stalling the pipeline. Instead of waiting for a result to be written to a register and read back, the result is forwarded directly from the output of one stage (e.g., EX) to the input of a later stage (e.g., EX of the next instruction). This keeps the pipeline flowing.',
    'In a data hazard, instruction 2 needs the result of instruction 1 before it is written back. Can you shortcut the path?'
  ),
(
    'Computer Organisation', 'Hard', 90,
    'What is the difference between SRAM and DRAM?',
    'SRAM is slower but cheaper; DRAM is faster but more expensive', 'SRAM uses flip-flops (no refresh needed, faster, expensive); DRAM uses capacitors (needs periodic refresh, slower, cheaper)',
    'SRAM is used for main memory; DRAM for cache', 'They are the same technology with different names',
    1,
    'SRAM (Static RAM) stores each bit in a flip-flop (6 transistors), retaining data as long as power is on — no refresh needed. It is fast (nanosecond access) and used for CPU caches. DRAM (Dynamic RAM) stores bits in capacitors (1 transistor + 1 capacitor), which leak and must be refreshed every few milliseconds. DRAM is cheaper and denser, used for main memory.',
    'Think about what "static" vs "dynamic" means. Which technology needs refreshing like a leaky bucket?'
  ),
(
    'Computer Organisation', 'Medium', 60,
    'In a two-level page table system, what problem does it solve compared to a single-level page table?',
    'It eliminates the need for a TLB', 'It reduces the memory required for page tables by only allocating second-level page tables that are actually needed',
    'It increases memory access speed', 'It eliminates internal fragmentation',
    1,
    'A single-level page table for a 32-bit address space with 4KB pages needs 2^20 × 4 bytes = 4MB per process (most often sparsely populated). A 2-level (or hierarchical) page table only allocates second-level tables for virtual memory regions actually in use, saving space for sparse address spaces.',
    'A process often uses only a small portion of its virtual address space. How does hierarchical paging avoid allocating page table entries for unused regions?'
  ),
(
    'Computer Organisation', 'Easy', 45,
    'What is the role of the ALU (Arithmetic Logic Unit) in a CPU?',
    'Stores data temporarily between operations', 'Performs arithmetic operations (add, subtract) and logical operations (AND, OR, NOT, XOR) on binary data',
    'Controls the instruction fetch and decode process', 'Manages cache memory',
    1,
    'The ALU is the computational core of the CPU, performing arithmetic (addition, subtraction, multiplication, division) and logical (AND, OR, NOT, XOR, shifts, comparisons) operations on binary data. Results and status flags (zero, carry, overflow, sign) are output to registers.',
    'What part of the CPU actually "calculates"? What kinds of operations does it perform?'
  ),
(
    'Computer Organisation', 'Hard', 90,
    'What is branch prediction in modern processors, and why is it important?',
    'Predicting the next instruction''s memory address for prefetching', 'Guessing the outcome of a branch instruction before it is resolved to keep the pipeline full, reducing misprediction penalties',
    'Allocating CPU branches to different execution units', 'Predicting memory access patterns for the cache prefetcher',
    1,
    'Modern deep pipelines (20+ stages) compute branch conditions late in the pipeline. Without branch prediction, the CPU would stall for ~20 cycles per branch. Branch predictors (static, 2-bit saturating counter, tournament, TAGE) guess whether the branch is taken or not. On misprediction, the pipeline is flushed (wasted work). Prediction accuracy of 95%+ is typical.',
    'In a deep pipeline, the CPU fetches instructions before knowing if a branch is taken. What happens if the guess is wrong?'
  ),
(
    'Computer Organisation', 'Medium', 60,
    'What does "instruction pipelining" improve?',
    'Latency of individual instructions', 'Throughput (number of instructions completed per unit time)',
    'The accuracy of branch prediction', 'Cache hit rate',
    1,
    'Pipelining does NOT reduce the latency (time to complete one instruction — still k clock cycles for k stages). It improves THROUGHPUT by overlapping multiple instructions. In steady state, one instruction completes per clock cycle (ideal). Throughput approaches k times that of non-pipelined for long instruction streams.',
    'Does pipelining make any single instruction faster? Or does it let multiple instructions execute simultaneously?'
  );
