-- ==========================================
-- Ranked Questions: Operating Systems
-- ==========================================

INSERT INTO public.ranked_questions
  (topic, difficulty, time_limit, question, option_a, option_b, option_c, option_d, correct_index, explanation)
VALUES
(
    'Operating Systems', 'Hard', 75,
    'In a system using the Banker''s Algorithm for deadlock avoidance, a process is in a SAFE state if:',
    'All resources are currently available',
    'There exists a safe sequence of process execution',
    'No process is waiting for resources',
    'The system is in a consistent state',
    1,
    'The Banker''s Algorithm defines a safe state as one where there exists at least one safe sequence — an ordering of all processes such that each process can obtain all its required resources and complete, then releasing those resources for subsequent processes.'
  ),
(
    'Operating Systems', 'Easy', 45,
    'What is the primary function of an operating system''s kernel?',
    'Providing user interface', 'Managing hardware resources and providing services to applications', 'Running application programs', 'Storing persistent data',
    1,
    'The kernel is the core of the OS that manages hardware resources (CPU, memory, I/O), provides system calls for applications, handles interrupts, and ensures secure resource sharing between processes.'
  ),
(
    'Operating Systems', 'Medium', 60,
    'In the context of process states, which transition is NOT valid in a typical 5-state process model?',
    'Ready → Running', 'Running → Blocked', 'Blocked → Running', 'Running → Ready',
    2,
    'In the 5-state model, a blocked process cannot directly transition to Running. It must first move to Ready (when the I/O event completes), then the scheduler can move it to Running. Direct Blocked→Running bypass is invalid.'
  ),
(
    'Operating Systems', 'Hard', 90,
    'Consider the following set of processes for FCFS scheduling: P1(0ms, burst 24ms), P2(0ms, burst 3ms), P3(0ms, burst 3ms). What is the average waiting time?',
    '17 ms', '18 ms', '27 ms', '0 ms',
    0,
    'FCFS order: P1(0-24), P2(24-27), P3(27-30). Waiting times: P1=0, P2=24, P3=27. Average = (0+24+27)/3 = 51/3 = 17 ms. FCFS suffers from the convoy effect where short processes wait behind long ones.'
  ),
(
    'Operating Systems', 'Medium', 75,
    'Which of the following is a necessary condition for deadlock (Coffman conditions)?',
    'Preemption is always possible', 'Resources can be shared simultaneously', 'Circular wait among processes', 'All processes run at the same priority',
    2,
    'The four necessary Coffman conditions for deadlock are: Mutual Exclusion, Hold and Wait, No Preemption, and Circular Wait. All four must hold simultaneously for deadlock to occur. Breaking any one prevents deadlock.'
  ),
(
    'Operating Systems', 'Hard', 90,
    'In the Producer-Consumer problem with a bounded buffer of size N, using semaphores, which semaphore ensures the producer waits when the buffer is full?',
    'mutex', 'empty', 'full', 'binary semaphore',
    1,
    'The ''empty'' semaphore is initialized to N (buffer size) and decremented by the producer before adding an item. When empty=0, the buffer is full and the producer blocks. The ''full'' semaphore (init=0) is decremented by the consumer.'
  ),
(
    'Operating Systems', 'Medium', 60,
    'What is the difference between internal and external fragmentation in memory management?',
    'Internal: wasted space inside allocated block; External: wasted space between allocated blocks',
    'Internal: wasted space between processes; External: wasted space within processes',
    'Both refer to the same type of memory waste',
    'Internal: caused by segmentation; External: caused by paging',
    0,
    'Internal fragmentation is wasted space within an allocated memory block (allocated more than needed). External fragmentation is wasted space between allocated blocks — free memory exists but in non-contiguous chunks too small to satisfy requests.'
  ),
(
    'Operating Systems', 'Hard', 90,
    'In the OPTIMAL page replacement algorithm, which page is selected for replacement?',
    'The page that was least recently used', 'The page that will not be used for the longest time in the future', 'The page loaded first (FIFO)', 'A randomly selected page',
    1,
    'The Optimal (OPT/MIN) algorithm replaces the page that will not be referenced for the longest time in the future. It produces the minimum number of page faults but is theoretical (requires future knowledge). Used as a benchmark.'
  ),
(
    'Operating Systems', 'Easy', 45,
    'Which system call is used to create a new process in UNIX/Linux?',
    'exec()', 'create()', 'fork()', 'spawn()',
    2,
    'fork() creates a new process (child) that is an exact copy of the calling process (parent), including code, data, and file descriptors. The child gets a return value of 0 from fork(); the parent gets the child''s PID.'
  ),
(
    'Operating Systems', 'Medium', 75,
    'Belady''s Anomaly states that in the FIFO page replacement algorithm:',
    'More frames always lead to fewer page faults', 'Increasing the number of frames can sometimes increase page faults', 'Fewer frames always lead to more page faults', 'Page faults are independent of the number of frames',
    1,
    'Belady''s Anomaly is the counterintuitive phenomenon in FIFO page replacement where increasing the number of page frames can actually increase the number of page faults for certain reference strings. LRU and OPT do not exhibit this anomaly.'
  ),
(
    'Operating Systems', 'Hard', 90,
    'In a multi-threaded program, which of the following is NOT shared between threads of the same process?',
    'Heap memory', 'Global variables', 'Program counter and registers', 'Open file descriptors',
    2,
    'Each thread has its own program counter, register set, and stack. Threads within the same process share the heap, global/static variables, open file descriptors, signal handlers, and code segment. This sharing makes thread communication efficient but requires synchronization.'
  ),
(
    'Operating Systems', 'Medium', 75,
    'In the context of OS scheduling, "aging" is a technique used to:',
    'Reduce the priority of long-running processes', 'Gradually increase the priority of waiting processes to prevent starvation',
    'Monitor process age to optimize memory allocation', 'Periodically reset all process priorities',
    1,
    'Aging prevents starvation in priority scheduling by gradually increasing the priority of processes that have been waiting for a long time. As a low-priority process ages in the ready queue, its priority rises until it eventually gets CPU time.'
  ),
(
    'Operating Systems', 'Hard', 90,
    'The "working set" model in virtual memory management is used to:',
    'Determine the optimal page size for a system', 'Track the set of pages actively used by a process in a time window to decide how many frames to allocate',
    'Implement FIFO page replacement efficiently', 'Measure CPU utilization across processes',
    1,
    'The working set W(t, Δ) of a process at time t is the set of pages referenced in the past Δ time units. The OS allocates frames ≥ |W(t, Δ)| to each process to prevent thrashing. If total working set sizes exceed total frames, the OS must suspend some processes.'
  ),
(
    'Operating Systems', 'Medium', 60,
    'The "critical section problem" requires that any solution satisfy which three conditions?',
    'Fairness, Speed, Correctness', 'Mutual Exclusion, Progress, Bounded Waiting', 'Atomicity, Isolation, Durability', 'Synchronization, Communication, Termination',
    1,
    'A correct critical section solution must satisfy: (1) Mutual Exclusion: only one process in CS at a time, (2) Progress: if no process is in CS and some want to enter, selection cannot be postponed indefinitely, (3) Bounded Waiting: a bound exists on how many times other processes can enter CS after a process requests entry.'
  ),
(
    'Operating Systems', 'Easy', 45,
    'What is the purpose of a "context switch" in an operating system?',
    'Switching between user and kernel mode', 'Saving the state of the current process and loading the state of another process for CPU execution',
    'Switching between different I/O devices', 'Changing the memory allocation of a process',
    1,
    'A context switch occurs when the OS switches the CPU from executing one process to another. It involves: (1) saving the current process''s context (registers, PC, stack pointer) to its PCB, and (2) loading the new process''s context from its PCB. Context switches incur overhead.'
  ),
(
    'Operating Systems', 'Medium', 75,
    'A "reentrant" function in operating systems and concurrent programming is one that:',
    'Can only be called once per execution', 'Can be safely called simultaneously by multiple threads because it uses only local variables and does not modify shared state',
    'Automatically locks shared resources before accessing them', 'Calls itself recursively',
    1,
    'A reentrant function can be interrupted and called again before the previous invocation completes (e.g., in signal handlers, multithreaded code). It is safe because it uses only local (stack) variables and parameters, not shared global/static state that could be corrupted by concurrent access.'
  ),
(
    'Operating Systems', 'Hard', 90,
    'In the context of memory-mapped files, mapping a file into virtual address space allows:',
    'The file to be accessed only sequentially', 'File I/O to be performed using memory load/store instructions, with the OS handling paging between disk and RAM transparently',
    'Multiple processes to edit the same file simultaneously without synchronization', 'The file to be encrypted automatically',
    1,
    'Memory-mapped files map a file (or file portion) into a process''s virtual address space. Reads/writes to the mapped addresses are translated to file I/O by the OS using demand paging. Benefits: zero-copy I/O, easy file sharing between processes (shared mapping), and random access without seek calls.'
  );
