-- ==========================================
-- Practice Questions: DBMS
-- ==========================================

INSERT INTO public.practice_questions
  (topic, difficulty, time_limit, question, option_a, option_b, option_c, option_d, correct_index, explanation, hint)
VALUES
(
    'DBMS', 'Medium', 60,
    'Which normal form is violated when a non-prime attribute depends on only part of a composite primary key?',
    '1NF', '2NF', '3NF', 'BCNF',
    1,
    '2NF (Second Normal Form) is violated when a non-prime attribute has a partial dependency on a composite primary key.',
    'Focus on the word "partial" — the attribute depends on only a part of the composite key, not the whole key.'
  ),
(
    'DBMS', 'Easy', 45,
    'What does the SELECT DISTINCT statement do in SQL?',
    'Selects all rows including duplicates', 'Selects only unique rows, removing duplicate result rows',
    'Selects rows in sorted order', 'Selects rows that match exactly one condition',
    1,
    'SELECT DISTINCT eliminates duplicate rows from the result set. It applies after projection — if two rows have identical values in all selected columns, only one is returned. DISTINCT adds overhead (requires sorting or hashing to detect duplicates).',
    'Think about what "distinct" means in English — what would you want distinct records to exclude?'
  ),
(
    'DBMS', 'Medium', 75,
    'In database normalization, what is a transitive dependency?',
    'A → B where B is a primary key', 'A → B → C where A is the primary key and C is a non-prime attribute depending on B (not directly on A)',
    'When two attributes always have the same value', 'A dependency between two tables',
    1,
    'A transitive dependency exists when A → B and B → C (where A is the candidate key, B and C are non-prime attributes). C transitively depends on A through B. 3NF requires removing transitive dependencies by decomposing the relation.',
    'The word "transitive" implies a chain: A → B → C. What does removing the middle link (B) from C''s dependency require?'
  ),
(
    'DBMS', 'Hard', 90,
    'In Two-Phase Locking (2PL), which variant guarantees freedom from deadlocks?',
    'Basic 2PL', 'Conservative (Static) 2PL', 'Strict 2PL', 'Rigorous 2PL',
    1,
    'Conservative (Static) 2PL requires a transaction to acquire ALL locks it will ever need before starting execution. This prevents deadlock (no circular waiting can form) but reduces concurrency. Strict 2PL holds all exclusive locks until commit (prevents cascading aborts) but can deadlock. Rigorous 2PL holds all locks until commit.',
    'Deadlock requires "hold and wait." Which 2PL variant eliminates this by acquiring all locks upfront?'
  ),
(
    'DBMS', 'Medium', 60,
    'What is a "dirty read" in database transactions?',
    'Reading data from a corrupted disk sector', 'Reading uncommitted data written by another transaction that may later be rolled back',
    'Reading data that has been modified but not yet flushed to disk', 'Reading an outdated version of data',
    1,
    'A dirty read occurs when Transaction T1 reads data modified by T2, which has not yet committed. If T2 later aborts/rolls back, T1 has read data that never officially existed. Prevented at READ COMMITTED isolation level and above.',
    'The word "dirty" refers to uncommitted data. What problem arises if you read data that might disappear?'
  ),
(
    'DBMS', 'Easy', 45,
    'Which SQL join returns only rows that have matching values in both tables?',
    'LEFT JOIN', 'RIGHT JOIN', 'FULL OUTER JOIN', 'INNER JOIN',
    3,
    'INNER JOIN returns only rows where the join condition is satisfied in BOTH tables — rows with no match in either table are excluded. LEFT JOIN returns all rows from the left table. RIGHT JOIN from the right. FULL OUTER JOIN returns all rows from both tables.',
    'Which join type includes ONLY the overlap between two sets (like intersection in set theory)?'
  ),
(
    'DBMS', 'Hard', 90,
    'In the context of database indexing, a B+ tree index on a column with low cardinality (e.g., a boolean flag) is:',
    'Very efficient because fewer index entries exist', 'Often inefficient because the index may not reduce the number of rows scanned significantly',
    'Always preferred over a full table scan', 'Ideal for equality queries',
    1,
    'Low cardinality columns (few distinct values, e.g., boolean, gender) make poor B+ tree index candidates. For example, an index on a boolean column where 50% of rows are TRUE means accessing ~50% of the table through the index — worse than a full table scan due to random I/O. Bitmap indexes work better for low cardinality.',
    'Think about what happens when half the rows match your query condition. Does an index help when you need to visit half the table anyway?'
  ),
(
    'DBMS', 'Medium', 60,
    'What does the ROLLBACK statement do in SQL?',
    'Permanently saves all changes made in the current transaction', 'Undoes all changes made in the current transaction since the last COMMIT or SAVEPOINT',
    'Deletes all rows from a table', 'Restores the database to its initial state',
    1,
    'ROLLBACK undoes all data modifications made in the current transaction since the last COMMIT or explicit SAVEPOINT, restoring data to the state before the transaction began. It releases locks held by the transaction. ROLLBACK TO SAVEPOINT undoes to a specific savepoint within the transaction.',
    'ROLLBACK is the "undo" operation for a transaction. It reverts changes that have not been committed yet.'
  ),
(
    'DBMS', 'Hard', 90,
    'In relational algebra, the result of σ_{condition}(R ⋈ S) is equivalent to which expression for query optimization?',
    'σ_{condition}(R) ⋈ S (always)', 'Pushing the selection down before the join if the condition involves only attributes of one relation',
    'R ⋈ σ_{condition}(S) (always)', 'The expressions are never equivalent',
    1,
    'Selection pushdown is a key query optimization: if a condition involves only attributes of R, σ_cond(R ⋈ S) = σ_cond(R) ⋈ S. Applying selection before the join reduces the size of R first, making the join cheaper. This is valid when the condition does not reference attributes from S.',
    'Applying a filter (selection) before a join reduces the number of rows being joined. When is it safe to do this?'
  ),
(
    'DBMS', 'Easy', 45,
    'What is the purpose of a database index?',
    'To enforce data integrity constraints', 'To speed up data retrieval at the cost of additional storage and slower writes',
    'To encrypt sensitive data', 'To backup the database automatically',
    1,
    'An index is a data structure (typically B+ tree or hash) built on one or more columns to speed up query retrieval. Indexes require extra storage space and slow down INSERT/UPDATE/DELETE (must update both data and index), but dramatically speed up SELECT queries on indexed columns.',
    'An index is like a book''s index — it helps you find information faster. What is the trade-off?'
  );
