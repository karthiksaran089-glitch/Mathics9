-- ============================================================
-- GateMathics: Analytics Performance Overview Data Layer
-- ============================================================
-- Dedicated analytics views and functions for the Performance
-- Overview page. Provides practice vs ranked breakdown,
-- accuracy/speed trends, weekly summaries, and a
-- recommendation engine.
-- ============================================================
-- NOTE: This migration adds to (does not replace) the views
-- in 20260604110000_analytics_dashboard.sql
-- ============================================================

-- 1. PRACTICE VS RANKED MODE BREAKDOWN
-- Side-by-side comparison of practice vs ranked session stats
DROP VIEW IF EXISTS public.analytics_mode_breakdown CASCADE;
CREATE VIEW public.analytics_mode_breakdown WITH (security_invoker = true) AS
SELECT
  sh.user_id,
  -- Practice mode stats
  COUNT(*) FILTER (WHERE sh.mode = 'Practice') AS practice_sessions,
  COALESCE(SUM(sh.questions_total) FILTER (WHERE sh.mode = 'Practice'), 0) AS practice_questions,
  COALESCE(SUM(sh.questions_correct) FILTER (WHERE sh.mode = 'Practice'), 0) AS practice_correct,
  COALESCE(SUM(sh.questions_incorrect) FILTER (WHERE sh.mode = 'Practice'), 0) AS practice_incorrect,
  COALESCE(SUM(sh.questions_timeout) FILTER (WHERE sh.mode = 'Practice'), 0) AS practice_timeout,
  COALESCE(ROUND(AVG(sh.accuracy) FILTER (WHERE sh.mode = 'Practice'), 1), 0) AS practice_avg_accuracy,
  COALESCE(ROUND(AVG(sh.avg_speed_seconds) FILTER (WHERE sh.mode = 'Practice'), 1), 0) AS practice_avg_speed,
  COALESCE(SUM(CASE WHEN sh.mode = 'Practice' THEN sh.hints_used ELSE 0 END), 0) AS practice_hints_used,
  -- Ranked mode stats
  COUNT(*) FILTER (WHERE sh.mode = 'Ranked') AS ranked_sessions,
  COALESCE(SUM(sh.questions_total) FILTER (WHERE sh.mode = 'Ranked'), 0) AS ranked_questions,
  COALESCE(SUM(sh.questions_correct) FILTER (WHERE sh.mode = 'Ranked'), 0) AS ranked_correct,
  COALESCE(SUM(sh.questions_incorrect) FILTER (WHERE sh.mode = 'Ranked'), 0) AS ranked_incorrect,
  COALESCE(SUM(sh.questions_timeout) FILTER (WHERE sh.mode = 'Ranked'), 0) AS ranked_timeout,
  COALESCE(ROUND(AVG(sh.accuracy) FILTER (WHERE sh.mode = 'Ranked'), 1), 0) AS ranked_avg_accuracy,
  COALESCE(ROUND(AVG(sh.avg_speed_seconds) FILTER (WHERE sh.mode = 'Ranked'), 1), 0) AS ranked_avg_speed,
  COALESCE(SUM(sh.lp_change) FILTER (WHERE sh.mode = 'Ranked'), 0) AS ranked_net_lp_change,
  COALESCE(SUM(CASE WHEN sh.mode = 'Ranked' AND sh.lp_change > 0 THEN sh.lp_change ELSE 0 END), 0) AS ranked_lp_gained,
  COALESCE(SUM(CASE WHEN sh.mode = 'Ranked' AND sh.lp_change < 0 THEN ABS(sh.lp_change) ELSE 0 END), 0) AS ranked_lp_lost,
  -- Combined totals
  COUNT(*) AS total_sessions,
  COALESCE(SUM(sh.questions_total), 0) AS total_questions,
  COALESCE(SUM(sh.questions_correct), 0) AS total_correct,
  COALESCE(SUM(sh.questions_incorrect), 0) AS total_incorrect,
  COALESCE(SUM(sh.questions_timeout), 0) AS total_timeout
FROM public.analytics_session_history sh
GROUP BY sh.user_id;

-- 2. ACCURACY TREND VIEW
-- Accuracy over time for trend charts (last 20 sessions)
DROP VIEW IF EXISTS public.analytics_accuracy_trend CASCADE;
CREATE VIEW public.analytics_accuracy_trend WITH (security_invoker = true) AS
SELECT
  user_id,
  session_id,
  session_date,
  mode,
  accuracy,
  avg_speed_seconds,
  questions_total,
  questions_correct,
  ROW_NUMBER() OVER (PARTITION BY user_id ORDER BY session_date ASC) AS seq
FROM public.analytics_session_history
ORDER BY user_id, session_date ASC;

-- 3. WEEKLY PERFORMANCE SUMMARY
-- Aggregated weekly stats for trend analysis
DROP VIEW IF EXISTS public.analytics_weekly_summary CASCADE;
CREATE VIEW public.analytics_weekly_summary WITH (security_invoker = true) AS
SELECT
  user_id,
  DATE_TRUNC('week', session_date)::DATE AS week_start,
  COUNT(*) AS sessions,
  SUM(questions_total) AS questions,
  SUM(questions_correct) AS correct,
  ROUND(AVG(accuracy), 1) AS avg_accuracy,
  ROUND(AVG(avg_speed_seconds), 1) AS avg_speed,
  SUM(CASE WHEN mode = 'Ranked' THEN lp_change ELSE 0 END) AS net_lp
FROM public.analytics_session_history
GROUP BY user_id, DATE_TRUNC('week', session_date)
ORDER BY user_id, DATE_TRUNC('week', session_date) DESC;

-- 4. RECOMMENDATIONS FUNCTION
-- Returns personalized next-step recommendations based on user data
DROP FUNCTION IF EXISTS public.get_analytics_recommendations;
CREATE FUNCTION public.get_analytics_recommendations(p_user_id UUID)
RETURNS JSONB
LANGUAGE plpgsql SECURITY DEFINER
AS $$
DECLARE
  v_rec JSONB := '[]'::JSONB;
  v_stats RECORD;
  v_weak TEXT[];
BEGIN
  SELECT * INTO v_stats FROM public.analytics_user_summary WHERE user_id = p_user_id;
  IF v_stats IS NULL THEN RETURN jsonb_build_object('recommendations', v_rec); END IF;

  -- Get weak topics (below 55% mastery)
  SELECT ARRAY_AGG(topic) INTO v_weak
  FROM public.analytics_weak_topics WHERE user_id = p_user_id;

  -- 1. Practice weak topics
  IF v_weak IS NOT NULL AND array_length(v_weak, 1) > 0 THEN
    v_rec := v_rec || jsonb_build_object(
      'type', 'practice_weak', 'priority', 1,
      'title', 'Practice ' || v_weak[1],
      'description', 'Your mastery in ' || v_weak[1] || ' needs attention. Focus here to boost your score.',
      'action', 'Start Practice', 'href', '/practice'
    );
  END IF;

  -- 2. Ranked push
  IF v_stats.total_ranked_sessions = 0 THEN
    v_rec := v_rec || jsonb_build_object(
      'type', 'first_ranked', 'priority', 2,
      'title', 'Try Ranked Mode',
      'description', 'Test your skills in competitive ranked matches and earn LP!',
      'action', 'Play Ranked', 'href', '/ranked-mode-screen'
    );
  ELSIF v_stats.lp < 2500 THEN
    v_rec := v_rec || jsonb_build_object(
      'type', 'rank_push', 'priority', 2,
      'title', 'Push Your Rank',
      'description', 'Play ranked matches to climb the leaderboard.',
      'action', 'Play Ranked', 'href', '/ranked-mode-screen'
    );
  END IF;

  -- 3. Streak suggestion
  IF v_stats.daily_streak < 3 THEN
    v_rec := v_rec || jsonb_build_object(
      'type', 'streak', 'priority', 3,
      'title', 'Build Your Streak',
      'description', 'Your streak is ' || v_stats.daily_streak || ' days. Play today to keep it going!',
      'action', 'Play Now', 'href', '/practice'
    );
  END IF;

  -- 4. Speed improvement
  IF v_stats.avg_answer_speed_seconds > 60 THEN
    v_rec := v_rec || jsonb_build_object(
      'type', 'speed', 'priority', 4,
      'title', 'Improve Speed',
      'description', 'Your avg answer speed is ' || ROUND(v_stats.avg_answer_speed_seconds) || 's. Practice to get faster!',
      'action', 'Practice Now', 'href', '/practice'
    );
  END IF;

  RETURN jsonb_build_object('recommendations', v_rec);
END;
$$;

-- 5. NEW INDEXES for analytics performance
CREATE INDEX IF NOT EXISTS idx_practice_sessions_accuracy
  ON public.practice_sessions(accuracy DESC);
CREATE INDEX IF NOT EXISTS idx_ranked_sessions_lp_change
  ON public.ranked_sessions(lp_change);
CREATE INDEX IF NOT EXISTS idx_user_profiles_lp
  ON public.user_profiles(lp);
