-- ==========================================
-- Ranked Questions: Software Engineering
-- ==========================================

INSERT INTO public.ranked_questions
  (topic, difficulty, time_limit, question, option_a, option_b, option_c, option_d, correct_index, explanation)
VALUES
(
    'Software Engineering', 'Easy', 45,
    'In the context of software testing, which technique tests the software without knowledge of its internal structure?',
    'White-box testing', 'Grey-box testing', 'Black-box testing', 'Structural testing',
    2,
    'Black-box testing (also called functional testing) tests software from the user''s perspective without knowledge of internal code structure. Testers provide inputs and verify outputs against specifications.'
  ),
(
    'Software Engineering', 'Easy', 45,
    'What does UML stand for, and what is its primary use?',
    'Universal Modeling Language, used for programming', 'Unified Modeling Language, used for visualizing and designing software systems',
    'Unified Machine Logic, used for hardware design', 'Universal Machine Language, used for low-level coding',
    1,
    'UML (Unified Modeling Language) is a standardized visual language for specifying, visualizing, constructing, and documenting software systems. It includes various diagram types (class, sequence, use case, activity) for different aspects of system design.'
  ),
(
    'Software Engineering', 'Medium', 60,
    'In agile software development, a "Sprint" refers to:',
    'A final testing phase before release', 'A short, time-boxed iteration (typically 2-4 weeks) in which a potentially shippable product increment is created',
    'A performance optimization technique', 'A type of regression testing',
    1,
    'In Scrum (an Agile framework), a Sprint is a fixed-length iteration (2-4 weeks) during which the development team completes a set of backlog items. Each Sprint ends with a potentially deployable product increment and a retrospective.'
  ),
(
    'Software Engineering', 'Hard', 90,
    'In the context of software metrics, McCabe''s Cyclomatic Complexity is calculated as:',
    'V(G) = Nodes - Edges + 2', 'V(G) = Edges - Nodes + 2', 'V(G) = Edges - Nodes + 2·Connected components',
    'V(G) = Number of decision points + 1',
    3,
    'McCabe''s Cyclomatic Complexity V(G) = E - N + 2P (where E=edges, N=nodes, P=connected components). For a single program P=1: V(G) = E - N + 2. Equivalently, V(G) = number of binary decision points (if, while, for, case) + 1. Measures code complexity and testability.'
  ),
(
    'Software Engineering', 'Medium', 75,
    'What is the purpose of a "code review" in software development?',
    'Automatically testing code for runtime errors', 'Systematically examining code by peers to find defects, improve quality, and share knowledge',
    'Measuring code execution performance', 'Automatically generating documentation',
    1,
    'Code review (peer review) is a systematic examination of source code by developers other than the author. It aims to find bugs, security vulnerabilities, and design issues; ensure coding standards; and share knowledge across the team. Studies show it is one of the most effective defect detection techniques.'
  ),
(
    'Software Engineering', 'Easy', 45,
    'Which software development model delivers working software in increments, with each increment adding functionality?',
    'Waterfall Model', 'V-Model', 'Incremental Model', 'Spiral Model',
    2,
    'The Incremental Model divides the system into increments, each delivering a working subset of functionality. Each increment is developed through all SDLC phases. Users get usable software early, and requirements can evolve between increments.'
  ),
(
    'Software Engineering', 'Hard', 90,
    'In software testing, the difference between verification and validation is:',
    'Verification tests the final product; validation tests during development', 'Verification checks if we built the product right (conformance to specifications); validation checks if we built the right product (meets user needs)',
    'They are the same activity with different names', 'Verification is automated; validation is manual',
    1,
    'Verification: "Are we building the product right?" — checks conformance to specifications through reviews, inspections, walkthroughs. Validation: "Are we building the right product?" — checks that the final product meets actual user needs through testing on real/simulated environment.'
  ),
(
    'Software Engineering', 'Medium', 60,
    'What is "technical debt" in software engineering?',
    'The financial cost of software licenses', 'The implied cost of rework caused by choosing an easy/quick solution now instead of a better approach that would take longer',
    'The cost of training developers on new technologies', 'Hardware costs for running software systems',
    1,
    'Technical debt (coined by Ward Cunningham) represents the accumulated cost of shortcuts, quick fixes, and suboptimal design decisions. Like financial debt, it accrues "interest" — the longer it remains, the more expensive it becomes to fix, slowing future development.'
  ),
(
    'Software Engineering', 'Hard', 90,
    'In Continuous Integration (CI), the primary goal is:',
    'Automatically deploying every code change to production', 'Frequently merging developer code changes into a shared repository, with automated builds and tests to detect integration errors quickly',
    'Replacing manual testing entirely with automated tests', 'Managing version control branches',
    1,
    'CI (Continuous Integration) requires developers to merge code to the main branch frequently (multiple times daily). Each merge triggers automated builds and tests, catching integration errors early when they are cheapest to fix. CI is distinct from CD (Continuous Delivery/Deployment).'
  ),
(
    'Software Engineering', 'Easy', 45,
    'What does the acronym SOLID stand for in object-oriented design principles?',
    'Scalable, Open, Linked, Integrated, Distributed', 'Single responsibility, Open-closed, Liskov substitution, Interface segregation, Dependency inversion',
    'Structured, Object-oriented, Layered, Integrated, Dynamic', 'Simple, Optimized, Lightweight, Isolated, Decoupled',
    1,
    'SOLID is an acronym for five OOP design principles: (S)ingle Responsibility, (O)pen-Closed, (L)iskov Substitution, (I)nterface Segregation, (D)ependency Inversion. These principles promote maintainable, flexible, and scalable code architecture.'
  ),
(
    'Software Engineering', 'Medium', 75,
    'In design patterns, the Observer pattern is used to:',
    'Ensure only one instance of a class exists', 'Define a one-to-many dependency so when one object changes state, all dependents are notified automatically',
    'Provide a simplified interface to a complex subsystem', 'Convert an interface to another interface expected by clients',
    1,
    'The Observer (Publish-Subscribe) pattern defines a one-to-many relationship. A subject (publisher) maintains a list of observers (subscribers). When the subject''s state changes, it notifies all registered observers automatically. Used in event systems and MVC frameworks.'
  ),
(
    'Software Engineering', 'Hard', 90,
    'In the context of software architecture, what is the key difference between microservices and monolithic architecture?',
    'Microservices use more programming languages than monolithic', 'Microservices decompose an application into small, independently deployable services; monolithic has all components in one deployable unit',
    'Monolithic architecture always performs better than microservices', 'Microservices cannot use databases',
    1,
    'Monolithic architecture packages all functionality (UI, business logic, data access) into a single deployable unit. Microservices decompose the application into independently deployable services, each with its own process and database, communicating via APIs. Microservices offer scalability and deployment flexibility at the cost of distributed system complexity.'
  ),
(
    'Software Engineering', 'Medium', 60,
    'In object-oriented design, the Dependency Inversion Principle (DIP) states:',
    'High-level modules should depend on low-level modules directly', 'Both high-level and low-level modules should depend on abstractions; abstractions should not depend on details',
    'Dependencies should be minimized by using fewer classes', 'Low-level modules should control high-level modules',
    1,
    'DIP (the ''D'' in SOLID) states: (1) High-level modules should not depend on low-level modules; both should depend on abstractions (interfaces). (2) Abstractions should not depend on details; details should depend on abstractions. This enables loose coupling and easier testing.'
  ),
(
    'Software Engineering', 'Medium', 60,
    'In software design, a "design pattern" is best described as:',
    'A specific code implementation to copy into projects', 'A reusable solution template to a commonly occurring problem in software design',
    'A formal specification language for software systems', 'A testing methodology for software validation',
    1,
    'Design patterns (popularized by the "Gang of Four") are reusable, named solutions to commonly recurring software design problems. They are not code but templates describing how to solve a problem. Categorized as Creational (object creation), Structural (composition), and Behavioral (communication) patterns.'
  ),
(
    'Software Engineering', 'Hard', 90,
    'In software quality assurance, what is the difference between "fault," "error," and "failure"?',
    'They are synonymous terms for software bugs', 'Fault: static defect in code; Error: incorrect internal state during execution; Failure: observable incorrect behavior',
    'Fault: runtime error; Error: compile-time error; Failure: logical error', 'Fault: hardware problem; Error: software problem; Failure: system crash',
    1,
    'IEEE definitions: Fault (defect): static imperfection in code (a bug). Error: an incorrect internal state resulting from the fault executing. Failure: externally observable incorrect behavior resulting from an error reaching the output. Not all faults lead to errors, and not all errors lead to failures.'
  ),
(
    'Software Engineering', 'Medium', 60,
    'In the context of version control, what does "git rebase" do compared to "git merge"?',
    'Rebase creates a merge commit; merge does not', 'Rebase rewrites commit history by moving commits to a new base; merge preserves history with a merge commit',
    'They are functionally identical', 'Rebase is only used for resolving conflicts',
    1,
    'Git merge creates a new "merge commit" that joins two branches, preserving complete history. Git rebase moves/replays commits from one branch onto another, creating a linear history without merge commits. Rebase rewrites commit hashes (avoid rebasing public/shared branches).'
  ),
(
    'Software Engineering', 'Hard', 90,
    'In the context of software refactoring, what is the "Strangler Fig Pattern"?',
    'A design pattern for handling null pointer exceptions', 'A technique for incrementally migrating a legacy system by building new functionality around it until the old system can be retired',
    'A refactoring pattern for deeply nested conditionals', 'A method for strangling memory leaks in C++ programs',
    1,
    'The Strangler Fig Pattern (coined by Martin Fowler) is a strategy for migrating a legacy system: new features are built as separate services around the legacy system. Over time, new implementations replace legacy functionality piece by piece. Eventually, the old system is "strangled" and can be removed.'
  );
