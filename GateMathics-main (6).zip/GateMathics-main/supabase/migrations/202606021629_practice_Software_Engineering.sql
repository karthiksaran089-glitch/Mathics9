-- ==========================================
-- Practice Questions: Software Engineering
-- ==========================================

INSERT INTO public.practice_questions
  (topic, difficulty, time_limit, question, option_a, option_b, option_c, option_d, correct_index, explanation, hint)
VALUES
(
    'Software Engineering', 'Easy', 45,
    'In the context of software testing, which technique tests the software without knowledge of its internal structure?',
    'White-box testing', 'Grey-box testing', 'Black-box testing', 'Structural testing',
    2,
    'Black-box testing (also called functional testing) tests software from the user''s perspective without knowledge of internal code structure.',
    'Think about what "black box" means — you cannot see inside it. You only observe inputs and outputs.'
  ),
(
    'Software Engineering', 'Easy', 45,
    'What is the purpose of version control systems like Git?',
    'To automatically test code for bugs', 'To track changes to code over time, enable collaboration, and allow reverting to previous versions',
    'To compile and deploy code automatically', 'To enforce coding style standards',
    1,
    'Version control systems (VCS) track the history of code changes, who made them, and why. They enable multiple developers to work concurrently (branching/merging), allow reverting to any previous state, and maintain a complete audit trail of the project''s evolution.',
    'Think about what problems arise when multiple developers edit the same files without a coordination system.'
  ),
(
    'Software Engineering', 'Medium', 75,
    'What is the difference between unit testing and integration testing?',
    'Unit tests test the whole system; integration tests test individual functions',
    'Unit tests test individual components in isolation; integration tests test how components work together',
    'Unit testing is automated; integration testing is manual', 'They test the same things with different tools',
    1,
    'Unit testing tests the smallest testable units (functions, methods, classes) in isolation, using mocks/stubs for dependencies. Integration testing tests the interaction between multiple components/modules, verifying they work correctly when combined. Integration tests find interface issues that unit tests miss.',
    'What does "unit" mean in unit testing? What does "integration" mean in integration testing?'
  ),
(
    'Software Engineering', 'Hard', 90,
    'In the context of software design, what is the "Dependency Injection" pattern?',
    'A pattern where objects create their own dependencies', 'A pattern where dependencies are provided to an object from the outside rather than created internally, improving testability and loose coupling',
    'A pattern for managing database connections', 'A way to inject code at runtime using reflection',
    1,
    'Dependency Injection (DI) inverts control: instead of a class creating its dependencies (e.g., new DatabaseConnection()), the dependencies are provided by an external framework or caller. This enables easy substitution of dependencies (e.g., mocking in tests), promotes loose coupling, and follows the Dependency Inversion Principle.',
    'If a class creates its own dependencies, how easy is it to test it in isolation? What if you could pass in the dependencies instead?'
  ),
(
    'Software Engineering', 'Medium', 60,
    'What does "DRY" stand for in software engineering, and what does it mean?',
    'Do Repeat Yourself — document everything thoroughly', 'Don''t Repeat Yourself — every piece of knowledge should have a single authoritative representation',
    'Data Repository Yield — a database design principle', 'Dynamic Runtime Yield — an optimization technique',
    1,
    'DRY (Don''t Repeat Yourself) is a principle stating that every piece of knowledge or logic should have a single, unambiguous, authoritative representation in a system. Duplication leads to inconsistency when one copy is updated but another is not. DRY is achieved through abstraction, functions, and modules.',
    'What problem occurs when the same logic exists in multiple places and one copy is updated but others are not?'
  ),
(
    'Software Engineering', 'Easy', 45,
    'In software testing, what is a "regression test"?',
    'A test that predicts future software failures', 'A test that verifies previously working functionality still works after code changes',
    'A test of performance under heavy load', 'A test of newly added features only',
    1,
    'Regression testing re-runs existing tests after code changes (bug fixes, new features, refactoring) to ensure previously working functionality has not been broken. Automated regression test suites are essential in CI/CD pipelines. The term "regression" means going back (returning to a broken state).',
    'The word "regression" means going backward. What does a regression test prevent from going backward?'
  ),
(
    'Software Engineering', 'Hard', 90,
    'What is the "Open-Closed Principle" in SOLID design principles?',
    'Software should be open to all programmers and closed to clients', 'Software entities should be open for extension but closed for modification — add new behavior without changing existing code',
    'All functions should be open (public) and all data closed (private)', 'Software should be open-source and have closed-source components',
    1,
    'OCP (Bertrand Meyer, popularized by Robert Martin): classes/modules should be designed so new functionality can be added by extending (inheritance, composition, plugins) without modifying existing code. This prevents bugs from modifications and keeps existing tests passing. Strategy and Template Method patterns help achieve OCP.',
    'How can you add new behavior to a class without changing its code? Think about inheritance and interfaces.'
  ),
(
    'Software Engineering', 'Medium', 75,
    'What is the primary difference between the Waterfall and Agile software development models?',
    'Waterfall uses automated testing; Agile uses manual testing', 'Waterfall follows rigid sequential phases; Agile is iterative and adaptive to changing requirements',
    'Agile is more expensive than Waterfall', 'Waterfall is designed for small projects; Agile for large ones',
    1,
    'Waterfall follows strict sequential phases (Requirements → Design → Implementation → Testing → Deployment) with no backtracking. Agile is iterative: short sprints deliver working software incrementally, with continuous feedback and ability to adapt to changing requirements. Agile is better for projects with evolving or unclear requirements.',
    'What happens in Waterfall when requirements change late in the project? How does Agile handle this differently?'
  ),
(
    'Software Engineering', 'Easy', 45,
    'What is the purpose of a "code smell" in software engineering?',
    'Code that uses too many comments', 'A symptom in source code that indicates a deeper design problem or the need for refactoring',
    'Code written by inexperienced developers', 'Code that fails security audits',
    1,
    'Code smells (introduced by Kent Beck, popularized by Martin Fowler) are surface-level indicators of potential design problems: long methods, large classes, duplicate code, feature envy, data clumps, etc. They are not bugs but suggest the code may be harder to maintain and should be refactored.',
    'A smell is a warning sign, not a definite problem. What might a "long method" or "duplicate code" tell you about the design?'
  );
