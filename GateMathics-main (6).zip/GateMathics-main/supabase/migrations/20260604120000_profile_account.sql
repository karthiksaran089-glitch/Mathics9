-- ============================================================
-- GateMathics: Profile & Account Views & Functions
-- ============================================================
-- Provides dedicated views for the profile/account page,
-- combining identity details from auth.users and progression
-- stats from user_profiles.
-- ============================================================

-- 1. PROFILE DETAILS VIEW
-- Single source of truth for the profile page — combines
-- auth.users identity with user_profiles progression data.
DROP VIEW IF EXISTS public.profile_details CASCADE;
CREATE VIEW public.profile_details WITH (security_invoker = true) AS
SELECT
  up.id AS user_id,
  up.display_name,
  up.email,
  up.avatar_url,
  up.auth_method::TEXT,
  up.rank::TEXT,
  up.lp,
  -- Progression fields
  up.total_questions_answered,
  up.total_correct,
  up.total_incorrect,
  up.total_timeout,
  up.overall_accuracy,
  up.avg_answer_speed_seconds,
  up.daily_streak,
  up.longest_streak,
  up.last_active_date,
  up.total_sessions,
  up.total_ranked_sessions,
  up.total_practice_sessions,
  up.created_at AS account_created_at,
  up.updated_at,
  -- Computed Level/XP fields using gamification formula
  -- Formula: Each correct answer = 10 XP, each session completion = 5 XP
  -- Total XP = (total_correct * 10) + (total_sessions * 5)
  (COALESCE(up.total_correct, 0) * 10 + COALESCE(up.total_sessions, 0) * 5) AS total_xp,
  -- Next rank LP threshold (based on current rank tier)
  CASE
    WHEN up.rank::TEXT = 'Bronze' THEN 500
    WHEN up.rank::TEXT = 'Silver' THEN 1000
    WHEN up.rank::TEXT = 'Gold' THEN 1500
    WHEN up.rank::TEXT = 'Platinum' THEN 2000
    WHEN up.rank::TEXT = 'Diamond' THEN 2500
    WHEN up.rank::TEXT = 'Grandmaster' THEN 2500
    ELSE 1000
  END AS next_rank_lp_threshold,
  -- Next rank name
  CASE
    WHEN up.rank::TEXT = 'Bronze' THEN 'Silver'
    WHEN up.rank::TEXT = 'Silver' THEN 'Gold'
    WHEN up.rank::TEXT = 'Gold' THEN 'Platinum'
    WHEN up.rank::TEXT = 'Platinum' THEN 'Diamond'
    WHEN up.rank::TEXT = 'Diamond' THEN 'Grandmaster'
    WHEN up.rank::TEXT = 'Grandmaster' THEN 'Grandmaster'
    ELSE 'Silver'
  END AS next_rank_name,
  -- LP progress toward next rank (percentage)
  CASE
    WHEN up.rank::TEXT = 'Grandmaster' THEN 100
    WHEN up.rank::TEXT = 'Bronze' THEN ROUND((up.lp::NUMERIC / 500) * 100, 1)
    WHEN up.rank::TEXT = 'Silver' THEN ROUND((up.lp::NUMERIC / 1000) * 100, 1)
    WHEN up.rank::TEXT = 'Gold' THEN ROUND((up.lp::NUMERIC / 1500) * 100, 1)
    WHEN up.rank::TEXT = 'Platinum' THEN ROUND((up.lp::NUMERIC / 2000) * 100, 1)
    WHEN up.rank::TEXT = 'Diamond' THEN ROUND((up.lp::NUMERIC / 2500) * 100, 1)
    ELSE 100
  END AS lp_progress_percent,
  -- Account age in days
  COALESCE(
    EXTRACT(DAY FROM (CURRENT_TIMESTAMP - up.created_at))::INTEGER,
    0
  ) AS account_age_days,
  -- Is the user active today?
  (up.last_active_date = CURRENT_DATE) AS is_active_today
FROM public.user_profiles up;

-- 2. PROFILE STAT VIEW
-- Quick-access view for the stats grid on profile page
DROP VIEW IF EXISTS public.profile_stats CASCADE;
CREATE VIEW public.profile_stats WITH (security_invoker = true) AS
SELECT
  up.id AS user_id,
  up.rank::TEXT,
  up.lp,
  up.overall_accuracy,
  up.avg_answer_speed_seconds,
  up.daily_streak,
  up.longest_streak,
  up.total_sessions,
  up.total_ranked_sessions,
  up.total_practice_sessions,
  up.total_questions_answered,
  up.total_correct,
  up.total_incorrect,
  up.total_timeout,
  -- Session breakdown percentages
  CASE
    WHEN up.total_sessions > 0
    THEN ROUND((up.total_ranked_sessions::NUMERIC / up.total_sessions) * 100, 1)
    ELSE 0
  END AS ranked_session_pct,
  CASE
    WHEN up.total_sessions > 0
    THEN ROUND((up.total_practice_sessions::NUMERIC / up.total_sessions) * 100, 1)
    ELSE 0
  END AS practice_session_pct,
  -- Accuracy trend indicator
  CASE
    WHEN up.overall_accuracy >= 80 THEN 'excellent'
    WHEN up.overall_accuracy >= 60 THEN 'good'
    WHEN up.overall_accuracy >= 40 THEN 'average'
    WHEN up.overall_accuracy > 0 THEN 'needs_improvement'
    ELSE 'no_data'
  END AS accuracy_tier,
  -- Total combined engagement score
  (COALESCE(up.total_sessions, 0) * 3 + COALESCE(up.total_questions_answered, 0) * 1 + COALESCE(up.total_correct, 0) * 2) AS engagement_score
FROM public.user_profiles up;

-- 3. FUNCTION: Update display name
-- Securely updates the display_name field on user_profiles
DROP FUNCTION IF EXISTS public.update_profile_display_name;
CREATE FUNCTION public.update_profile_display_name(
  p_user_id UUID,
  p_display_name TEXT
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_result JSONB;
BEGIN
  -- Validate display name
  IF p_display_name IS NULL OR LENGTH(TRIM(p_display_name)) < 2 THEN
    RETURN jsonb_build_object('success', false, 'error', 'Display name must be at least 2 characters.');
  END IF;
  IF LENGTH(p_display_name) > 32 THEN
    RETURN jsonb_build_object('success', false, 'error', 'Display name must be 32 characters or less.');
  END IF;

  UPDATE public.user_profiles
  SET display_name = TRIM(p_display_name)
  WHERE id = p_user_id;

  IF NOT FOUND THEN
    RETURN jsonb_build_object('success', false, 'error', 'User profile not found.');
  END IF;

  RETURN jsonb_build_object('success', true, 'display_name', TRIM(p_display_name));
END;
$$;

-- 4. FUNCTION: Get account summary (for account details modal)
DROP FUNCTION IF EXISTS public.get_account_summary;
CREATE FUNCTION public.get_account_summary(p_user_id UUID)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_result JSONB;
BEGIN
  SELECT jsonb_build_object(
    'email', COALESCE(up.email, ''),
    'auth_method', up.auth_method::TEXT,
    'account_type', CASE WHEN up.auth_method = 'guest' THEN 'Guest' ELSE 'Authenticated User' END,
    'member_since', up.created_at,
    'account_age_days', COALESCE(EXTRACT(DAY FROM (CURRENT_TIMESTAMP - up.created_at))::INTEGER, 0),
    'current_rank', up.rank::TEXT,
    'total_lp', up.lp,
    'total_sessions', up.total_sessions,
    'total_questions_answered', up.total_questions_answered,
    'is_active_today', (up.last_active_date = CURRENT_DATE)
  ) INTO v_result
  FROM public.user_profiles up
  WHERE up.id = p_user_id;

  IF v_result IS NULL THEN
    RETURN jsonb_build_object('error', 'User profile not found');
  END IF;

  RETURN v_result;
END;
$$;

-- 5. FUNCTION: Get achievement badges for user
DROP FUNCTION IF EXISTS public.get_user_achievements;
CREATE FUNCTION public.get_user_achievements(p_user_id UUID)
RETURNS TABLE(
  badge_id TEXT,
  badge_name TEXT,
  badge_description TEXT,
  badge_icon TEXT,
  unlocked BOOLEAN,
  unlocked_at TIMESTAMPTZ
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_stats RECORD;
BEGIN
  SELECT * INTO v_stats FROM public.profile_stats WHERE user_id = p_user_id;

  RETURN QUERY
  SELECT * FROM (
    SELECT
      'first_session' AS badge_id,
      'First Steps' AS badge_name,
      'Complete your first session' AS badge_description,
      '🎯' AS badge_icon,
      (COALESCE(v_stats.total_sessions, 0) >= 1) AS unlocked,
      NULL::TIMESTAMPTZ AS unlocked_at
    UNION ALL
    SELECT 'ten_sessions', 'Dedicated Learner', 'Complete 10 sessions', '📚',
      (COALESCE(v_stats.total_sessions, 0) >= 10), NULL
    UNION ALL
    SELECT 'fifty_sessions', 'GATE Warrior', 'Complete 50 sessions', '⚔️',
      (COALESCE(v_stats.total_sessions, 0) >= 50), NULL
    UNION ALL
    SELECT 'hundred_sessions', 'GATE Master', 'Complete 100 sessions', '🏆',
      (COALESCE(v_stats.total_sessions, 0) >= 100), NULL
    UNION ALL
    SELECT 'streak_3', 'On Fire', '3-day streak', '🔥',
      (COALESCE(v_stats.daily_streak, 0) >= 3), NULL
    UNION ALL
    SELECT 'streak_7', 'Unstoppable', '7-day streak', '💪',
      (COALESCE(v_stats.daily_streak, 0) >= 7), NULL
    UNION ALL
    SELECT 'streak_30', 'GATE Dedication', '30-day streak', '🌟',
      (COALESCE(v_stats.daily_streak, 0) >= 30), NULL
    UNION ALL
    SELECT 'accuracy_80', 'Sharp Shooter', '80%+ overall accuracy', '🎯',
      (COALESCE(v_stats.overall_accuracy, 0) >= 80), NULL
    UNION ALL
    SELECT 'accuracy_90', 'Precision Master', '90%+ overall accuracy', '💎',
      (COALESCE(v_stats.overall_accuracy, 0) >= 90), NULL
    UNION ALL
    SELECT 'rank_gold', 'Gold Achiever', 'Reach Gold rank', '🥇',
      (v_stats.rank IN ('Gold', 'Platinum', 'Diamond', 'Grandmaster')), NULL
    UNION ALL
    SELECT 'rank_platinum', 'Elite Player', 'Reach Platinum rank', '💠',
      (v_stats.rank IN ('Platinum', 'Diamond', 'Grandmaster')), NULL
    UNION ALL
    SELECT 'rank_diamond', 'Diamond Elite', 'Reach Diamond rank', '💎',
      (v_stats.rank IN ('Diamond', 'Grandmaster')), NULL
    UNION ALL
    SELECT 'questions_100', 'Century', 'Answer 100 questions', '💯',
      (COALESCE(v_stats.total_questions_answered, 0) >= 100), NULL
    UNION ALL
    SELECT 'questions_500', 'GATE Scholar', 'Answer 500 questions', '🎓',
      (COALESCE(v_stats.total_questions_answered, 0) >= 500), NULL
    UNION ALL
    SELECT 'practice_session', 'Practice Makes Perfect', 'Complete a practice session', '✏️',
      (COALESCE(v_stats.total_practice_sessions, 0) >= 1), NULL
    UNION ALL
    SELECT 'ranked_session', 'Competitive Spirit', 'Complete a ranked session', '⚡',
      (COALESCE(v_stats.total_ranked_sessions, 0) >= 1), NULL
  ) badges
  ORDER BY badges.unlocked DESC, badges.badge_id ASC;
END;
$$;

-- 6. PROFILE ACTIVITY SUMMARY VIEW
-- Last 7 days of activity for the profile dashboard
DROP VIEW IF EXISTS public.profile_activity CASCADE;
CREATE VIEW public.profile_activity WITH (security_invoker = true) AS
WITH daily AS (
  SELECT
    user_id,
    session_date::DATE AS activity_date,
    COUNT(*) AS session_count,
    SUM(questions_total) AS total_questions,
    ROUND(AVG(accuracy), 1) AS avg_accuracy
  FROM (
    SELECT user_id, session_date, questions_total, accuracy
    FROM public.ranked_sessions
    WHERE session_date >= CURRENT_DATE - INTERVAL '6 days'
    UNION ALL
    SELECT user_id, session_date, questions_total, accuracy
    FROM public.practice_sessions
    WHERE session_date >= CURRENT_DATE - INTERVAL '6 days'
  ) combined
  GROUP BY user_id, session_date::DATE
)
SELECT
  user_id,
  activity_date,
  COALESCE(session_count, 0) AS session_count,
  COALESCE(total_questions, 0) AS total_questions,
  avg_accuracy,
  EXTRACT(DOW FROM activity_date)::INTEGER AS day_of_week
FROM daily
ORDER BY user_id, activity_date ASC;