-- ==========================================
-- Ranked Questions: Compiler Design
-- ==========================================

INSERT INTO public.ranked_questions
  (topic, difficulty, time_limit, question, option_a, option_b, option_c, option_d, correct_index, explanation)
VALUES
(
    'Compiler Design', 'Hard', 75,
    'Which parsing technique is used by most modern compilers for its efficiency and ability to handle most programming language grammars?',
    'LL(1) top-down parsing', 'Recursive descent with backtracking', 'LALR(1) bottom-up parsing', 'Earley parsing',
    2,
    'LALR(1) (Look-Ahead LR with 1 token of lookahead) is the parsing technique used by most compiler generators like yacc/bison. It handles a large class of grammars efficiently in O(n) time.'
  ),
(
    'Compiler Design', 'Easy', 45,
    'What is the purpose of lexical analysis in a compiler?',
    'Checking the semantic correctness of code', 'Converting source code characters into a stream of tokens', 'Generating machine code from intermediate representation', 'Building the symbol table',
    1,
    'Lexical analysis (scanning) reads the source code character stream and groups characters into meaningful lexical units called tokens (keywords, identifiers, operators, literals). It removes whitespace and comments, feeding tokens to the parser.'
  ),
(
    'Compiler Design', 'Medium', 60,
    'What is a "grammar conflict" in LALR(1) parsing, specifically a reduce-reduce conflict?',
    'When the parser cannot shift or reduce', 'When two different productions can be reduced for the same lookahead token in the same state',
    'When a shift and reduce action both exist for the same lookahead', 'When the grammar has left recursion',
    1,
    'A reduce-reduce conflict occurs in an LR parsing table when a state has two or more different reduce actions for the same lookahead token — the parser cannot determine which production to reduce. This usually indicates an ambiguous grammar or insufficient lookahead.'
  ),
(
    'Compiler Design', 'Hard', 90,
    'In a syntax-directed translation scheme, an "L-attributed" definition is one where:',
    'All attributes are synthesized', 'Each inherited attribute of a symbol depends only on attributes of symbols to its left in the production and the parent''s inherited attributes',
    'All attributes flow from right to left', 'Attributes can depend on any other attribute in the parse tree',
    1,
    'An L-attributed SDD allows attributes to be evaluated in a single left-to-right pass. Each inherited attribute of Xi in A→X1X2...Xn depends only on inherited attributes of A and attributes (synthesized or inherited) of X1,...,Xi-1 (symbols to the left).'
  ),
(
    'Compiler Design', 'Medium', 75,
    'Three-address code (TAC) is an intermediate representation where each instruction has at most:',
    'One operand and one result', 'Two operands and one result', 'Three operands and one result', 'Any number of operands',
    1,
    'Three-address code instructions have the form: result = operand1 op operand2 (two source operands + one destination = three addresses). Examples: t1 = a + b, t2 = t1 * c. TAC is easy to generate and optimize.'
  ),
(
    'Compiler Design', 'Easy', 45,
    'Which phase of compilation detects errors like using an undeclared variable or type mismatch?',
    'Lexical Analysis', 'Syntax Analysis', 'Semantic Analysis', 'Code Generation',
    2,
    'Semantic analysis detects context-sensitive errors that are syntactically valid but semantically incorrect: undeclared variables, type mismatches, wrong number of arguments, scope violations, etc. It uses the symbol table built during earlier phases.'
  ),
(
    'Compiler Design', 'Hard', 90,
    'Loop-invariant code motion is an optimization that:',
    'Eliminates loops that never execute', 'Moves computations whose results do not change across loop iterations to before the loop',
    'Unrolls loops to reduce branch overhead', 'Converts loops into recursive function calls',
    1,
    'Loop-invariant code motion (LICM) identifies computations inside a loop whose operands do not change during loop execution (loop-invariant expressions) and moves them outside the loop (into the preheader), reducing redundant computation.'
  ),
(
    'Compiler Design', 'Medium', 60,
    'What is the FIRST set of a non-terminal A in a grammar?',
    'The set of all non-terminals that A can derive', 'The set of terminals that can appear as the first symbol in strings derived from A',
    'The set of terminals that can follow A in any sentential form', 'The set of productions where A appears on the left side',
    1,
    'FIRST(A) is the set of terminal symbols that can begin any string derived from A. If A can derive ε (empty string), then ε is also in FIRST(A). FIRST sets are used to construct LL(1) and LR parsing tables.'
  ),
(
    'Compiler Design', 'Hard', 90,
    'In copy propagation optimization, the statement "x = y" allows subsequent uses of x to be replaced by y. This is valid as long as:',
    'x and y are both integers', 'Neither x nor y is redefined between the copy statement and the use of x',
    'x and y are in the same basic block', 'The statement appears in a loop',
    1,
    'Copy propagation replaces uses of x with y after "x = y", eliminating the copy and enabling further optimizations (like dead code elimination of "x = y"). Validity requires that neither x nor y is redefined (assigned a new value) between the copy statement and the use point.'
  ),
(
    'Compiler Design', 'Medium', 75,
    'In the context of compiler optimizations, "strength reduction" refers to:',
    'Reducing the number of functions in a program', 'Replacing expensive operations with equivalent cheaper ones (e.g., multiplication with addition in loops)',
    'Reducing the memory footprint of compiled programs', 'Minimizing the number of variables in a function',
    1,
    'Strength reduction replaces expensive operations with cheaper equivalents: replacing multiplication by a constant with additions (x*4 → x<<2), replacing exponentiation with multiplications in loops (x^2 → x*x), or replacing loop-induction multiplications with additions. Classic compiler optimization.'
  ),
(
    'Compiler Design', 'Hard', 90,
    'In SSA (Static Single Assignment) form, each variable is defined exactly once. The φ (phi) function is needed to:',
    'Handle function calls in the intermediate representation', 'Merge different definitions of a variable from different control flow paths at join points',
    'Optimize loop variables', 'Rename all variables to unique identifiers',
    1,
    'In SSA form, when control flow paths merge (at join points), a φ (phi) function selects the correct variable version based on which path was taken. For example, if x1 comes from then-branch and x2 from else-branch, a φ(x1, x2) at the merge point yields the correct value.'
  ),
(
    'Compiler Design', 'Medium', 75,
    'In the context of runtime memory management, the "activation record" is pushed onto the stack when:',
    'The program starts execution', 'A function/procedure is called, and popped when it returns',
    'A variable is declared globally', 'A heap allocation is made',
    1,
    'An activation record (stack frame) is created and pushed on the call stack each time a function is called. It contains: local variables, parameters, return address, saved registers, and dynamic link (pointer to caller''s frame). It is popped when the function returns, restoring the caller''s context.'
  ),
(
    'Compiler Design', 'Easy', 45,
    'The role of a "linker" in program compilation is to:',
    'Convert assembly language to machine code', 'Check the program for syntax errors', 'Combine multiple object files and resolve external symbol references to produce an executable',
    'Optimize the generated machine code',
    2,
    'The linker takes multiple object files (.o files) produced by the compiler/assembler and combines them into a single executable. It resolves external symbol references (functions/variables defined in other files or libraries), performs relocation, and produces the final executable file.'
  ),
(
    'Compiler Design', 'Medium', 60,
    'What is "dead code elimination" in compiler optimization?',
    'Removing code that handles exceptions', 'Removing code whose results are never used or code that can never be reached',
    'Eliminating function calls to improve performance', 'Removing redundant variable declarations',
    1,
    'Dead code elimination removes: (1) unreachable code (code after return statements, branches that are never taken), and (2) code whose computed values are never used (dead assignments). This reduces code size and improves execution speed without changing program semantics.'
  ),
(
    'Compiler Design', 'Hard', 90,
    'In a type system, "type inference" refers to:',
    'The process of explicitly declaring variable types in source code', 'The automatic deduction of the types of expressions by the compiler without explicit type annotations',
    'Converting one type to another at runtime', 'Checking that all types in a program are compatible',
    1,
    'Type inference (e.g., in Hindley-Milner type system used in ML/Haskell) allows the compiler to automatically deduce the types of variables and expressions from context, without requiring explicit type annotations. This enables concise code while maintaining static type safety.'
  );
