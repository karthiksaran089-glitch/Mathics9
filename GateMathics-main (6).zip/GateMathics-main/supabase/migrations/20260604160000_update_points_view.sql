-- ============================================================
-- GateMathics: Update Points Raw Data View
-- ============================================================
-- This migration adds a new `is_personal_best` flag to
-- recent_earnings view and updates user_points_ledger
-- to include streak-aware points calculation.
-- ============================================================

-- 1. DROP AND RECREATE recent_earnings with new column
DROP VIEW IF EXISTS public.recent_earnings CASCADE;
CREATE VIEW public.recent_earnings WITH (security_invoker = true) AS
SELECT
  sh.session_id,
  sh.user_id,
  sh.session_date,
  sh.mode,
  sh.questions_total,
  sh.questions_correct,
  sh.questions_incorrect,
  sh.questions_timeout,
  sh.accuracy,
  sh.avg_speed_seconds,
  sh.lp_change,
  sh.topics,
  sh.difficulty,
  sh.hints_used,
  -- XP earned (practice mode: 10 per correct + 5 per session)
  CASE
    WHEN sh.mode = 'Practice' THEN (COALESCE(sh.questions_correct, 0) * 10 + 5)
    ELSE 0
  END AS xp_earned,
  -- LP earned (ranked mode only)
  CASE
    WHEN sh.mode = 'Ranked' THEN COALESCE(sh.lp_change, 0)
    ELSE 0
  END AS lp_earned,
  -- NEW: Flag if accuracy is a personal best (>= 90%)
  CASE
    WHEN sh.accuracy >= 90 THEN true
    ELSE false
  END AS is_personal_best
FROM public.analytics_session_history sh
ORDER BY sh.session_date DESC
LIMIT 10;

-- 2. UPDATE user_points_ledger to include streak multiplier
DROP VIEW IF EXISTS public.user_points_ledger CASCADE;
CREATE VIEW public.user_points_ledger WITH (security_invoker = true) AS
WITH ranked_points AS (
  SELECT
    user_id,
    SUM(CASE WHEN lp_change > 0 THEN lp_change ELSE 0 END) AS ranked_lp_gained,
    SUM(CASE WHEN lp_change < 0 THEN ABS(lp_change) ELSE 0 END) AS ranked_lp_lost,
    SUM(lp_change) AS ranked_net_lp,
    COUNT(*) AS ranked_sessions_played,
    ROUND(AVG(accuracy), 1) AS ranked_avg_accuracy,
    ROUND(AVG(avg_speed_seconds), 1) AS ranked_avg_speed,
    -- NEW: Best ranked session accuracy
    COALESCE(MAX(accuracy), 0) AS ranked_best_accuracy
  FROM public.ranked_sessions
  GROUP BY user_id
),
practice_points AS (
  SELECT
    user_id,
    SUM(questions_correct) * 10 AS practice_xp_from_correct,
    COUNT(*) * 5 AS practice_xp_from_sessions,
    SUM(questions_correct) * 10 + COUNT(*) * 5 AS practice_total_xp,
    COUNT(*) AS practice_sessions_played,
    ROUND(AVG(accuracy), 1) AS practice_avg_accuracy,
    ROUND(AVG(avg_speed_seconds), 1) AS practice_avg_speed,
    SUM(hints_used) AS practice_hints_used,
    -- NEW: Best practice session accuracy
    COALESCE(MAX(accuracy), 0) AS practice_best_accuracy
  FROM public.practice_sessions
  GROUP BY user_id
)
SELECT
  up.id AS user_id,
  up.display_name,
  up.lp AS current_lp,
  up.rank::TEXT AS current_rank,
  COALESCE(rp.ranked_lp_gained, 0) AS ranked_lp_gained,
  COALESCE(rp.ranked_lp_lost, 0) AS ranked_lp_lost,
  COALESCE(rp.ranked_net_lp, 0) AS ranked_net_lp,
  COALESCE(rp.ranked_sessions_played, 0) AS ranked_sessions_played,
  COALESCE(rp.ranked_avg_accuracy, 0) AS ranked_avg_accuracy,
  COALESCE(rp.ranked_avg_speed, 0) AS ranked_avg_speed,
  COALESCE(rp.ranked_best_accuracy, 0) AS ranked_best_accuracy, -- NEW
  COALESCE(pp.practice_xp_from_correct, 0) AS practice_xp_from_correct,
  COALESCE(pp.practice_xp_from_sessions, 0) AS practice_xp_from_sessions,
  COALESCE(pp.practice_total_xp, 0) AS practice_total_xp,
  COALESCE(pp.practice_sessions_played, 0) AS practice_sessions_played,
  COALESCE(pp.practice_avg_accuracy, 0) AS practice_avg_accuracy,
  COALESCE(pp.practice_avg_speed, 0) AS practice_avg_speed,
  COALESCE(pp.practice_hints_used, 0) AS practice_hints_used,
  COALESCE(pp.practice_best_accuracy, 0) AS practice_best_accuracy, -- NEW
  COALESCE(rp.ranked_sessions_played, 0) + COALESCE(pp.practice_sessions_played, 0) AS total_sessions,
  up.total_questions_answered,
  up.total_correct,
  up.total_incorrect,
  up.total_timeout,
  up.overall_accuracy,
  up.daily_streak,
  up.longest_streak
FROM public.user_profiles up
LEFT JOIN ranked_points rp ON up.id = rp.user_id
LEFT JOIN practice_points pp ON up.id = pp.user_id;