-- ==========================================
-- Practice Questions: Programming Languages
-- ==========================================

INSERT INTO public.practice_questions
  (topic, difficulty, time_limit, question, option_a, option_b, option_c, option_d, correct_index, explanation, hint)
VALUES
(
    'Programming Languages', 'Medium', 60,
    'Which of the following is a characteristic of a purely functional programming language?',
    'Mutable state is allowed', 'Functions have side effects', 'Referential transparency is guaranteed', 'Loops are the primary control structure',
    2,
    'Referential transparency means that a function call can be replaced by its return value without changing program behavior. This is a core property of purely functional languages like Haskell.',
    'In a purely functional language, the same input always produces the same output with no observable side effects.'
  ),
(
    'Programming Languages', 'Easy', 45,
    'What is the difference between "pass by value" and "pass by reference" in programming languages?',
    'They are identical in effect', 'Pass by value copies the argument; pass by reference passes the memory address, allowing the function to modify the original variable',
    'Pass by reference is faster in all cases', 'Pass by value is only used in functional languages',
    1,
    'Pass by value: a copy of the argument is passed to the function. Changes inside the function do not affect the original. Pass by reference: the address (reference) of the variable is passed. The function can modify the original variable. C uses pass by value; C++ supports both. Java passes object references by value.',
    'If you pass an integer to a function and the function increments it, does the original variable change? It depends on the calling convention.'
  ),
(
    'Programming Languages', 'Medium', 75,
    'What is "dynamic dispatch" in object-oriented programming?',
    'Creating objects dynamically at runtime', 'Selecting which method implementation to call at runtime based on the actual type of the object, rather than the declared type',
    'Dispatching threads to different CPU cores', 'Automatically generating getter/setter methods',
    1,
    'Dynamic dispatch (runtime polymorphism) enables a method call through a base class reference to invoke the correct overridden method of the actual subclass at runtime. Implemented via virtual function tables (vtable) in C++, method tables in Java. Enables the Open-Closed Principle and polymorphism.',
    'If a base class has a method and a derived class overrides it, which version is called when you use a base class pointer? It depends on the actual object type at runtime.'
  ),
(
    'Programming Languages', 'Hard', 90,
    'What is "tail call optimization" (TCO) in programming language implementations?',
    'Optimizing the last statement of a function for speed', 'Reusing the current function''s stack frame for a tail-recursive call instead of creating a new frame, converting recursion to iteration',
    'Inlining the last function call to avoid overhead', 'Caching the return values of recursive functions',
    1,
    'A tail call is a function call that is the very last operation (the result is immediately returned). TCO replaces the current activation record with the new call''s frame, avoiding stack growth. This transforms tail-recursive functions into efficient loops. Haskell and Scheme require TCO; Python does not implement it.',
    'In a tail recursive function, do you need the caller''s stack frame after the recursive call returns? If not, can you reuse it?'
  ),
(
    'Programming Languages', 'Medium', 60,
    'What is a "closure" in programming languages?',
    'A way to close/end a program', 'A function that captures variables from its enclosing lexical scope, allowing those variables to persist beyond their defining scope''s lifetime',
    'A method for closing database connections', 'A compile-time constant expression',
    1,
    'A closure is a function bundled with its lexical environment — the variables from the surrounding scope that the function "closes over." Even after the outer function returns, the closure retains access to those captured variables. Used extensively in JavaScript, Python, Haskell, Lisp.',
    'What happens to a local variable when the function that defined it returns? What if a nested function still references it?'
  ),
(
    'Programming Languages', 'Easy', 45,
    'What is the difference between a compiled language and an interpreted language?',
    'Compiled languages are always faster than interpreted', 'Compiled languages translate the entire source to machine code before execution; interpreted languages execute source code line by line via an interpreter',
    'Interpreted languages cannot be debugged', 'Compiled languages run on any platform without modification',
    1,
    'Compiled languages (C, C++, Rust) translate entire source code to native machine code before execution, producing a standalone executable. Interpreted languages (Python, Ruby) are executed line by line at runtime by an interpreter. Many modern languages use intermediate approaches (Java: bytecode + JIT, Python: bytecode + interpreter).',
    'When does the translation from source code to machine instructions happen — before or during execution?'
  ),
(
    'Programming Languages', 'Hard', 90,
    'What is "type erasure" in generic programming (e.g., Java generics)?',
    'Removing type information from the source code', 'Removing generic type parameters at compile time, replacing them with their bounds or Object, so no type information exists at runtime',
    'Converting between different numeric types automatically', 'Erasing all static type checks',
    1,
    'Java generics use type erasure: List<Integer> and List<String> both become List (of Object) at bytecode level. Type parameters are checked only at compile time; at runtime, all generics are erased. This enables backward compatibility with pre-generics Java but means you cannot do "instanceof List<Integer>" or create generic arrays.',
    'Java generics are a compile-time feature. What happens to the type parameter information when the bytecode is generated?'
  ),
(
    'Programming Languages', 'Medium', 60,
    'What is "garbage collection" in programming languages?',
    'Removing unused code from the compiled binary', 'Automatic reclamation of memory that is no longer reachable/referenced by the program',
    'Deleting temporary files created during compilation', 'Optimizing memory layout for cache efficiency',
    1,
    'Garbage collection (GC) automatically reclaims heap memory that is no longer referenced by the program, preventing memory leaks without requiring manual free/delete. Common algorithms: Reference Counting (Python, Swift), Mark-and-Sweep (Java), Copying (generational GC). Trade-offs: convenience vs. control, potential GC pauses.',
    'If no variable in your program references a heap object anymore, can that memory ever be used again? Who should free it?'
  );
