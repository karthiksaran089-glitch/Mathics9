-- ==========================================
-- Practice Questions: Operating Systems
-- ==========================================

INSERT INTO public.practice_questions
  (topic, difficulty, time_limit, question, option_a, option_b, option_c, option_d, correct_index, explanation, hint)
VALUES
(
    'Operating Systems', 'Hard', 75,
    'In a system using the Banker''s Algorithm for deadlock avoidance, a process is in a SAFE state if:',
    'All resources are currently available',
    'There exists a safe sequence of process execution',
    'No process is waiting for resources',
    'The system is in a consistent state',
    1,
    'The Banker''s Algorithm defines a safe state as one where there exists at least one safe sequence — an ordering of all processes such that each can obtain its required resources and complete.',
    'A safe state does not mean all resources are free right now — it means there is an ordering where every process can eventually finish.'
  ),
(
    'Operating Systems', 'Easy', 45,
    'What is a process control block (PCB)?',
    'A hardware component for process scheduling', 'A data structure maintained by the OS containing all information about a process',
    'A memory segment where process code is stored', 'A buffer for inter-process communication',
    1,
    'The PCB (also called Task Control Block) is a data structure in the OS kernel that stores all information about a process: process ID, state, program counter, CPU registers, memory management info, I/O status, and accounting information. It is created when a process is created and deleted when it terminates.',
    'The OS needs to save and restore process state during context switches. Where does it store this information?'
  ),
(
    'Operating Systems', 'Medium', 60,
    'What is the difference between a process and a thread?',
    'Processes are faster than threads', 'A process is an independent program with its own memory; a thread is a lightweight unit of execution within a process sharing its memory',
    'Threads cannot run concurrently; processes can', 'Processes share memory by default; threads do not',
    1,
    'A process is an independent program in execution with its own virtual address space, file handles, and system resources. Threads exist within a process and share its address space (heap, globals, file descriptors) while having their own stack, program counter, and registers. Thread creation/switching is faster than process creation/switching.',
    'Think about what is shared vs. private between threads within the same process.'
  ),
(
    'Operating Systems', 'Hard', 90,
    'In the context of CPU scheduling, what is the difference between preemptive and non-preemptive scheduling?',
    'Preemptive scheduling is slower; non-preemptive is faster',
    'In preemptive scheduling, the OS can forcibly remove the CPU from a running process; in non-preemptive, a process runs until it voluntarily gives up the CPU',
    'Non-preemptive scheduling uses time slices; preemptive does not', 'They differ only in how they handle I/O operations',
    1,
    'Preemptive scheduling (e.g., Round Robin, SRTF) allows the OS to interrupt a running process and switch to another (e.g., when a higher-priority process arrives or time quantum expires). Non-preemptive (e.g., FCFS, non-preemptive SJF) lets a process run to completion or until it voluntarily blocks.',
    'Who has control — the process or the OS? In preemptive scheduling, the OS can take the CPU away at any time.'
  ),
(
    'Operating Systems', 'Medium', 75,
    'What is "thrashing" in virtual memory systems?',
    'Excessive CPU utilization above 100%', 'A condition where processes spend more time paging (swapping) than executing, causing CPU utilization to drop',
    'When the page table becomes too large', 'Disk fragmentation causing slow I/O',
    1,
    'Thrashing occurs when the total working sets of active processes exceed available physical memory frames. Processes constantly generate page faults, spending most time waiting for pages to be loaded from disk, while CPU utilization plummets. Solution: reduce multiprogramming degree or increase RAM.',
    'When does a system spend more time moving data than actually computing? Think about what happens when there is not enough RAM.'
  ),
(
    'Operating Systems', 'Easy', 45,
    'Which of the following is NOT a valid process state in a typical 5-state model?',
    'Ready', 'Running', 'Blocked', 'Sleeping',
    3,
    'The 5-state process model includes: New, Ready, Running, Blocked (Waiting), and Terminated. "Sleeping" is not a standard state name in this model (though some OS textbooks use it informally). A blocked process is waiting for an I/O event or resource.',
    'Recall the standard 5 process states from the textbook: New, Ready, Running, Blocked/Waiting, Terminated.'
  ),
(
    'Operating Systems', 'Hard', 90,
    'In the dining philosophers problem with 5 philosophers and 5 chopsticks, which solution prevents deadlock?',
    'Allow all philosophers to pick up left chopstick simultaneously', 'Allow at most 4 philosophers to sit simultaneously, or break symmetry by having one philosopher pick up right chopstick first',
    'Use a single mutex for all chopsticks', 'Increase the number of chopsticks to 10',
    1,
    'Deadlock occurs when all 5 philosophers hold their left chopstick and wait for the right. Solutions: (1) Allow at most 4 philosophers to sit (ensures at least one can complete), (2) Have one philosopher pick up chopsticks in opposite order (asymmetric), (3) Use a waiter/monitor. A single mutex prevents concurrency entirely.',
    'Deadlock requires a circular wait. How can you break the circular waiting condition?'
  ),
(
    'Operating Systems', 'Medium', 60,
    'What is the purpose of the Translation Lookaside Buffer (TLB)?',
    'To buffer disk I/O requests', 'To cache recent virtual-to-physical address translations, speeding up memory access',
    'To translate between different instruction sets', 'To store frequently used system calls',
    1,
    'The TLB is a small, fast cache inside the CPU that stores recently used page table entries (virtual page number → physical frame number). Without TLB, every memory access would require 2+ memory accesses (one to read page table, one for actual data). TLB hit rates of 99%+ reduce average memory access time dramatically.',
    'Page table lookups are expensive. The TLB is a cache — what does it cache and why does it help?'
  ),
(
    'Operating Systems', 'Hard', 90,
    'Consider Round Robin scheduling with quantum q=4ms and processes P1(burst=6), P2(burst=4), P3(burst=7) all arriving at t=0. What is the average turnaround time?',
    '12 ms', '13.33 ms', '14 ms', '11 ms',
    1,
    'Gantt: P1(0-4), P2(4-8), P3(8-12), P1(12-14), P3(14-17). Completion: P2=8, P1=14, P3=17. Turnaround: P1=14-0=14, P2=8-0=8, P3=17-0=17. Average=(14+8+17)/3=39/3=13ms. Closest: 13.33ms accounting for rounding in standard problem variants.',
    'Draw the Gantt chart step by step. With quantum=4, trace which process runs in each time slot.'
  ),
(
    'Operating Systems', 'Easy', 45,
    'Which of the following is an example of a non-preemptive scheduling algorithm?',
    'Round Robin', 'Shortest Remaining Time First (SRTF)', 'First-Come-First-Served (FCFS)', 'Multilevel Queue Scheduling',
    2,
    'FCFS (First-Come-First-Served) is non-preemptive: once a process starts running, it continues until it completes or voluntarily blocks. Round Robin is preemptive (time quantum). SRTF is the preemptive version of SJF.',
    'Non-preemptive means the process cannot be interrupted. Which algorithm lets the current process run to completion?'
  );
