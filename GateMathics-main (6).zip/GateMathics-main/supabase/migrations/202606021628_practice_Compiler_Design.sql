-- ==========================================
-- Practice Questions: Compiler Design
-- ==========================================

INSERT INTO public.practice_questions
  (topic, difficulty, time_limit, question, option_a, option_b, option_c, option_d, correct_index, explanation, hint)
VALUES
(
    'Compiler Design', 'Hard', 75,
    'Which parsing technique is used by most modern compilers for its efficiency and ability to handle most programming language grammars?',
    'LL(1) top-down parsing', 'Recursive descent with backtracking', 'LALR(1) bottom-up parsing', 'Earley parsing',
    2,
    'LALR(1) (Look-Ahead LR with 1 token of lookahead) is the parsing technique used by most compiler generators like yacc/bison. It handles a large class of grammars efficiently in O(n) time.',
    'Think about which parser generator tools (yacc, bison) are most commonly used in practice and what algorithm they implement.'
  ),
(
    'Compiler Design', 'Easy', 45,
    'What is a "token" in the context of lexical analysis?',
    'A piece of memory allocated for a variable', 'A meaningful sequence of characters classified into a category (keyword, identifier, operator, etc.)',
    'A node in the abstract syntax tree', 'A production rule in the grammar',
    1,
    'A token is the basic lexical unit produced by the scanner. It consists of a token type (category) and optional attribute value. Examples: (KEYWORD, "if"), (IDENTIFIER, "count"), (INTEGER_LITERAL, 42), (OPERATOR, "+"). Tokens are the input to the parser.',
    'Lexical analysis breaks source code into "words." What do we call these classified words?'
  ),
(
    'Compiler Design', 'Medium', 60,
    'What is the FOLLOW set used for in parser construction?',
    'To determine which symbols can appear after deriving from a non-terminal', 'To compute the FIRST set of terminals',
    'To detect ambiguous grammars', 'To eliminate left recursion',
    0,
    'FOLLOW(A) is the set of terminals that can appear immediately after non-terminal A in any sentential form derived from the start symbol. FOLLOW sets are used to build SLR(1) parsing tables: reduce by A → α when the current input is in FOLLOW(A).',
    'FIRST tells you what can START a derivation. What tells you what can come AFTER a non-terminal?'
  ),
(
    'Compiler Design', 'Hard', 90,
    'In the context of runtime storage, what is the difference between stack allocation and heap allocation?',
    'Stack is for global variables; heap is for local variables', 'Stack allocation is automatic (LIFO, managed by compiler for local variables and frames); heap allocation is dynamic (explicit/GC-managed for objects with runtime-determined lifetime)',
    'Stack is always larger than heap', 'Heap allocation is faster than stack allocation',
    1,
    'Stack: automatically managed (push on function call, pop on return), LIFO, stores activation records (local variables, return addresses, parameters), fast allocation (just move stack pointer). Heap: manually managed (malloc/free) or garbage-collected, stores objects with dynamic lifetime, slower allocation (must find free block), can fragment.',
    'Which memory is managed automatically by function calls and returns? Which requires explicit allocation and deallocation?'
  ),
(
    'Compiler Design', 'Medium', 75,
    'What is "constant folding" in compiler optimization?',
    'Removing constant variables from the program', 'Evaluating constant expressions at compile time rather than runtime',
    'Moving constants out of loops', 'Replacing function calls with constant return values',
    1,
    'Constant folding evaluates expressions with all constant operands at compile time. For example, "x = 3 * 4 + 2" is replaced with "x = 14". This reduces runtime computation. It is often combined with constant propagation (replacing variables with their constant values to enable further folding).',
    'If you can compute a mathematical expression during compilation, why compute it again at runtime?'
  ),
(
    'Compiler Design', 'Easy', 45,
    'What is an "abstract syntax tree" (AST)?',
    'The concrete parse tree with all grammar symbols', 'A tree representation of the hierarchical syntactic structure of source code, omitting redundant grammar details',
    'A tree of all possible parse paths', 'The symbol table organized as a tree',
    1,
    'An AST is a simplified tree representation of source code structure. Unlike a parse tree (concrete syntax tree), an AST omits redundant grammar symbols (parentheses, semicolons, epsilon productions) while preserving the logical structure. Each internal node represents an operation; leaves represent operands.',
    'An AST is "abstract" because it strips away concrete syntax details. What does it preserve from the parse tree?'
  ),
(
    'Compiler Design', 'Hard', 90,
    'In global data flow analysis, "live variable analysis" computes for each program point:',
    'Variables that will be defined before next use', 'Variables whose current values may be used before being redefined on some path from the current point',
    'Variables that have been assigned in the current basic block', 'Variables that are used in every execution path',
    1,
    'A variable v is live at point p if there exists a path from p to a use of v that does not pass through a definition of v. Live variable analysis is a backward dataflow analysis used for dead code elimination and register allocation. LIVEOUT(B) = ∪(LIVEIN(S)) for all successors S of B.',
    'A variable is "live" if its current value will be needed later. Think about it from the perspective of the future path of execution.'
  ),
(
    'Compiler Design', 'Medium', 60,
    'What is the purpose of "name mangling" in C++ compilation?',
    'Obfuscating variable names for security', 'Encoding type information into function names to support function overloading and distinguish between same-named functions with different signatures',
    'Converting variable names to memory addresses', 'Compressing symbol names to reduce binary size',
    1,
    'C++ supports function overloading (multiple functions with same name, different parameters). Since linkers work with unique symbol names, the compiler encodes the function''s parameter types into its symbol name — "name mangling." For example, void f(int) becomes _Z1fi and void f(double) becomes _Z1fd.',
    'C++ allows functions with the same name but different types. How does the linker tell them apart?'
  );
