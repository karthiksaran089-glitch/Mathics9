-- ============================================================
-- GateMathics: Practice Mode Question Bank
-- Fallback question table for Practice Mode.
-- Used when the AI question generation engine fails, times out,
-- or is unavailable. Questions can be manually added, modified,
-- or deleted directly in this table.
-- ============================================================

-- 1. TABLE

CREATE TABLE IF NOT EXISTS public.practice_questions (
  id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  topic        TEXT NOT NULL,
  difficulty   TEXT NOT NULL CHECK (difficulty IN ('Easy', 'Medium', 'Hard')),
  time_limit   INTEGER NOT NULL DEFAULT 60,   -- seconds
  question     TEXT NOT NULL,
  option_a     TEXT NOT NULL,
  option_b     TEXT NOT NULL,
  option_c     TEXT NOT NULL,
  option_d     TEXT NOT NULL,
  correct_index INTEGER NOT NULL CHECK (correct_index BETWEEN 0 AND 3),  -- 0=A,1=B,2=C,3=D
  explanation  TEXT NOT NULL DEFAULT '',
  hint         TEXT NOT NULL DEFAULT '',      -- optional hint shown to user in practice mode
  is_active    BOOLEAN NOT NULL DEFAULT TRUE,
  created_at   TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
  updated_at   TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- 2. INDEXES
CREATE INDEX IF NOT EXISTS idx_practice_questions_topic      ON public.practice_questions(topic);
CREATE INDEX IF NOT EXISTS idx_practice_questions_difficulty ON public.practice_questions(difficulty);
CREATE INDEX IF NOT EXISTS idx_practice_questions_is_active  ON public.practice_questions(is_active);

-- 3. UPDATED_AT TRIGGER
CREATE OR REPLACE FUNCTION public.update_practice_questions_updated_at()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_practice_questions_updated_at ON public.practice_questions;
CREATE TRIGGER trg_practice_questions_updated_at
  BEFORE UPDATE ON public.practice_questions
  FOR EACH ROW EXECUTE FUNCTION public.update_practice_questions_updated_at();

-- 4. ENABLE RLS
ALTER TABLE public.practice_questions ENABLE ROW LEVEL SECURITY;

-- Authenticated users can read active questions
DROP POLICY IF EXISTS "practice_questions_select_active" ON public.practice_questions;
CREATE POLICY "practice_questions_select_active"
ON public.practice_questions
FOR SELECT
TO authenticated
USING (is_active = TRUE);

-- Anon (guests) can also read active questions
DROP POLICY IF EXISTS "practice_questions_select_active_anon" ON public.practice_questions;
CREATE POLICY "practice_questions_select_active_anon"
ON public.practice_questions
FOR SELECT
TO anon
USING (is_active = TRUE);

-- 5. SEED DATA — 12 GATE CS questions for Practice Mode
-- Practice mode includes an extra `hint` column for guided learning.
-- You can manually INSERT / UPDATE / DELETE rows here at any time.

