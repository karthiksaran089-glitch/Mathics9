-- ==========================================
-- Ranked Questions: Computer Networks
-- ==========================================

INSERT INTO public.ranked_questions
  (topic, difficulty, time_limit, question, option_a, option_b, option_c, option_d, correct_index, explanation)
VALUES
(
    'Computer Networks', 'Medium', 60,
    'In TCP, the purpose of the 3-way handshake is to:',
    'Encrypt the data before transmission',
    'Establish a reliable connection by synchronizing sequence numbers',
    'Determine the maximum segment size',
    'Authenticate the client and server',
    1,
    'The TCP 3-way handshake (SYN → SYN-ACK → ACK) establishes a reliable, full-duplex connection by synchronizing initial sequence numbers (ISNs) between client and server.'
  ),
(
    'Computer Networks', 'Easy', 45,
    'Which layer of the OSI model is responsible for breaking data into frames and handling MAC addressing?',
    'Network Layer (Layer 3)', 'Physical Layer (Layer 1)', 'Data Link Layer (Layer 2)', 'Transport Layer (Layer 4)',
    2,
    'The Data Link Layer (Layer 2) is responsible for framing, physical addressing (MAC), error detection (CRC), and flow control on a single network link. Protocols include Ethernet, Wi-Fi (802.11), and PPP.'
  ),
(
    'Computer Networks', 'Medium', 75,
    'What is the purpose of NAT (Network Address Translation)?',
    'Encrypting network traffic between routers', 'Translating private IP addresses to public IP addresses, allowing multiple devices to share one public IP',
    'Assigning dynamic IP addresses to hosts', 'Filtering malicious network packets',
    1,
    'NAT allows multiple devices on a private network (using RFC 1918 addresses like 192.168.x.x) to share a single public IP address. The NAT router modifies packet headers, mapping private (IP:port) pairs to the public IP with different port numbers.'
  ),
(
    'Computer Networks', 'Hard', 90,
    'In TCP''s sliding window protocol, if the receiver advertises a window size of 0, the sender should:',
    'Terminate the connection immediately', 'Continue sending at a reduced rate', 'Stop sending data and start the persist timer to periodically probe the receiver',
    'Retransmit all unacknowledged segments',
    2,
    'A zero window advertisement means the receiver''s buffer is full. The sender stops sending data and starts the persist timer. When the timer expires, the sender sends a 1-byte probe (window probe) to check if the window has opened, preventing deadlock.'
  ),
(
    'Computer Networks', 'Medium', 60,
    'What is the function of ICMP (Internet Control Message Protocol)?',
    'Routing packets between autonomous systems', 'Transporting application data reliably', 'Sending error messages and operational information about IP packet processing',
    'Assigning IP addresses to hosts',
    2,
    'ICMP is used by network devices to send error messages (e.g., "Destination Unreachable", "Time Exceeded") and operational queries (ping uses ICMP Echo Request/Reply). It operates at the Network Layer alongside IP.'
  ),
(
    'Computer Networks', 'Hard', 90,
    'In the context of network flow control, the difference between flow control and congestion control is:',
    'Flow control prevents sender from overwhelming receiver; congestion control prevents sender from overwhelming the network',
    'Flow control operates at the application layer; congestion control at the network layer',
    'They are the same mechanism with different names', 'Congestion control is end-to-end; flow control is router-to-router',
    0,
    'Flow control is end-to-end between sender and receiver, preventing the sender from overwhelming the receiver''s buffer (using receiver window in TCP). Congestion control prevents the sender from overwhelming intermediate network routers/links (using cwnd in TCP).'
  ),
(
    'Computer Networks', 'Easy', 45,
    'Which protocol is used to resolve domain names to IP addresses?',
    'DHCP', 'ARP', 'DNS', 'SMTP',
    2,
    'DNS (Domain Name System) translates human-readable domain names (www.example.com) to IP addresses (93.184.216.34). It uses a hierarchical distributed database with root servers, TLD servers, and authoritative name servers.'
  ),
(
    'Computer Networks', 'Medium', 75,
    'What is the maximum data rate of a noisy channel with bandwidth 3kHz and SNR of 30dB according to Shannon''s theorem?',
    '~10 kbps', '~20 kbps', '~30 kbps', '~50 kbps',
    2,
    'Shannon capacity = B × log₂(1 + SNR). SNR of 30dB = 10^(30/10) = 1000. Capacity = 3000 × log₂(1001) = 3000 × 9.97 ≈ 29,910 bps ≈ 30 kbps. This is the theoretical maximum regardless of encoding scheme.'
  ),
(
    'Computer Networks', 'Hard', 90,
    'In OSPF, what is the purpose of the Designated Router (DR) on a multi-access network?',
    'To route packets between different OSPF areas', 'To reduce the number of adjacencies by acting as a central point for LSA distribution, reducing O(n²) adjacencies to O(n)',
    'To authenticate OSPF neighbors', 'To assign IP addresses to OSPF routers',
    1,
    'On multi-access networks (like Ethernet), OSPF elects a DR (and BDR) to reduce routing overhead. Without DR, each router forms full adjacency with every other (O(n²) adjacencies). With DR, each router only forms full adjacency with DR/BDR (O(n) adjacencies).'
  ),
(
    'Computer Networks', 'Medium', 60,
    'The HTTPS protocol secures HTTP by running it over which security protocol?',
    'IPSec', 'SSH', 'TLS/SSL', 'SFTP',
    2,
    'HTTPS (HTTP Secure) runs HTTP over TLS (Transport Layer Security, formerly SSL). TLS provides encryption (confidentiality), authentication (via certificates), and integrity (MAC). It operates between the Application and Transport layers.'
  ),
(
    'Computer Networks', 'Hard', 90,
    'In MPLS (Multiprotocol Label Switching), packets are forwarded based on:',
    'IP destination addresses using longest prefix match', 'Short fixed-length labels that map to predetermined paths (LSPs)',
    'MAC addresses at Layer 2', 'TCP port numbers',
    1,
    'MPLS forwards packets using short fixed-length labels rather than IP addresses. At ingress, packets are labeled. Interior LSRs (Label Switching Routers) forward based on label lookup in a table, swapping labels. This provides fast switching and enables traffic engineering, VPNs, and QoS.'
  ),
(
    'Computer Networks', 'Medium', 60,
    'What is the key difference between a hub and a switch in a local area network?',
    'A hub operates at Layer 3; a switch at Layer 2', 'A hub broadcasts to all ports; a switch forwards frames only to the destination port using MAC address table',
    'A switch is slower than a hub', 'A hub supports full-duplex; a switch only half-duplex',
    1,
    'A hub (Layer 1) broadcasts every received frame to all ports, creating a shared collision domain. A switch (Layer 2) learns MAC addresses and forwards frames only to the specific port of the destination device, creating separate collision domains and improving network efficiency.'
  ),
(
    'Computer Networks', 'Hard', 90,
    'In the context of network security, a "SYN flood attack" exploits which TCP mechanism?',
    'The TCP sliding window protocol', 'The three-way handshake by sending many SYN packets without completing the handshake, exhausting server connection table',
    'TCP''s congestion control algorithm', 'TCP sequence number prediction',
    1,
    'A SYN flood (DoS attack) sends many TCP SYN packets with spoofed source IPs. The server responds with SYN-ACK and waits (in SYN-RECEIVED state) for ACK that never comes. The half-open connections fill the server''s backlog queue, preventing legitimate connections. SYN cookies mitigate this.'
  ),
(
    'Computer Networks', 'Medium', 60,
    'In IPv4, which class of addresses is reserved for multicast communication?',
    'Class A (1.0.0.0 to 126.255.255.255)', 'Class B (128.0.0.0 to 191.255.255.255)', 'Class C (192.0.0.0 to 223.255.255.255)', 'Class D (224.0.0.0 to 239.255.255.255)',
    3,
    'Class D addresses (224.0.0.0 to 239.255.255.255) are reserved for multicast. A single multicast address identifies a group of receivers. Multicast is used for streaming, OSPF (224.0.0.5/6), and RIP (224.0.0.9) to send one packet to multiple recipients efficiently.'
  ),
(
    'Computer Networks', 'Easy', 45,
    'What port number does the FTP protocol use for control connections?',
    '20', '21', '22', '23',
    1,
    'FTP uses port 21 for control connections (commands and responses) and port 20 for data connections in active mode. Port 22 is SSH, port 23 is Telnet. FTP transmits data and credentials in plaintext; SFTP (over SSH) provides secure alternative.'
  ),
(
    'Computer Networks', 'Hard', 90,
    'In the Spanning Tree Protocol (STP) for Ethernet networks, the purpose of blocking ports is to:',
    'Improve network performance by limiting traffic', 'Prevent broadcast storms caused by network loops in Layer 2 networks',
    'Provide encryption on specific network segments', 'Balance traffic load across multiple paths',
    1,
    'STP prevents Layer 2 (Ethernet) loops by electing a Root Bridge and putting redundant links in Blocking state. Without STP, a broadcast frame would loop indefinitely (broadcast storm), consuming all bandwidth. STP ensures a loop-free logical topology while maintaining redundant physical links.'
  );
