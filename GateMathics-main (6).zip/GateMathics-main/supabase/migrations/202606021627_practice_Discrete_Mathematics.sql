-- ==========================================
-- Practice Questions: Discrete Mathematics
-- ==========================================

INSERT INTO public.practice_questions
  (topic, difficulty, time_limit, question, option_a, option_b, option_c, option_d, correct_index, explanation, hint)
VALUES
(
    'Discrete Mathematics', 'Medium', 60,
    'How many edges does a complete graph Kₙ have?',
    'n(n-1)', 'n(n-1)/2', 'n²', 'n(n+1)/2',
    1,
    'A complete graph Kₙ has n(n-1)/2 edges. Each of the n vertices connects to every other vertex, giving n(n-1) directed pairs. Since each undirected edge is counted twice, we divide by 2.',
    'Think of it as choosing 2 vertices from n to form an edge — this is a combinations problem: C(n, 2).'
  ),
(
    'Discrete Mathematics', 'Easy', 45,
    'What is a "function" in the mathematical sense?',
    'A program subroutine', 'A relation where each element of the domain maps to exactly one element in the codomain',
    'A relation where each element of the codomain has exactly one preimage', 'Any subset of the Cartesian product A × B',
    1,
    'A function f: A → B is a relation where every element in A (domain) maps to exactly one element in B (codomain). If an element maps to multiple outputs, it is not a function. f is injective if distinct inputs give distinct outputs; surjective if every output has a preimage; bijective if both.',
    'The key requirement is that each input has exactly one output. Multiple inputs can share an output (unless injective).'
  )
ON CONFLICT DO NOTHING;
