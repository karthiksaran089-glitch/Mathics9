-- ============================================================
-- GateMathics: Analytics Dashboard Views & Functions
-- ============================================================
-- Provides pre-computed views for the analytics dashboard,
-- combining data from user_profiles, ranked_sessions, and
-- practice_sessions tables.
--
-- DATA FLOW:
-- ──────────
-- Practice Mode → saves to `practice_sessions` table
--   (PracticeMode.tsx → savePracticeSession() → Supabase)
--   Data: questions_total, correct, incorrect, timeout,
--         accuracy, avg_speed_seconds, hints_used,
--         topics_practiced, difficulty
--
-- Ranked Mode → saves to `ranked_sessions` table
--   (RankedModeClient.tsx → saveRankedSession() → Supabase)
--   Data: questions_total, correct, incorrect, timeout,
--         accuracy, avg_speed_seconds, lp_before, lp_after,
--         lp_change, rank_before, rank_after,
--         topics_played, topics_banned
--
-- Both modes → update `user_profiles` table
--   (aggregated stats: total_sessions, total_ranked_sessions,
--    total_practice_sessions, total_questions_answered,
--    total_correct, total_incorrect, total_timeout,
--    overall_accuracy, avg_answer_speed_seconds, lp, rank,
--    daily_streak, longest_streak, last_active_date)
--
-- DASHBOARD VIEWS:
-- ────────────────
-- Analytics Dashboard  ← reads from `analytics_*` views
--   (analytics/page.tsx → Supabase views)
--   Combines data from BOTH practice and ranked sessions
--
-- Practice Dashboard   ← reads from `practice_sessions` table
--   (practice-dashboard/page.tsx → Supabase table)
--   Shows ONLY practice mode data
--
-- Ranked Dashboard     ← reads from `ranked_sessions` table
--   (ranked-dashboard/page.tsx → Supabase table)
--   Shows ONLY ranked mode data
--
-- Profile Page         ← reads from `profile_*` views
--   (profile/ProfileContent.tsx → Supabase views)
--   Identity + progression + session breakdown
--
-- REAL-TIME SYNC:
-- ───────────────
-- All dashboards subscribe to Supabase Realtime on:
--   - practice_sessions (INSERT/UPDATE/DELETE)
--   - ranked_sessions (INSERT/UPDATE/DELETE)
--   - user_profiles (UPDATE)
-- This ensures results sync across tabs and devices instantly.
-- ============================================================

-- 1. ANALYTICS ENUM FOR MASTERY LEVELS
DROP TYPE IF EXISTS public.mastery_level CASCADE;
CREATE TYPE public.mastery_level AS ENUM ('low', 'medium', 'high', 'excellent');

-- 2. ANALYTICS USER SUMMARY VIEW
-- Single source of truth for all profile stats displayed on dashboard
DROP VIEW IF EXISTS public.analytics_user_summary CASCADE;
CREATE VIEW public.analytics_user_summary WITH (security_invoker = true) AS
SELECT
  up.id AS user_id,
  up.lp,
  up.rank,
  up.overall_accuracy,
  up.avg_answer_speed_seconds,
  up.daily_streak,
  up.longest_streak,
  up.total_sessions,
  up.total_ranked_sessions,
  up.total_practice_sessions,
  up.total_questions_answered,
  up.total_correct,
  up.total_incorrect,
  up.total_timeout,
  up.last_active_date,
  up.created_at AS account_created_at,
  -- Computed fields
  CASE
    WHEN up.total_questions_answered > 0
    THEN ROUND((up.total_correct::NUMERIC / up.total_questions_answered) * 100, 1)
    ELSE 0
  END AS computed_accuracy,
  -- LP progression rate (LP per ranked session)
  CASE
    WHEN up.total_ranked_sessions > 0
    THEN ROUND(up.lp::NUMERIC / NULLIF(up.total_ranked_sessions, 0), 1)
    ELSE 0
  END AS lp_per_ranked_session,
  -- Total hints used across all practice sessions (if available via subquery)
  COALESCE((
    SELECT SUM(ps.hints_used) FROM public.practice_sessions ps WHERE ps.user_id = up.id
  ), 0) AS total_hints_used
FROM public.user_profiles up;

-- 3. ANALYTICS TOPIC MASTERY VIEW
-- Computes per-topic accuracy from both ranked and practice sessions
DROP VIEW IF EXISTS public.analytics_topic_mastery CASCADE;
CREATE VIEW public.analytics_topic_mastery WITH (security_invoker = true) AS
WITH topic_list AS (
  SELECT unnest(ARRAY[
    'Algorithms', 'Data Structures', 'DBMS', 'Operating Systems',
    'Computer Networks', 'Theory of Computation', 'Compiler Design',
    'Discrete Mathematics', 'Computer Organisation', 'Programming Languages',
    'Software Engineering', 'Artificial Intelligence'
  ]) AS topic_name
),
ranked_topics AS (
  SELECT
    rs.user_id,
    unnest(rs.topics_played) AS topic,
    rs.questions_total AS total_q,
    rs.questions_correct AS correct_q
  FROM public.ranked_sessions rs
),
practice_topics AS (
  SELECT
    ps.user_id,
    unnest(ps.topics_practiced) AS topic,
    ps.questions_total AS total_q,
    ps.questions_correct AS correct_q
  FROM public.practice_sessions ps
),
all_topics_agg AS (
  SELECT
    user_id,
    topic,
    SUM(total_q) AS total_questions,
    SUM(correct_q) AS total_correct
  FROM (
    SELECT * FROM ranked_topics
    UNION ALL
    SELECT * FROM practice_topics
  ) combined
  GROUP BY user_id, topic
)
SELECT
  tl.topic_name AS topic,
  ata.user_id,
  COALESCE(ata.total_questions, 0) AS total_questions,
  COALESCE(ata.total_correct, 0) AS total_correct,
  CASE
    WHEN COALESCE(ata.total_questions, 0) > 0
    THEN ROUND((COALESCE(ata.total_correct, 0)::NUMERIC / NULLIF(ata.total_questions, 0)) * 100, 1)
    ELSE 0
  END AS mastery_percent,
  CASE
    WHEN COALESCE(ata.total_questions, 0) = 0 THEN 'low'::public.mastery_level
    WHEN ROUND((COALESCE(ata.total_correct, 0)::NUMERIC / NULLIF(ata.total_questions, 0)) * 100, 1) >= 80 THEN 'excellent'::public.mastery_level
    WHEN ROUND((COALESCE(ata.total_correct, 0)::NUMERIC / NULLIF(ata.total_questions, 0)) * 100, 1) >= 60 THEN 'high'::public.mastery_level
    WHEN ROUND((COALESCE(ata.total_correct, 0)::NUMERIC / NULLIF(ata.total_questions, 0)) * 100, 1) >= 40 THEN 'medium'::public.mastery_level
    ELSE 'low'::public.mastery_level
  END AS mastery_level
FROM topic_list tl
CROSS JOIN (
  SELECT DISTINCT user_id FROM all_topics_agg
  UNION
  SELECT id FROM public.user_profiles
) users
LEFT JOIN all_topics_agg ata ON tl.topic_name = ata.topic AND users.user_id = ata.user_id;

-- 4. ANALYTICS SESSION HISTORY VIEW
-- Combined view of ranked + practice sessions with a unified interface
DROP VIEW IF EXISTS public.analytics_session_history CASCADE;
CREATE VIEW public.analytics_session_history WITH (security_invoker = true) AS
SELECT
  rs.id AS session_id,
  rs.user_id,
  rs.session_date,
  'Ranked'::TEXT AS mode,
  rs.questions_total,
  rs.questions_correct,
  rs.questions_incorrect,
  rs.questions_timeout,
  rs.accuracy,
  rs.avg_speed_seconds,
  rs.lp_change,
  rs.lp_before,
  rs.lp_after,
  rs.rank_before,
  rs.rank_after,
  rs.topics_played AS topics,
  NULL::TEXT[] AS topics_practiced,
  NULL::TEXT AS difficulty,
  0 AS hints_used
FROM public.ranked_sessions rs

UNION ALL

SELECT
  ps.id AS session_id,
  ps.user_id,
  ps.session_date,
  'Practice'::TEXT AS mode,
  ps.questions_total,
  ps.questions_correct,
  ps.questions_incorrect,
  ps.questions_timeout,
  ps.accuracy,
  ps.avg_speed_seconds,
  0 AS lp_change,
  0 AS lp_before,
  0 AS lp_after,
  NULL::TEXT AS rank_before,
  NULL::TEXT AS rank_after,
  NULL::TEXT[] AS topics,
  ps.topics_practiced,
  ps.difficulty,
  ps.hints_used
FROM public.practice_sessions ps;

-- 5. ANALYTICS LP TREND VIEW
-- Last 7 ranked sessions for LP trend chart
DROP VIEW IF EXISTS public.analytics_lp_trend CASCADE;
CREATE VIEW public.analytics_lp_trend WITH (security_invoker = true) AS
SELECT
  user_id,
  id AS session_id,
  session_date,
  lp_before,
  lp_after,
  lp_change,
  rank_before,
  rank_after,
  ROW_NUMBER() OVER (PARTITION BY user_id ORDER BY session_date DESC) AS session_rank_desc
FROM public.ranked_sessions
ORDER BY user_id, session_date DESC;

-- 6. ANALYTICS ACTIVITY VIEW
-- 35-day activity calendar data
DROP VIEW IF EXISTS public.analytics_activity CASCADE;
CREATE VIEW public.analytics_activity WITH (security_invoker = true) AS
WITH date_series AS (
  SELECT generate_series(
    CURRENT_DATE - INTERVAL '34 days',
    CURRENT_DATE,
    '1 day'::INTERVAL
  )::DATE AS activity_date
),
daily_activity AS (
  SELECT
    user_id,
    session_date::DATE AS activity_date,
    COUNT(*) AS session_count
  FROM (
    SELECT user_id, session_date FROM public.ranked_sessions
    WHERE session_date >= CURRENT_DATE - INTERVAL '34 days'
    UNION ALL
    SELECT user_id, session_date FROM public.practice_sessions
    WHERE session_date >= CURRENT_DATE - INTERVAL '34 days'
  ) combined
  GROUP BY user_id, session_date::DATE
)
SELECT
  ds.activity_date,
  da.user_id,
  COALESCE(da.session_count, 0) AS session_count,
  EXTRACT(DOW FROM ds.activity_date)::INTEGER AS day_of_week,
  EXTRACT(WEEK FROM ds.activity_date)::INTEGER AS week_number
FROM date_series ds
LEFT JOIN daily_activity da ON ds.activity_date = da.activity_date;

-- 7. ANALYTICS SESSION STATS VIEW
-- Aggregated stats for the session history summary bar
DROP VIEW IF EXISTS public.analytics_session_stats CASCADE;
CREATE VIEW public.analytics_session_stats WITH (security_invoker = true) AS
SELECT
  user_id,
  COUNT(*) FILTER (WHERE mode = 'Ranked') AS total_ranked_sessions,
  COUNT(*) FILTER (WHERE mode = 'Practice') AS total_practice_sessions,
  COUNT(*) FILTER (WHERE mode = 'Ranked' AND lp_change > 0) AS ranked_wins,
  COUNT(*) FILTER (WHERE mode = 'Ranked' AND lp_change < 0) AS ranked_losses,
  CASE
    WHEN COUNT(*) FILTER (WHERE mode = 'Ranked') > 0
    THEN ROUND(
      (COUNT(*) FILTER (WHERE mode = 'Ranked' AND lp_change > 0)::NUMERIC /
       NULLIF(COUNT(*) FILTER (WHERE mode = 'Ranked'), 0)) * 100, 1
    )
    ELSE 0
  END AS ranked_win_rate,
  COALESCE(MAX(accuracy) FILTER (WHERE mode = 'Ranked'), 0) AS best_ranked_accuracy,
  COALESCE(ROUND(AVG(accuracy) FILTER (WHERE mode = 'Ranked'), 1), 0) AS avg_ranked_accuracy,
  COALESCE(SUM(lp_change) FILTER (WHERE lp_change > 0), 0) AS total_lp_gained,
  COALESCE(SUM(ABS(lp_change)) FILTER (WHERE lp_change < 0), 0) AS total_lp_lost
FROM public.analytics_session_history
GROUP BY user_id;

-- 8. ANALYTICS WEAK TOPICS VIEW
-- Identifies topics below 55% mastery for next-step suggestions
DROP VIEW IF EXISTS public.analytics_weak_topics CASCADE;
CREATE VIEW public.analytics_weak_topics WITH (security_invoker = true) AS
SELECT
  user_id,
  topic,
  total_questions,
  total_correct,
  mastery_percent
FROM public.analytics_topic_mastery
WHERE mastery_percent > 0 AND mastery_percent < 55
ORDER BY mastery_percent ASC;

-- 9. INDEXES TO SPEED UP ANALYTICS QUERIES
CREATE INDEX IF NOT EXISTS idx_ranked_sessions_user_date
  ON public.ranked_sessions(user_id, session_date DESC);
CREATE INDEX IF NOT EXISTS idx_practice_sessions_user_date
  ON public.practice_sessions(user_id, session_date DESC);
CREATE INDEX IF NOT EXISTS idx_ranked_sessions_topics
  ON public.ranked_sessions USING GIN(topics_played);
CREATE INDEX IF NOT EXISTS idx_practice_sessions_topics
  ON public.practice_sessions USING GIN(topics_practiced);

-- 10. RLS POLICIES FOR VIEWS
-- The views use security_invoker = true, so they inherit RLS from
-- the underlying tables. The existing RLS policies on ranked_sessions,
-- practice_sessions, and user_profiles automatically apply.

-- 11. HELPER FUNCTION: Get user's next rank suggestion
DROP FUNCTION IF EXISTS public.get_next_rank_suggestion;
CREATE FUNCTION public.get_next_rank_suggestion(p_user_id UUID)
RETURNS TABLE(
  current_rank TEXT,
  current_lp INTEGER,
  next_rank TEXT,
  lp_needed INTEGER
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_lp INTEGER;
  v_rank TEXT;
BEGIN
  SELECT up.lp, up.rank::TEXT INTO v_lp, v_rank
  FROM public.user_profiles up WHERE up.id = p_user_id;

  RETURN QUERY
  SELECT
    v_rank AS current_rank,
    v_lp AS current_lp,
    next_rank.name AS next_rank,
    (next_rank.min_lp - v_lp) AS lp_needed
  FROM (
    SELECT 'Bronze' AS name, 0 AS min_lp
    UNION ALL SELECT 'Silver', 500
    UNION ALL SELECT 'Gold', 1000
    UNION ALL SELECT 'Platinum', 1500
    UNION ALL SELECT 'Diamond', 2000
    UNION ALL SELECT 'Grandmaster', 2500
  ) AS next_rank
  WHERE next_rank.min_lp > v_lp
  ORDER BY next_rank.min_lp ASC
  LIMIT 1;
END;
$$;