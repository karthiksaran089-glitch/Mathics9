-- ==========================================
-- Practice Questions: Theory of Computation
-- ==========================================

INSERT INTO public.practice_questions
  (topic, difficulty, time_limit, question, option_a, option_b, option_c, option_d, correct_index, explanation, hint)
VALUES
(
    'Theory of Computation', 'Hard', 90,
    'Which of the following languages is NOT context-free?',
    'L = {aⁿbⁿ | n ≥ 0}', 'L = {aⁿbⁿcⁿ | n ≥ 0}', 'L = {ww^R | w ∈ {a,b}*}', 'L = {aⁿb²ⁿ | n ≥ 0}',
    1,
    'L = {aⁿbⁿcⁿ | n ≥ 0} is NOT context-free. It requires counting and matching three quantities simultaneously, which a PDA cannot do.',
    'A pushdown automaton has only one stack. Think about how many independent counts are needed to verify membership.'
  ),
(
    'Theory of Computation', 'Easy', 45,
    'What is the language accepted by a DFA with a single state that is both the start state and the accepting state, with self-loops on all input symbols?',
    'Empty language ∅', 'Only the empty string ε', 'All strings over the input alphabet Σ*', 'Only strings of length 1',
    2,
    'If the only state is both the start and accepting state, every string (including ε) will end in this accepting state. Since the self-loops on all symbols keep the DFA in this state for any input, every string is accepted, giving the language Σ*.',
    'If you start in an accepting state and never leave it (self-loops), what happens for every possible input string?'
  ),
(
    'Theory of Computation', 'Medium', 75,
    'Which of the following is a correct statement about the pumping lemma for regular languages?',
    'If a language satisfies the pumping lemma, it must be regular', 'The pumping lemma provides a necessary condition for regularity — if a language violates it, the language is not regular',
    'The pumping lemma can prove a language IS regular', 'The pumping lemma applies only to finite languages',
    1,
    'The pumping lemma gives a necessary (but not sufficient) condition for regularity. It is used as a proof tool: if a language does NOT satisfy the pumping lemma, it is definitely not regular. However, a language can satisfy the pumping lemma and still not be regular (e.g., {a^p | p is prime} satisfies conditions for small pumping lengths).',
    'The pumping lemma is used to DISPROVE regularity. Can it ever prove a language IS regular?'
  ),
(
    'Theory of Computation', 'Hard', 90,
    'The complement of a context-free language (CFL) is:',
    'Always a CFL', 'Always a regular language', 'Not necessarily a CFL (CFLs are not closed under complement)',
    'Always recursively enumerable but not CFL',
    2,
    'CFLs are NOT closed under complement. While the complement of some CFLs may be CFL (e.g., complement of a regular language is regular, and regular ⊂ CFL), there exist CFLs whose complements are not CFL. This is in contrast to regular languages and decidable languages, which ARE closed under complement.',
    'CFLs are not closed under intersection. Hint: De Morgan''s law relates complement and intersection.'
  ),
(
    'Theory of Computation', 'Medium', 60,
    'A Turing Machine is said to "recognize" a language if:',
    'It halts and accepts all strings in the language, and halts and rejects all strings not in the language',
    'It halts and accepts strings in the language, but may loop forever on strings not in the language',
    'It accepts all strings over Σ*', 'It runs in polynomial time on all inputs',
    1,
    'Language recognition (semi-decision) means the TM accepts strings in L (halts in accept state) but for strings not in L, it may either reject (halt in reject state) or loop forever. A TM that always halts (accept or reject) DECIDES the language. Decidable ⊂ Recognizable.',
    'Recognition allows looping on non-members. Decision requires halting on ALL inputs. Which is weaker?'
  ),
(
    'Theory of Computation', 'Hard', 90,
    'Which of the following is a consequence of Rice''s Theorem?',
    'All properties of Turing Machines are decidable', 'The halting problem is decidable',
    'Any non-trivial semantic property of Turing Machine programs (about the language they recognize) is undecidable',
    'Context-free grammars can recognize all computable languages',
    2,
    'Rice''s Theorem: any non-trivial property P of Turing Machine programs (where "non-trivial" means some TMs have P and some don''t, and P depends only on the language recognized, not the TM mechanism) is undecidable. Examples: "Does TM M accept the empty string?", "Is L(M) regular?", "Is L(M) finite?" — all undecidable.',
    'Rice''s Theorem is very powerful. It says you cannot algorithmically determine ANYTHING interesting about what a program computes.'
  ),
(
    'Theory of Computation', 'Easy', 45,
    'What is the minimum number of states in a DFA that accepts only the empty string ε?',
    '1', '2', '3', '0',
    1,
    'A DFA accepting only ε needs: (1) a start state that is also an accepting state (to accept ε), and (2) a dead/trap state that is not accepting (to reject all non-empty strings). Any input from the start state goes to the dead state. Minimum 2 states.',
    'To accept ε, the start state must be accepting. To reject all other strings, what must happen when any symbol is read?'
  ),
(
    'Theory of Computation', 'Medium', 75,
    'Context-Sensitive Languages (CSL) are recognized by which automaton model?',
    'Pushdown Automaton (PDA)', 'Finite Automaton (DFA/NFA)', 'Linear Bounded Automaton (LBA)', 'Turing Machine (unrestricted)',
    2,
    'The Chomsky hierarchy: Regular (FA) ⊂ Context-Free (PDA) ⊂ Context-Sensitive (LBA) ⊂ Recursively Enumerable (TM). A Linear Bounded Automaton is a TM whose tape is limited to the length of the input (multiplied by a constant). Context-sensitive grammars have productions where |α| ≤ |β| (non-contracting).',
    'Recall the Chomsky hierarchy: Type 3 (Regular), Type 2 (CFL), Type 1 (CSL), Type 0 (RE). Match each grammar type to its automaton.'
  ),
(
    'Theory of Computation', 'Hard', 90,
    'The language of all valid C programs that halt on all inputs is:',
    'Context-free', 'Recursive (decidable)', 'Recursively enumerable but not recursive', 'Not recursively enumerable',
    3,
    'This language is not recursively enumerable. Determining if an arbitrary program halts on all inputs is the "halting problem for all inputs" — even harder than the standard halting problem. The set of programs that halt on all inputs is a Π₂-complete problem in the arithmetic hierarchy, which is neither RE nor co-RE.',
    'The halting problem is already undecidable. What about deciding if a program halts on ALL possible inputs?'
  );
