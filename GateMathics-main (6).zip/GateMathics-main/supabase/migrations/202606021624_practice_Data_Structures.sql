-- ==========================================
-- Practice Questions: Data Structures
-- ==========================================

INSERT INTO public.practice_questions
  (topic, difficulty, time_limit, question, option_a, option_b, option_c, option_d, correct_index, explanation, hint)
VALUES
(
    'Data Structures', 'Easy', 45,
    'In a singly linked list, inserting a node at the beginning (head) has time complexity:',
    'O(n)', 'O(log n)', 'O(1)', 'O(n log n)',
    2,
    'Inserting at the head of a singly linked list is O(1) because it only requires creating the new node, setting its next pointer to the current head, and updating the head pointer.',
    'You do not need to traverse the list at all — you only update the head pointer.'
  ),
(
    'Data Structures', 'Easy', 45,
    'What is the maximum number of nodes in a binary tree of height h?',
    '2h', '2h - 1', '2^(h+1) - 1', '2^h',
    2,
    'A binary tree of height h (where height 0 = root only) has at most 2^0 + 2^1 + ... + 2^h = 2^(h+1) - 1 nodes (geometric series sum). This maximum is achieved by a complete/perfect binary tree.',
    'At each level i of the tree, there are at most 2^i nodes. Sum from level 0 to h using geometric series formula.'
  ),
(
    'Data Structures', 'Medium', 60,
    'In an AVL tree, what is the maximum height for a tree with n nodes?',
    'O(n)', 'O(log n)', 'O(n log n)', 'O(√n)',
    1,
    'AVL trees maintain the invariant that left and right subtree heights differ by at most 1. This balance condition guarantees height O(log n). The minimum number of nodes in an AVL tree of height h is N(h) = N(h-1) + N(h-2) + 1 (Fibonacci-like), giving height at most 1.44 × log₂(n).',
    'AVL trees are self-balancing. The balance condition directly bounds the maximum height relative to n.'
  ),
(
    'Data Structures', 'Hard', 90,
    'In a Splay Tree, the "splay" operation brings the accessed node to the root using rotations. The amortized time complexity of each splay operation is:',
    'O(n)', 'O(log n)', 'O(1)', 'O(n log n)',
    1,
    'Splay trees achieve O(log n) amortized time per operation using the potential method. Although individual operations can be O(n) in the worst case (e.g., accessing elements in sorted order without splaying), the amortized cost over any sequence of m operations is O(m log n).',
    'Splay trees self-adjust. Recently accessed elements are near the root. Think about amortized analysis over many operations.'
  ),
(
    'Data Structures', 'Medium', 60,
    'What is the time complexity of the HEAPIFY-DOWN (sift-down) operation on a binary heap?',
    'O(1)', 'O(log n)', 'O(n)', 'O(n log n)',
    1,
    'HEAPIFY-DOWN starts at a node and swaps with the larger child (for max-heap) until the heap property is restored. The maximum number of swaps equals the height of the subtree, which is O(log n) for a binary heap with n elements.',
    'At most how many levels can a node travel downward in a heap with n elements?'
  ),
(
    'Data Structures', 'Easy', 45,
    'Which of the following is NOT a property of a valid binary search tree (BST)?',
    'Left subtree values are less than root', 'Right subtree values are greater than root',
    'Both subtrees are also valid BSTs', 'The tree must be balanced',
    3,
    'BST properties: left subtree contains only values < root, right subtree contains only values > root, and both subtrees must themselves be valid BSTs. Balance is NOT a BST requirement — an unbalanced BST is still valid (just inefficient).',
    'BST defines an ordering property, not a structural balance property. Those are different concepts.'
  ),
(
    'Data Structures', 'Hard', 90,
    'In a hash table with open addressing and linear probing, what is the expected number of probes for a successful search when the load factor α = 0.75?',
    '~2.5', '~3.0', '~2.5 using formula (1 + 1/(1-α))/2', '~1.5',
    2,
    'For linear probing, expected probes for successful search = (1/2)(1 + 1/(1-α)). With α = 0.75: (1/2)(1 + 1/0.25) = (1/2)(1 + 4) = 2.5. For unsuccessful search: (1/2)(1 + 1/(1-α)²) = (1/2)(1 + 16) = 8.5.',
    'Use the formula for linear probing successful search: (1 + 1/(1-α)) / 2. Plug in α = 0.75.'
  ),
(
    'Data Structures', 'Medium', 75,
    'What is the key advantage of a deque (double-ended queue) over a standard queue?',
    'Faster access to middle elements', 'Elements can be inserted and deleted from both ends in O(1)',
    'It uses less memory than a standard queue', 'It automatically sorts inserted elements',
    1,
    'A deque (double-ended queue) supports O(1) insertion and deletion at both the front and rear. A standard queue only allows O(1) operations at one end each (enqueue at rear, dequeue at front). Deques support both stack (LIFO) and queue (FIFO) behavior.',
    'The name "double-ended" is the hint — it supports operations at both ends efficiently.'
  ),
(
    'Data Structures', 'Hard', 90,
    'In a Trie (prefix tree) storing n words with maximum word length L, what is the time complexity of searching for a word?',
    'O(n)', 'O(L)', 'O(n × L)', 'O(log n)',
    1,
    'Searching in a Trie takes O(L) time where L is the length of the search key. Each character in the word corresponds to one node traversal. The search is independent of n (number of words stored), making Trie search O(L) regardless of dictionary size.',
    'In a Trie, you follow one node per character. How many characters are in the search word?'
  ),
(
    'Data Structures', 'Easy', 45,
    'A stack implemented using an array supports which of the following operations in O(1) time?',
    'Only push', 'Only pop', 'Both push and pop, but not search', 'Push, pop, and search',
    2,
    'Stack (array-based) supports O(1) push (add to top) and O(1) pop (remove from top) by maintaining a top pointer/index. Searching requires O(n) traversal since stacks do not support random access for arbitrary elements.',
    'A stack only allows access to the top element. Which operations only touch the top?'
  ),
(
    'Data Structures', 'Medium', 60,
    'In a graph represented as an adjacency matrix, checking if an edge exists between vertices u and v takes:',
    'O(V)', 'O(E)', 'O(1)', 'O(V + E)',
    2,
    'An adjacency matrix is a 2D array where matrix[u][v] = 1 (or edge weight) if edge (u,v) exists, 0 otherwise. Checking if edge (u,v) exists is simply reading matrix[u][v], which is O(1) array access. Trade-off: uses O(V²) space regardless of edge count.',
    'An adjacency matrix stores edges as array entries. Accessing a specific array element by index takes constant time.'
  );
