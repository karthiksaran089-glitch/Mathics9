-- GateMathics: User Profiles + Auth Module
-- Starting rank: Silver (not Bronze), 0 LP
-- ============================================================

-- 1. TYPES
DROP TYPE IF EXISTS public.auth_method CASCADE;
CREATE TYPE public.auth_method AS ENUM ('google', 'email_otp', 'guest');

DROP TYPE IF EXISTS public.rank_tier CASCADE;
CREATE TYPE public.rank_tier AS ENUM ('Silver', 'Gold', 'Platinum', 'Diamond', 'Master', 'Grandmaster');

-- 2. CORE TABLES

-- User profiles (authenticated users)
CREATE TABLE IF NOT EXISTS public.user_profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email TEXT,
  display_name TEXT NOT NULL DEFAULT '',
  avatar_url TEXT DEFAULT '',
  auth_method public.auth_method DEFAULT 'email_otp',
  -- Rank & LP
  rank public.rank_tier DEFAULT 'Silver'::public.rank_tier,
  lp INTEGER DEFAULT 0,
  -- Performance stats (all zeroed on first login)
  total_questions_answered INTEGER DEFAULT 0,
  total_correct INTEGER DEFAULT 0,
  total_incorrect INTEGER DEFAULT 0,
  total_timeout INTEGER DEFAULT 0,
  overall_accuracy NUMERIC(5,2) DEFAULT 0.00,
  avg_answer_speed_seconds NUMERIC(6,2) DEFAULT 0.00,
  daily_streak INTEGER DEFAULT 0,
  longest_streak INTEGER DEFAULT 0,
  last_active_date DATE,
  -- Session history
  total_sessions INTEGER DEFAULT 0,
  total_ranked_sessions INTEGER DEFAULT 0,
  total_practice_sessions INTEGER DEFAULT 0,
  -- Timestamps
  created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- Guest sessions (temporary, 24h TTL)
CREATE TABLE IF NOT EXISTS public.guest_sessions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  guest_name TEXT NOT NULL,
  session_token TEXT NOT NULL UNIQUE,
  expires_at TIMESTAMPTZ NOT NULL DEFAULT (CURRENT_TIMESTAMP + INTERVAL '24 hours'),
  created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- 3. INDEXES
CREATE INDEX IF NOT EXISTS idx_user_profiles_email ON public.user_profiles(email);
CREATE INDEX IF NOT EXISTS idx_user_profiles_rank ON public.user_profiles(rank);
CREATE INDEX IF NOT EXISTS idx_guest_sessions_token ON public.guest_sessions(session_token);
CREATE INDEX IF NOT EXISTS idx_guest_sessions_expires ON public.guest_sessions(expires_at);

-- 4. FUNCTIONS (must be before RLS policies)

-- Auto-create user profile on first sign-in
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  INSERT INTO public.user_profiles (
    id,
    email,
    display_name,
    avatar_url,
    auth_method,
    rank,
    lp,
    total_questions_answered,
    total_correct,
    total_incorrect,
    total_timeout,
    overall_accuracy,
    avg_answer_speed_seconds,
    daily_streak,
    longest_streak,
    total_sessions,
    total_ranked_sessions,
    total_practice_sessions
  ) VALUES (
    NEW.id,
    NEW.email,
    COALESCE(NEW.raw_user_meta_data->>'full_name', NEW.raw_user_meta_data->>'name', split_part(COALESCE(NEW.email, ''), '@', 1), 'User'),
    COALESCE(NEW.raw_user_meta_data->>'avatar_url', NEW.raw_user_meta_data->>'picture', ''),
    COALESCE((NEW.raw_user_meta_data->>'auth_method')::public.auth_method, 'email_otp'::public.auth_method),
    'Silver'::public.rank_tier,
    0,
    0, 0, 0, 0,
    0.00, 0.00,
    0, 0,
    0, 0, 0
  )
  ON CONFLICT (id) DO NOTHING;
  RETURN NEW;
END;
$$;

-- Update updated_at timestamp
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$;

-- 5. ENABLE RLS
ALTER TABLE public.user_profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.guest_sessions ENABLE ROW LEVEL SECURITY;

-- 6. RLS POLICIES

-- user_profiles: users manage their own profile
DROP POLICY IF EXISTS "users_manage_own_user_profiles" ON public.user_profiles;
CREATE POLICY "users_manage_own_user_profiles"
ON public.user_profiles
FOR ALL
TO authenticated
USING (id = auth.uid())
WITH CHECK (id = auth.uid());

-- guest_sessions: public insert + read by token
DROP POLICY IF EXISTS "guest_sessions_public_insert" ON public.guest_sessions;
CREATE POLICY "guest_sessions_public_insert"
ON public.guest_sessions
FOR INSERT
TO public
WITH CHECK (true);

DROP POLICY IF EXISTS "guest_sessions_public_select" ON public.guest_sessions;
CREATE POLICY "guest_sessions_public_select"
ON public.guest_sessions
FOR SELECT
TO public
USING (expires_at > CURRENT_TIMESTAMP);

-- 7. TRIGGERS

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW
  EXECUTE FUNCTION public.handle_new_user();

DROP TRIGGER IF EXISTS update_user_profiles_updated_at ON public.user_profiles;
CREATE TRIGGER update_user_profiles_updated_at
  BEFORE UPDATE ON public.user_profiles
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();
