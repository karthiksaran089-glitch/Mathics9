-- ==========================================
-- Ranked Questions: DBMS
-- ==========================================

INSERT INTO public.ranked_questions
  (topic, difficulty, time_limit, question, option_a, option_b, option_c, option_d, correct_index, explanation)
VALUES
(
    'DBMS', 'Medium', 60,
    'Which normal form is violated when a non-prime attribute depends on only part of a composite primary key?',
    '1NF', '2NF', '3NF', 'BCNF',
    1,
    '2NF (Second Normal Form) is violated when a non-prime attribute has a partial dependency on a composite primary key — meaning it depends on only a subset of the key, not the full key.'
  ),
(
    'DBMS', 'Easy', 45,
    'Which SQL command is used to remove all rows from a table without deleting the table structure?',
    'DROP TABLE', 'DELETE FROM table', 'TRUNCATE TABLE', 'REMOVE FROM table',
    2,
    'TRUNCATE TABLE removes all rows from a table quickly without logging individual row deletions. It resets identity columns, cannot be rolled back in most DBMS (DDL operation), and is faster than DELETE FROM which logs each row.'
  ),
(
    'DBMS', 'Medium', 60,
    'What does the FOREIGN KEY constraint ensure in a relational database?',
    'Values in the column are unique', 'Values in the column reference valid values in another table''s primary key (referential integrity)', 'The column cannot contain NULL values', 'The column values are within a specified range',
    1,
    'A FOREIGN KEY ensures referential integrity: the value in the foreign key column must either be NULL or match an existing value in the referenced table''s primary key column. This maintains consistency between related tables.'
  ),
(
    'DBMS', 'Hard', 90,
    'In a relation R(A,B,C,D) with functional dependencies A→B, B→C, C→D. The decomposition into R1(A,B), R2(B,C), R3(C,D) is:',
    'Lossless but not dependency-preserving', 'Lossy and not dependency-preserving', 'Lossless and dependency-preserving', 'Lossy but dependency-preserving',
    2,
    'The decomposition R1(A,B), R2(B,C), R3(C,D) is lossless because each decomposition uses the FD key. All FDs (A→B, B→C, C→D) are preserved in R1, R2, and R3 respectively. Hence it is both lossless and dependency-preserving.'
  ),
(
    'DBMS', 'Medium', 75,
    'What is a "phantom read" in database concurrency control?',
    'Reading a record that was modified by another transaction', 'A transaction reading a set of rows, then another transaction inserts rows satisfying the same query, causing the first transaction to see different results on re-read',
    'Reading uncommitted data from another transaction', 'Reading the same row twice and getting different values',
    1,
    'A phantom read occurs at isolation level Repeatable Read or below: Transaction T1 executes a range query, T2 inserts new rows matching that range and commits, then T1 re-executes the same query and sees the new "phantom" rows. Prevented only at SERIALIZABLE isolation level.'
  ),
(
    'DBMS', 'Easy', 45,
    'Which of the following SQL aggregate functions ignores NULL values?',
    'COUNT(*)', 'COUNT(column)', 'Both COUNT(*) and COUNT(column)', 'Neither',
    1,
    'COUNT(column) ignores NULL values — it counts only non-NULL entries in that column. COUNT(*) counts all rows including those with NULLs. Other aggregate functions (SUM, AVG, MAX, MIN) also ignore NULLs by default.'
  ),
(
    'DBMS', 'Hard', 90,
    'In the context of database indexing, a "covering index" means:',
    'The index covers the entire table', 'The index contains all columns needed by a query, eliminating the need to access the base table', 'The index covers multiple tables in a join', 'The index is stored in main memory',
    1,
    'A covering index includes all columns referenced in a query (SELECT, WHERE, JOIN, ORDER BY). The query engine can satisfy the query entirely from the index without accessing the base table rows, dramatically reducing I/O.'
  ),
(
    'DBMS', 'Medium', 60,
    'What is the result of a NATURAL JOIN between two relations R(A,B,C) and S(B,C,D)?',
    'Joins on all common columns (B and C) and eliminates duplicate columns', 'A Cartesian product of R and S', 'Joins only on the first common column', 'Returns only the common columns B and C',
    0,
    'NATURAL JOIN automatically joins on all columns with the same name (B and C here), includes only rows where both B and C values match, and eliminates duplicate columns in the result. Result schema is (A,B,C,D).'
  ),
(
    'DBMS', 'Hard', 90,
    'In B+ Trees used for database indexing, which statement is TRUE compared to B-Trees?',
    'B+ Trees store data records in all nodes', 'B+ Trees store data only in leaf nodes; internal nodes contain only keys for routing', 'B+ Trees do not support range queries efficiently', 'B+ Trees have smaller height than equivalent B-Trees',
    1,
    'In B+ Trees, all actual data records (or pointers to them) are stored in leaf nodes. Internal nodes contain only keys to guide search. Leaf nodes are linked in a linked list, enabling efficient range queries by sequential leaf traversal.'
  ),
(
    'DBMS', 'Medium', 60,
    'Which SQL isolation level prevents dirty reads, non-repeatable reads, but NOT phantom reads?',
    'READ UNCOMMITTED', 'READ COMMITTED', 'REPEATABLE READ', 'SERIALIZABLE',
    2,
    'REPEATABLE READ prevents dirty reads and non-repeatable reads (re-reading same row gives same result), but phantom reads can still occur (new rows inserted by other transactions may appear in range queries). SERIALIZABLE prevents all three anomalies.'
  ),
(
    'DBMS', 'Easy', 45,
    'What does DDL stand for in the context of SQL?',
    'Data Definition Language', 'Data Derivation Logic', 'Dynamic Data Language', 'Data Display Layer',
    0,
    'DDL (Data Definition Language) includes SQL commands that define and modify database structure: CREATE, ALTER, DROP, TRUNCATE, RENAME. These operate on schema objects. DML (Data Manipulation Language) handles INSERT, UPDATE, DELETE, SELECT.'
  ),
(
    'DBMS', 'Hard', 90,
    'In distributed databases, two-phase commit (2PC) protocol ensures atomicity by:',
    'Having the coordinator execute all transactions locally', 'Phase 1: coordinator asks all participants to prepare (vote); Phase 2: if all vote YES, coordinator sends commit; else abort',
    'Replicating all transactions to backup servers', 'Using timestamps to order all transactions globally',
    1,
    '2PC ensures distributed atomicity: Phase 1 (Prepare): coordinator sends PREPARE to all participants; they log and respond VOTE-YES (ready) or VOTE-NO. Phase 2 (Commit/Abort): if all YES, coordinator sends COMMIT; if any NO, sends ABORT. All participants execute accordingly.'
  ),
(
    'DBMS', 'Medium', 60,
    'What is the difference between UNION and UNION ALL in SQL?',
    'UNION ALL is slower than UNION', 'UNION removes duplicate rows; UNION ALL includes all rows including duplicates',
    'UNION works on different table schemas; UNION ALL requires identical schemas', 'They are identical in behavior',
    1,
    'UNION combines results of two queries and removes duplicate rows (requires additional sort/hash operation). UNION ALL combines all rows including duplicates, making it faster. Both require compatible column types and counts. Use UNION ALL when you know results are distinct or duplicates are acceptable.'
  ),
(
    'DBMS', 'Hard', 90,
    'In the context of query optimization, selectivity of a predicate refers to:',
    'The number of indexes available for the query', 'The fraction of tuples satisfying the predicate; a highly selective predicate returns fewer tuples',
    'The speed of predicate evaluation', 'The number of attributes in the predicate',
    1,
    'Selectivity = (number of tuples satisfying predicate) / (total tuples). A selectivity of 0.01 means 1% of tuples satisfy the predicate (highly selective). The query optimizer uses selectivity estimates to choose efficient join orders and access methods (index vs. full scan).'
  ),
(
    'DBMS', 'Medium', 75,
    'In SQL, what does the EXISTS keyword do in a subquery?',
    'Checks if a column contains a specific value', 'Returns TRUE if the subquery produces at least one row',
    'Counts the number of rows in the subquery', 'Checks if all rows in a table satisfy a condition',
    1,
    'EXISTS is a Boolean operator that returns TRUE if the correlated subquery returns at least one row. It is often more efficient than IN for large datasets because EXISTS stops evaluating as soon as the first matching row is found, while IN must build the complete result set.'
  ),
(
    'DBMS', 'Hard', 90,
    'The "lost update" problem in concurrent transactions occurs when:',
    'A transaction reads uncommitted data from another transaction', 'Two transactions both read a value, both modify it, and one write overwrites the other''s update',
    'A transaction cannot find a previously committed row', 'A deadlock prevents any transaction from completing',
    1,
    'Lost Update: T1 reads x=100, T2 reads x=100, T1 writes x=150 (added 50), T2 writes x=80 (subtracted 20). T2''s write overwrites T1''s update, losing T1''s change. Final value is 80 instead of correct 130. Prevented by proper locking (exclusive locks on write).'
  ),
(
    'DBMS', 'Easy', 45,
    'In SQL, the PRIMARY KEY constraint enforces which two properties simultaneously?',
    'NOT NULL and UNIQUE', 'UNIQUE and FOREIGN KEY', 'DEFAULT and NOT NULL', 'CHECK and UNIQUE',
    0,
    'A PRIMARY KEY constraint automatically enforces: (1) NOT NULL — the key column(s) cannot contain NULL values, and (2) UNIQUE — no two rows can have the same primary key value. A table can have only one PRIMARY KEY but multiple UNIQUE constraints (which allow NULLs).'
  );
