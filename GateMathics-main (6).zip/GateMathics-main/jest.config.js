const nextJest = require('next/jest');

const createJestConfig = nextJest({ dir: './' });

/** @type {import('jest').Config} */
const config = {
  coverageProvider: 'v8',
  testEnvironment: 'jsdom',
  setupFilesAfterFramework: ['<rootDir>/src/__tests__/setup.ts'],
  moduleNameMapper: {
    '^@/(.*)$': '<rootDir>/src/$1',
  },
  testMatch: [
    '<rootDir>/src/__tests__/**/*.test.{js,ts,tsx}',
    '<rootDir>/src/__tests__/**/*.spec.{js,ts,tsx}',
  ],
  collectCoverageFrom: [
    'src/lib/**/*.{ts,tsx}',
    'src/contexts/**/*.{ts,tsx}',
    'src/app/practice/components/**/*.{ts,tsx}',
    'src/app/auth/**/*.{ts,tsx}',
    '!src/**/*.d.ts',
    '!src/**/__tests__/**',
  ],
  coverageThreshold: {
    global: {
      branches: 70,
      functions: 80,
      lines: 80,
      statements: 80,
    },
  },
};

module.exports = createJestConfig(config);
