# Supabase Auto-Migration Setup

This project uses **GitHub Actions** to automatically apply SQL schema changes from `supabase/migrations/` to the Supabase database on every push/merge to `main`.

## 📁 Structure

```
supabase/
├── config.toml                # Supabase project config
└── migrations/                # All SQL migration files
    ├── 20260602161000_ranked_questions_bank.sql
    ├── 20260602162000_practice_questions_bank.sql
    └── YYYYMMDDHHMMSS_description.sql
```

## 🔑 Required GitHub Secrets

Go to **GitHub → Repo → Settings → Secrets and variables → Actions** and add:

| Secret Name | Value | How to Get |
|-------------|-------|------------|
| `SUPABASE_ACCESS_TOKEN` | A personal access token | https://app.supabase.com/account/tokens → New Token |
| `SUPABASE_PROJECT_REF` | Your project ref (e.g. `abcdefghij`) | Supabase Dashboard → Settings → General → Reference ID |
| `SUPABASE_DB_PASSWORD` | Your database password | Supabase Dashboard → Settings → Database → Database password |

## 🚀 How It Works

1. Create a new migration file locally:
   ```bash
   npx supabase migration new my_change_name
   # or manually create: supabase/migrations/YYYYMMDDHHMMSS_my_change_name.sql
   ```

2. Write your SQL inside the file:
   ```sql
   -- supabase/migrations/20260603120000_add_user_stats.sql
   create table if not exists public.user_stats (...);
   ```

3. Commit & push to `main`:
   ```bash
   git add supabase/migrations/
   git commit -m "feat(db): add user_stats table"
   git push origin main
   ```

4. GitHub Actions automatically:
   - Detects changes in `supabase/migrations/`
   - Links to your Supabase project
   - Runs `supabase db push` to apply pending migrations

## 🛠️ Local Development (Optional)

You can test migrations locally **before** pushing to GitHub. The `db reset` command is **local-only** — it does NOT connect to your remote Supabase project. It only resets your local Docker-based Supabase instance.

```bash
# Start local Supabase (Docker required)
npx supabase start

# Create a new migration
npx supabase migration new my_change

# Apply all migrations to the LOCAL instance
npx supabase db reset
```

> ⚠️ If you see a `uv_spawn` error locally, it means the Supabase CLI runtime/Docker isn't installed correctly on your machine. **This does not affect the GitHub→Supabase sync** — the remote deploy uses the CLI installed inside the GitHub Actions runner, not your local shell.

**For remote sync, you do NOT need `db reset` — just push to `main` and the GitHub Actions workflow runs `supabase db push` automatically.**

## ⚠️ Rules

- ✅ **Always** add new schema changes as a new migration file
- ✅ **Never** edit an existing migration that has already been pushed to `main`
- ❌ **Avoid** making manual changes via Supabase Dashboard (except one-off settings like auth providers, API keys, etc.)
- ✅ Use the `--include-all` flag to also apply seed files (configured in workflow)

## 🔄 Manual Trigger

You can also manually run the migration workflow from the GitHub Actions tab using `workflow_dispatch`.

## 📚 References

- [Supabase CLI Docs](https://supabase.com/docs/guides/cli)
- [Supabase Migrations Guide](https://supabase.com/docs/guides/cli/local-development#database-migrations)
- [GitHub Actions Docs](https://docs.github.com/en/actions)