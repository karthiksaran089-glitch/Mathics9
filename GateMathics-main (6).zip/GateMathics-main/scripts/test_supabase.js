const { createClient } = require('@supabase/supabase-js');

// mock url and key for testing syntax locally? No, I need real credentials.
// Let me read them from .env
require('dotenv').config({ path: '.env.local' });
const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL;
const supabaseKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;
const supabase = createClient(supabaseUrl, supabaseKey);

async function run() {
  const { data: all } = await supabase.from('practice_questions').select('id').limit(2);
  const ids = all.map(r => r.id);
  console.log('Got IDs:', ids);

  // Test 1: not.in with array?
  let { data: d1, error: e1 } = await supabase.from('practice_questions').select('id').not('id', 'in', `(${ids.join(',')})`).limit(1);
  console.log('Test 1:', e1 ? e1.message : d1.length > 0 ? 'Success' : 'No data');

  // Test 2: not.in with quotes inside parentheses?
  let { data: d2, error: e2 } = await supabase.from('practice_questions').select('id').not('id', 'in', `(${ids.map(id => `"${id}"`).join(',')})`).limit(1);
  console.log('Test 2:', e2 ? e2.message : d2.length > 0 ? 'Success' : 'No data');

  // Test 3: filter not.in array?
  let { data: d3, error: e3 } = await supabase.from('practice_questions').select('id').filter('id', 'not.in', `(${ids.join(',')})`).limit(1);
  console.log('Test 3:', e3 ? e3.message : d3.length > 0 ? 'Success' : 'No data');
}

run();
