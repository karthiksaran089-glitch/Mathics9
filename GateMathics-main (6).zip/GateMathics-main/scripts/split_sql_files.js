const fs = require('fs');
const path = require('path');

const migrationsDir = path.join(__dirname, '../supabase/migrations');
const rankedFile = path.join(migrationsDir, '20260602161000_ranked_questions_bank.sql');
const practiceFile = path.join(migrationsDir, '20260602162000_practice_questions_bank.sql');

const rankedContent = fs.readFileSync(rankedFile, 'utf8');
const practiceContent = fs.readFileSync(practiceFile, 'utf8');

function splitFile(content, mode, baseTimestamp) {
  // Extract everything before the first INSERT
  const insertIndex = content.indexOf('INSERT INTO public.');
  const schemaPart = content.substring(0, insertIndex);
  const valuesPart = content.substring(insertIndex);

  // Write schema part to a new file
  const schemaFileName = `${baseTimestamp}00_${mode}_questions_schema.sql`;
  fs.writeFileSync(path.join(migrationsDir, schemaFileName), schemaPart);

  // Extract the INSERT INTO prefix
  const valuesStartIndex = valuesPart.indexOf('VALUES') + 6;
  const insertPrefix = valuesPart.substring(0, valuesStartIndex).trim() + '\n';

  const rowsString = valuesPart.substring(valuesStartIndex).trim().replace(/;$/, '');
  
  // A naive split by "),\n  (" or similar might break if text contains it.
  // Using a regex to match the start of a tuple.
  // Actually, we can just match `\(\n\s*'([^']+)'` 
  // Let's use a simple state machine or careful split.
  
  const rows = [];
  let currentStart = 0;
  let inString = false;
  let parenDepth = 0;
  let isEscaping = false;

  for (let i = 0; i < rowsString.length; i++) {
    const char = rowsString[i];
    
    if (inString) {
      if (char === "'" && !isEscaping) {
        // Lookahead to check for '' (escaped quote)
        if (i + 1 < rowsString.length && rowsString[i+1] === "'") {
          i++; // Skip the second quote
        } else {
          inString = false;
        }
      }
      isEscaping = false;
    } else {
      if (char === "'") {
        inString = true;
      } else if (char === '(') {
        parenDepth++;
      } else if (char === ')') {
        parenDepth--;
      } else if (char === ',' && parenDepth === 0) {
        // We found the end of a tuple!
        rows.push(rowsString.substring(currentStart, i).trim());
        currentStart = i + 1;
      }
    }
  }
  // Push the last row
  if (currentStart < rowsString.length) {
    rows.push(rowsString.substring(currentStart).trim());
  }

  const topicMap = {};
  
  rows.forEach(row => {
    if (!row) return;
    // Extract the topic (first string in the tuple)
    // The row looks like: ( 'Topic', 'Medium', ... )
    const topicMatch = row.match(/^\(\s*'([^']+)'/);
    if (topicMatch) {
      const topic = topicMatch[1];
      if (!topicMap[topic]) topicMap[topic] = [];
      topicMap[topic].push(row);
    } else {
      console.warn('Could not extract topic from row:', row.substring(0, 50));
    }
  });

  // Write out files
  let fileIndex = 1;
  for (const [topic, topicRows] of Object.entries(topicMap)) {
    const safeTopicName = topic.replace(/[^a-zA-Z0-9]/g, '_');
    const timestamp = (parseInt(baseTimestamp) + fileIndex).toString().padStart(14, '0');
    const fileName = `${timestamp}_${mode}_${safeTopicName}.sql`;
    
    let fileContent = `-- ==========================================\n`;
    fileContent += `-- ${mode.charAt(0).toUpperCase() + mode.slice(1)} Questions: ${topic}\n`;
    fileContent += `-- ==========================================\n\n`;
    fileContent += insertPrefix;
    fileContent += topicRows.join(',\n');
    fileContent += ';\n';
    
    fs.writeFileSync(path.join(migrationsDir, fileName), fileContent);
    fileIndex++;
  }
}

splitFile(rankedContent, 'ranked', '202606021610');
splitFile(practiceContent, 'practice', '202606021620');

// Delete the old files
fs.unlinkSync(rankedFile);
fs.unlinkSync(practiceFile);

console.log('Successfully split SQL files!');
