-- ============================================================
-- GateMathics: Analytics Data Flow Verification Script
-- ============================================================
-- Run this script in the Supabase SQL Editor to verify that
-- data is flowing correctly from Ranked Mode and Practice Mode
-- to the Analytics Dashboard.
-- ============================================================

-- 1. CHECK: How many ranked sessions exist per user
SELECT
  user_id,
  COUNT(*) AS total_ranked_sessions,
  SUM(questions_total) AS total_questions,
  SUM(questions_correct) AS total_correct,
  SUM(questions_incorrect) AS total_incorrect,
  SUM(questions_timeout) AS total_timeout,
  ROUND(AVG(accuracy), 1) AS avg_accuracy,
  SUM(lp_change) AS total_lp_change,
  MIN(session_date) AS first_session,
  MAX(session_date) AS last_session
FROM public.ranked_sessions
GROUP BY user_id
ORDER BY total_ranked_sessions DESC;

-- 2. CHECK: How many practice sessions exist per user
SELECT
  user_id,
  COUNT(*) AS total_practice_sessions,
  SUM(questions_total) AS total_questions,
  SUM(questions_correct) AS total_correct,
  SUM(questions_incorrect) AS total_incorrect,
  SUM(questions_timeout) AS total_timeout,
  ROUND(AVG(accuracy), 1) AS avg_accuracy,
  SUM(hints_used) AS total_hints,
  MIN(session_date) AS first_session,
  MAX(session_date) AS last_session
FROM public.practice_sessions
GROUP BY user_id
ORDER BY total_practice_sessions DESC;

-- 3. CHECK: User profile stats (should match session counts)
SELECT
  id AS user_id,
  display_name,
  lp,
  rank,
  total_sessions,
  total_ranked_sessions,
  total_practice_sessions,
  total_questions_answered,
  total_correct,
  total_incorrect,
  total_timeout,
  overall_accuracy,
  avg_answer_speed_seconds,
  daily_streak,
  longest_streak,
  last_active_date
FROM public.user_profiles
ORDER BY total_sessions DESC;

-- 4. CHECK: Analytics user summary view (should match profile)
SELECT
  user_id,
  lp,
  rank,
  computed_accuracy,
  lp_per_ranked_session,
  total_hints_used,
  total_sessions,
  total_ranked_sessions,
  total_practice_sessions
FROM public.analytics_user_summary;

-- 5. CHECK: Analytics session history (combined view)
SELECT
  user_id,
  mode,
  COUNT(*) AS session_count,
  SUM(questions_total) AS total_questions,
  SUM(questions_correct) AS total_correct,
  ROUND(AVG(accuracy), 1) AS avg_accuracy
FROM public.analytics_session_history
GROUP BY user_id, mode
ORDER BY user_id, mode;

-- 6. CHECK: Analytics session stats (ranked wins/losses)
SELECT
  user_id,
  total_ranked_sessions,
  total_practice_sessions,
  ranked_wins,
  ranked_losses,
  ranked_win_rate,
  best_ranked_accuracy,
  avg_ranked_accuracy,
  total_lp_gained,
  total_lp_lost
FROM public.analytics_session_stats;

-- 7. CHECK: Topic mastery (per-topic accuracy)
SELECT
  user_id,
  topic,
  total_questions,
  total_correct,
  mastery_percent,
  mastery_level
FROM public.analytics_topic_mastery
WHERE total_questions > 0
ORDER BY user_id, mastery_percent DESC;

-- 8. CHECK: Mode breakdown (practice vs ranked comparison)
SELECT
  user_id,
  practice_sessions,
  ranked_sessions,
  practice_avg_accuracy,
  ranked_avg_accuracy,
  ranked_net_lp_change,
  practice_hints_used
FROM public.analytics_mode_breakdown;

-- 9. CHECK: LP trend (recent ranked sessions)
SELECT
  user_id,
  session_date,
  lp_before,
  lp_after,
  lp_change,
  rank_before,
  rank_after
FROM public.analytics_lp_trend
WHERE session_rank_desc <= 10
ORDER BY user_id, session_date DESC;

-- 10. CHECK: Accuracy trend (all sessions)
SELECT
  user_id,
  session_date,
  mode,
  accuracy,
  avg_speed_seconds
FROM public.analytics_accuracy_trend
ORDER BY user_id, session_date DESC
LIMIT 20;

-- 11. CHECK: Activity calendar (last 35 days)
SELECT
  user_id,
  activity_date,
  session_count
FROM public.analytics_activity
WHERE session_count > 0
ORDER BY user_id, activity_date DESC;

-- 12. CHECK: Weak topics (below 55% mastery)
SELECT
  user_id,
  topic,
  mastery_percent,
  total_questions
FROM public.analytics_weak_topics
ORDER BY user_id, mastery_percent ASC;

-- 13. DATA FLOW SUMMARY
SELECT
  (SELECT COUNT(*) FROM public.ranked_sessions) AS total_ranked_rows,
  (SELECT COUNT(*) FROM public.practice_sessions) AS total_practice_rows,
  (SELECT COUNT(*) FROM public.user_profiles WHERE total_sessions > 0) AS users_with_sessions,
  (SELECT COUNT(*) FROM public.user_profiles WHERE total_ranked_sessions > 0) AS users_with_ranked,
  (SELECT COUNT(*) FROM public.user_profiles WHERE total_practice_sessions > 0) AS users_with_practice;